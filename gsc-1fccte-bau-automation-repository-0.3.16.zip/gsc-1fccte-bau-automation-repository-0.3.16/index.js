const UtilsSnowflake = require("../lib/UtilsSnowflake");

const UtilsOneShot = require("./lib/UtilsOneShot");
const UtilsVolumetry = require("../timer-check-ingest-dh/lib/UtilsVolumetryDH");

require("dotenv").config({path: `./configuration/dev.env`});

//module.exports = async function (context, myTimer) {

async function prueba() {
 
    vVolumetryHistoyry = UtilsOneShot.GetVolumetryHistoryPrueba();
     
    try {
        let vInterface;
        let vReferenceDate;
        let vVolumetry;
        let year;
        let month;
        let day;

        // ----- Define insert sentence 
        const vSqlText = `INSERT INTO BAU_VOLUMETRY_DH (INTERFACE_ID, REFERENCE_DATE, VOLUMETRY) VALUES ( ?, ?, ? )`
             

        for ( let item of vVolumetryHistoyry) {
            
            vInterface = item[0];
            vVolumetry = item[2];

            [year, month, day] = item[1].split('-');
            vReferenceDate = new Date(year, month - 1, day); // mes empieza en 0

            if ( UtilsVolumetry.GetVolumetry(vReferenceDate,vInterface) === null ) {
                
                   
                await UtilsSnowflake.InsertRowSnowflake(vSqlText, [vInterface,vReferenceDate,vVolumetry]);
                
                console.log(item, 'interface',vInterface, 'Reference date', vReferenceDate );
            }

        }

    } catch (err) {
        context.log('ERROR AL INSERTAR EN SNOWFLAKE --> ', err);
    }  
   
};


prueba();

