const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsReconciliationCheck = require("./lib/UtilsReconciliationCheck");
const UtilsTicketsReconciliationCheck = require("./lib/UtilsTicketsReconciliationCheck");

require('dotenv').config({ path: `./configuration/${process.env.environment}.env`, override: true });


module.exports = async function (context, myTimer) {

    // ---------------- Countries
    const vCountries = process.env.r3_reconciliation_countries.split(',');

    // ---------------- Date range: 1st of current month to yesterday
    const vYesterday = new Date();
    vYesterday.setDate(vYesterday.getDate() - 1);
    const vEndDate = Utils.dateToStringYYYYMMDD(vYesterday);

    const vFirstOfMonth = new Date(vYesterday.getFullYear(), vYesterday.getMonth(), 1);
    const vStartDate = Utils.dateToStringYYYYMMDD(vFirstOfMonth);

    context.log(`Ejecuta timer-reconciliation-check - Rango: ${vStartDate} a ${vEndDate}`);

    // ---------------- Functions returns OK / ERROR and an error message in a dictionary
    //                  Each function contains try/catch and return unexpected errors in message
    //                  Example: {'result': 'ERROR', 'message':'error description' } 
    //                           {'result': 'OK', 'message':'aditional information for OK' }
    let vResult = {};

    // ---------- Create Snowflake Connection
    const vSnowflakeConfig = UtilsSnowflake.GetConfigSnowflakeClient();
    const vSnowClientInstance = await UtilsSnowflake.CreateSnowflakeClientInstance(vSnowflakeConfig);

    try {

        // ---------- Get Country Config
        const vCountriesConfig = UtilsYaml.ReadConfig("CountriesConfig.yaml");

        // ---------------- for each country
        for (const vCountry of vCountries) {

            context.log('------------------------ COUNTRY:', vCountry);
            const vCountryConfig = vCountriesConfig[vCountry];
            const vCountryShortName = vCountryConfig['short_name'];

            if ( await Utils.getLog(vSnowClientInstance, vCountryShortName, vYesterday, 'RECONCILIATION_CHECK_DONE' ) === null ) {

                // ---------- CHECK 1: Volumetry comparison (DH vs TM) - day by day for the month
                const vDHData = await UtilsReconciliationCheck.getDHVolumetryByDay(
                    context,
                    vSnowClientInstance,
                    vStartDate,
                    vEndDate,
                    vCountryShortName
                );

                const vTMData = await UtilsReconciliationCheck.getTMVolumetryByDay(
                    context,
                    vSnowClientInstance,
                    vStartDate,
                    vEndDate,
                    vCountryConfig['code']
                );

                const vFullTable = UtilsReconciliationCheck.buildFullComparisonTable(vDHData, vTMData);
                const vMismatches = vFullTable.filter(r => r.status === 'DESCUADRE');

                context.log(`Días con datos DH: ${vDHData.length}, Días con datos TM: ${vTMData.length}, Descuadres: ${vMismatches.length}`);

                // ---------- Log full comparison table
                const vTableText = UtilsReconciliationCheck.formatComparisonTable(vFullTable);
                context.log(`Tabla de volumetrías ${vCountryShortName} (${vStartDate} - ${vEndDate}):\n${vTableText}`);

                let vHasMismatch = false;

                if (vMismatches.length > 0) {
                    vHasMismatch = true;
                    context.log(`DESCUADRE detectado para ${vCountryShortName} en ${vMismatches.length} día(s)`);

                    vResult = await UtilsTicketsReconciliationCheck.createTicketMismatch(
                        context,
                        vCountryConfig,
                        vEndDate,
                        vMismatches,
                        vFullTable
                    );
                    context.log(`Create ticket Reconciliation Mismatch - ${vResult['result']} ${vResult['message']}`);

                } else {
                    context.log(`Cuadre OK para ${vCountryShortName} - ${vStartDate} a ${vEndDate}`);
                }

                // ---------- CHECK 2: Parameterization errors (for the month)
                const vParamErrors = await UtilsReconciliationCheck.getParameterizationErrors(
                    context,
                    vSnowClientInstance,
                    vStartDate,
                    vEndDate,
                    vCountryConfig['code']
                );

                context.log(`Errores de parametría encontrados: ${vParamErrors.length}`);

                let vHasParamErrors = false;

                if (vParamErrors.length > 0) {
                    vHasParamErrors = true;
                    context.log(`Errores de parametría detectados para ${vCountryShortName}`);

                    vResult = await UtilsTicketsReconciliationCheck.createTicketParameterizationErrors(
                        context,
                        vCountryConfig,
                        vEndDate,
                        vParamErrors
                    );
                    context.log(`Create ticket Parameterization Errors - ${vResult['result']} ${vResult['message']}`);

                } else {
                    context.log(`Sin errores de parametría para ${vCountryShortName}`);
                }

                // ---------- Insert log
                let vLogDescription = '';
                if (vHasMismatch && vHasParamErrors) {
                    vLogDescription = `Descuadres: ${vMismatches.length} día(s) + Errores parametría: ${vParamErrors.length} (${vStartDate}-${vEndDate})`;
                } else if (vHasMismatch) {
                    vLogDescription = `Descuadres: ${vMismatches.length} día(s) (${vStartDate}-${vEndDate})`;
                } else if (vHasParamErrors) {
                    vLogDescription = `Errores parametría: ${vParamErrors.length} (${vStartDate}-${vEndDate})`;
                } else {
                    vLogDescription = `OK - Sin descuadres ni errores parametría (${vStartDate}-${vEndDate})`;
                }

                await Utils.insertLog(
                    vSnowClientInstance,
                    vCountryShortName,
                    vYesterday,
                    'I',
                    'timer-reconciliation-check',
                    'RECONCILIATION_CHECK_DONE',
                    vLogDescription
                );
            }
        }

        context.log('Finaliza timer-reconciliation-check');

    } catch(error) {
        throw new Error(error);
    } finally {
        // ---------- Close Snowflake Connection
        if (vSnowClientInstance) {
            await UtilsSnowflake.CloseConnectionSnowClient(vSnowClientInstance);
        }
    }
};
