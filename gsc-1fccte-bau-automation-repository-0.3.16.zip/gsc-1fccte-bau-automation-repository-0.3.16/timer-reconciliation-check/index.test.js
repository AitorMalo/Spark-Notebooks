"use strict";

jest.mock("../lib/UtilsSnowflake", () => ({
  GetConfigSnowflakeClient: jest.fn(),
  CreateSnowflakeClientInstance: jest.fn(),
  CloseConnectionSnowClient: jest.fn(),
  ExecuteQuerySnowflakeConn: jest.fn(),
  ExecuteQuerySnowflake: jest.fn(),
  InsertRowSnowflakeConn: jest.fn(),
  InsertRowSnowflake: jest.fn(),
}));
jest.mock("../lib/UtilsYaml", () => ({
  ReadConfig: jest.fn(),
  ClearCache: jest.fn(),
}));
jest.mock("../lib/Utils", () => ({
  dateToStringYYYYMMDD: jest.fn(),
  InitResult: jest.fn(),
  getLog: jest.fn(),
  insertLog: jest.fn(),
  ReplaceLabels: jest.fn(),
  parseYYYYMMDD: jest.fn(),
  isFestive: jest.fn(),
  getLastBusinessDay: jest.fn(),
}));
jest.mock("../lib/UtilsServicenow", () => ({
  CreateSaveTicket: jest.fn(),
  getAccessToken: jest.fn(),
  createServicenowTicket: jest.fn(),
  TicketExists: jest.fn(),
}));
jest.mock("./lib/UtilsReconciliationCheck", () => ({
  getDHVolumetryByDay: jest.fn(),
  getTMVolumetryByDay: jest.fn(),
  compareDayByDay: jest.fn(),
  buildFullComparisonTable: jest.fn(),
  formatComparisonTable: jest.fn(),
  getParameterizationErrors: jest.fn(),
}));
jest.mock("./lib/UtilsTicketsReconciliationCheck", () => ({
  createTicketMismatch: jest.fn(),
  createTicketParameterizationErrors: jest.fn(),
  generateMismatchDescription: jest.fn(),
  generateParameterizationErrorsDescription: jest.fn(),
}));

const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsReconciliationCheck = require("./lib/UtilsReconciliationCheck");
const UtilsTicketsReconciliationCheck = require("./lib/UtilsTicketsReconciliationCheck");

const indexModule = require("./index");

const mockContext = {
  log: jest.fn(),
};

beforeEach(() => {
  jest.clearAllMocks();

  process.env.r3_reconciliation_countries = "00411,00051,00053,00012";

  Utils.dateToStringYYYYMMDD.mockImplementation((d) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}${m}${day}`;
  });

  Utils.InitResult.mockReturnValue({ result: "OK", message: "OK" });
  Utils.getLog.mockResolvedValue(null);
  Utils.insertLog.mockResolvedValue();

  UtilsSnowflake.GetConfigSnowflakeClient.mockReturnValue({});
  UtilsSnowflake.CreateSnowflakeClientInstance.mockResolvedValue({});
  UtilsSnowflake.CloseConnectionSnowClient.mockResolvedValue();

  UtilsYaml.ReadConfig.mockReturnValue({
    "00411": { short_name: "PT", code: "00411" },
    "00051": { short_name: "CH", code: "00051" },
    "00053": { short_name: "UY", code: "00053" },
    "00012": { short_name: "BR", code: "00012" },
  });

  UtilsReconciliationCheck.getDHVolumetryByDay.mockResolvedValue([]);
  UtilsReconciliationCheck.getTMVolumetryByDay.mockResolvedValue([]);
  UtilsReconciliationCheck.buildFullComparisonTable.mockReturnValue([]);
  UtilsReconciliationCheck.formatComparisonTable.mockReturnValue("");
  UtilsReconciliationCheck.getParameterizationErrors.mockResolvedValue([]);

  UtilsTicketsReconciliationCheck.createTicketMismatch.mockResolvedValue({
    result: "OK",
    message: "OK",
  });
  UtilsTicketsReconciliationCheck.createTicketParameterizationErrors.mockResolvedValue({
    result: "OK",
    message: "OK",
  });
});

describe("timer-reconciliation-check index", () => {
  test("creates Snowflake connection and closes it after processing", async () => {
    await indexModule(mockContext);

    expect(UtilsSnowflake.GetConfigSnowflakeClient).toHaveBeenCalledTimes(1);
    expect(UtilsSnowflake.CreateSnowflakeClientInstance).toHaveBeenCalledTimes(1);
    expect(UtilsSnowflake.CloseConnectionSnowClient).toHaveBeenCalledTimes(1);
  });

  test("processes all 4 countries", async () => {
    await indexModule(mockContext);

    expect(UtilsReconciliationCheck.getDHVolumetryByDay).toHaveBeenCalledTimes(4);
    expect(UtilsReconciliationCheck.getTMVolumetryByDay).toHaveBeenCalledTimes(4);
    expect(UtilsReconciliationCheck.getParameterizationErrors).toHaveBeenCalledTimes(4);
  });

  test("skips country when idempotency log exists", async () => {
    Utils.getLog.mockImplementation((client, country, date, code) => {
      if (country === "PT" && code === "RECONCILIATION_CHECK_DONE") return Promise.resolve({});
      return Promise.resolve(null);
    });

    await indexModule(mockContext);

    expect(UtilsReconciliationCheck.getDHVolumetryByDay).toHaveBeenCalledTimes(3);
  });

  test("creates mismatch ticket when descuadres found", async () => {
    UtilsReconciliationCheck.buildFullComparisonTable.mockReturnValue([
      { date: "20260501", dhTotal: 100, tmTotal: 90, difference: 10, status: "DESCUADRE" },
      { date: "20260502", dhTotal: 200, tmTotal: 200, difference: 0, status: "OK" },
    ]);

    await indexModule(mockContext);

    expect(UtilsTicketsReconciliationCheck.createTicketMismatch).toHaveBeenCalledTimes(4);
  });

  test("does not create mismatch ticket when all days match", async () => {
    UtilsReconciliationCheck.buildFullComparisonTable.mockReturnValue([
      { date: "20260501", dhTotal: 100, tmTotal: 100, difference: 0, status: "OK" },
    ]);

    await indexModule(mockContext);

    expect(UtilsTicketsReconciliationCheck.createTicketMismatch).not.toHaveBeenCalled();
  });

  test("creates parameterization errors ticket when errors found", async () => {
    UtilsReconciliationCheck.getParameterizationErrors.mockResolvedValue([
      { TRANSACTION_TYPE_ID: "TYPE_001", ROWS_NUMBER: 5 },
    ]);

    await indexModule(mockContext);

    expect(UtilsTicketsReconciliationCheck.createTicketParameterizationErrors).toHaveBeenCalledTimes(4);
  });

  test("does not create param errors ticket when no errors", async () => {
    UtilsReconciliationCheck.getParameterizationErrors.mockResolvedValue([]);

    await indexModule(mockContext);

    expect(UtilsTicketsReconciliationCheck.createTicketParameterizationErrors).not.toHaveBeenCalled();
  });

  test("inserts RECONCILIATION_CHECK_DONE log for each country", async () => {
    await indexModule(mockContext);

    expect(Utils.insertLog).toHaveBeenCalledTimes(4);
    expect(Utils.insertLog).toHaveBeenCalledWith(
      expect.anything(),
      expect.any(String),
      expect.any(Date),
      "I",
      "timer-reconciliation-check",
      "RECONCILIATION_CHECK_DONE",
      expect.any(String)
    );
  });

  test("log description includes mismatch and param error info when both present", async () => {
    UtilsReconciliationCheck.buildFullComparisonTable.mockReturnValue([
      { date: "20260501", dhTotal: 100, tmTotal: 90, difference: 10, status: "DESCUADRE" },
    ]);
    UtilsReconciliationCheck.getParameterizationErrors.mockResolvedValue([
      { TRANSACTION_TYPE_ID: "TYPE_001", ROWS_NUMBER: 5 },
    ]);

    await indexModule(mockContext);

    expect(Utils.insertLog).toHaveBeenCalledWith(
      expect.anything(),
      expect.any(String),
      expect.any(Date),
      "I",
      "timer-reconciliation-check",
      "RECONCILIATION_CHECK_DONE",
      expect.stringContaining("Descuadres")
    );
  });

  test("closes Snowflake connection even when error occurs", async () => {
    UtilsReconciliationCheck.getDHVolumetryByDay.mockRejectedValue(new Error("DB error"));

    await expect(indexModule(mockContext)).rejects.toThrow();

    expect(UtilsSnowflake.CloseConnectionSnowClient).toHaveBeenCalledTimes(1);
  });

  test("logs execution start with date range", async () => {
    await indexModule(mockContext);

    expect(mockContext.log).toHaveBeenCalledWith(
      expect.stringContaining("Ejecuta timer-reconciliation-check - Rango:")
    );
  });
});
