"use strict";

jest.mock("../lib/UtilsSnowflake", () => ({
  GetConfigSnowflakeClient: jest.fn(),
  CreateSnowflakeClientInstance: jest.fn(),
  CloseConnectionSnowClient: jest.fn(),
  ExecuteQuerySnowflakeConn: jest.fn(),
  ExecuteQuerySnowflake: jest.fn(),
  InsertRowSnowflakeConn: jest.fn(),
  InsertRowSnowflake: jest.fn(),
}));
jest.mock("../lib/UtilsYaml", () => ({
  ReadConfig: jest.fn(),
  ClearCache: jest.fn(),
}));
jest.mock("../lib/Utils", () => ({
  dateToStringYYYYMMDD: jest.fn(),
  InitResult: jest.fn(),
  getLog: jest.fn(),
  insertLog: jest.fn(),
  ReplaceLabels: jest.fn(),
  parseYYYYMMDD: jest.fn(),
  isFestive: jest.fn(),
  getLastBusinessDay: jest.fn(),
}));
jest.mock("../lib/UtilsServicenow", () => ({
  CreateSaveTicket: jest.fn(),
  getAccessToken: jest.fn(),
  createServicenowTicket: jest.fn(),
  TicketExists: jest.fn(),
}));
jest.mock("./lib/UtilsReconciliationCheck", () => ({
  getDHVolumetryByDay: jest.fn(),
  getTMVolumetryByDay: jest.fn(),
  compareDayByDay: jest.fn(),
  buildFullComparisonTable: jest.fn(),
  formatComparisonTable: jest.fn(),
  getParameterizationErrors: jest.fn(),
}));
jest.mock("./lib/UtilsTicketsReconciliationCheck", () => ({
  createTicketMismatch: jest.fn(),
  createTicketParameterizationErrors: jest.fn(),
  generateMismatchDescription: jest.fn(),
  generateParameterizationErrorsDescription: jest.fn(),
}));

const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsReconciliationCheck = require("./lib/UtilsReconciliationCheck");
const UtilsTicketsReconciliationCheck = require("./lib/UtilsTicketsReconciliationCheck");

const indexModule = require("./index");

const mockContext = {
  log: jest.fn(),
};

beforeEach(() => {
  jest.clearAllMocks();

  process.env.r3_reconciliation_countries = "00411,00051,00053,00012";

  Utils.dateToStringYYYYMMDD.mockImplementation((d) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}${m}${day}`;
  });

  Utils.InitResult.mockReturnValue({ result: "OK", message: "OK" });
  Utils.getLog.mockResolvedValue(null);
  Utils.insertLog.mockResolvedValue();

  UtilsSnowflake.GetConfigSnowflakeClient.mockReturnValue({});
  UtilsSnowflake.CreateSnowflakeClientInstance.mockResolvedValue({});
  UtilsSnowflake.CloseConnectionSnowClient.mockResolvedValue();

  UtilsYaml.ReadConfig.mockReturnValue({
    "00411": { short_name: "PT", code: "00411" },
    "00051": { short_name: "CH", code: "00051" },
    "00053": { short_name: "UY", code: "00053" },
    "00012": { short_name: "BR", code: "00012" },
  });

  UtilsReconciliationCheck.getDHVolumetryByDay.mockResolvedValue([]);
  UtilsReconciliationCheck.getTMVolumetryByDay.mockResolvedValue([]);
  UtilsReconciliationCheck.buildFullComparisonTable.mockReturnValue([]);
  UtilsReconciliationCheck.formatComparisonTable.mockReturnValue("");
  UtilsReconciliationCheck.getParameterizationErrors.mockResolvedValue([]);

  UtilsTicketsReconciliationCheck.createTicketMismatch.mockResolvedValue({
    result: "OK",
    message: "OK",
  });
  UtilsTicketsReconciliationCheck.createTicketParameterizationErrors.mockResolvedValue({
    result: "OK",
    message: "OK",
  });
});

describe("timer-reconciliation-check TimerFunction", () => {
  test("executes without errors for happy path", async () => {
    await indexModule(mockContext);

    expect(mockContext.log).toHaveBeenCalledWith(
      expect.stringContaining("Finaliza timer-reconciliation-check")
    );
  });

  test("passes date range to DH and TM queries", async () => {
    await indexModule(mockContext);

    const dhCall = UtilsReconciliationCheck.getDHVolumetryByDay.mock.calls[0];
    const tmCall = UtilsReconciliationCheck.getTMVolumetryByDay.mock.calls[0];

    // startDate (arg index 2) should end with '01'
    expect(dhCall[2]).toMatch(/01$/);
    expect(tmCall[2]).toMatch(/01$/);
  });

  test("logs comparison table for each country", async () => {
    UtilsReconciliationCheck.formatComparisonTable.mockReturnValue("table text");

    await indexModule(mockContext);

    expect(mockContext.log).toHaveBeenCalledWith(
      expect.stringContaining("Tabla de volumetr")
    );
  });
});
