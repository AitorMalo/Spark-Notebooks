# SDH  Azure - Azure Function NodeJS

## Guía Workflows
En esta guía te introduciremos los distintos workflows que encontrarás en este pipeline, así como una serie de ficheros a tener en cuenta

## Workflows

### Integration

El workflow **Integration** se dispará sobre las ramas **develop, development y todas las subramas feature**. Además tenemos la posibilidad de ejecutar dicho workflow de manera manual.
En dicho worflow se ejecutará todo el proceso Build, Sonar Fortify, subir artefacto a Nexus y el despliegue de nuestra Azure Function al entorno de **certification**.

### Release
El workflow **Release** se dispará sobre las ramas **master o main**. Además tenemos la posibilidad de ejecutar dicho workflow de manera manual.
En dicho worflow se ejecutará todo el proceso Build, Sonar Fortify, subir artefacto a Nexus y el despliegue de nuestra Azure Function tanto en el entorno de **preproduction** como el de **production**, es decir, ambos.

### Manual Deploy
El workflow **Manual Deploy** como su nombre indica, es un worflow manual, que nos permitirá desplegar la version del artefacto que especifiquemos en uno de los entornos que damos a elegir:
  - certification
  - preproduction
  - production

Para ello, se requieren de dos datos:
  - **artifact-version**: Donde especificaremos la versión del artefacto, como *0.0.1-SNAPSHOT*
  - **env**: Nos permite seleccionar que entorno queremos desplegar como **certification, preproduction o production**

### Update
El workflow **Update** es un workflow que viene heredado del componente de *Gluon* llamado **Base Component Template**. Este workflow se ejecuta de manera manual, y su misión es actualizar a la última versión del **Base Component Template** que ha sido creado, para generar este repositorio (componente dentro del ecosistema de Gluon)

## Carpeta Envs
Los distintos workflows que ejecutamos siempre ejecutan el job setup-env-vars, donde se generan unas variables necesarias para poder ejecutar dichos jobs.
Hay casos en que hay ciertas variables que dependiendo de la casuística de cada proyecto, tendrá distintos valores. Por eso, existe el fichero ./envs/properties.env donde podemos modificar el valor de estas variables. Dichas varaibles son:

| Variable                        | Description |
| --------                        | -------- |
| QG_ENABLED                      | Permite habilitar Sonar y Fortify con el valor _High_ y desactivar con _None_   |
| SONAR_PROJECT_KEY               | Nombre del proyecto de Sonar, que tiene que coinicidir con el nombre del repositorio   |
| FORTIFY_PROJECT                 | Nombre del proyecto de Fortify, que tiene que coinicidir con el nombre del repositorio   |
| NPM_SONAR_PROPERTIES            | Permite especificar con que propiedades se puede ejecutar Sonar. Viene a sustituir al fichero *sonar-project.properties*   |
| NPM_APPLICATION_DIST_DIRECTORY  | Directorio donde se encuentra la carpeta dist, en caso de que no exista, se ha puesto *.* para |
| NODE_VERSION                    | Version de Node   |
| NPM_APPLICATION_GROUP           | Nombre del application group que utilizaremos para generar el artefacto de Nexus, Ej: sdh-core  |
| NPM_RUN_TEST_COMMAND            | Comandos NPM que se ejecutaran en el proceso de test  |
| NPM_RUN_AUDIT_COMMAND           | Comandos NPM que se ejecutaran en el proceso de audit   |
| NPM_RUN_BUILD_COMMAND           | Comandos NPM que se ejecutaran en el proceso de build   |
| CERTIFICATE_MAPPING             | Ruta donde se encuentra el fichero para consultar los secretos del Vault, que sería */vaultcfgs/vaultinfo.json*   |

Un ejemplo de ello sería 

```
QG_ENABLED='None'
SONAR_PROJECT_KEY="gsc-alias-test"
FORTIFY_PROJECT="gsc-alias-test"
NPM_APPLICATION_DIST_DIRECTORY="."
NODE_VERSION="20.14.0"
NPM_APPLICATION_GROUP="sdh-core"
NPM_RUN_TEST_COMMAND=""
NPM_RUN_AUDIT_COMMAND="npm ci --audit=false --ignore-scripts --legacy-peer-deps"
NPM_RUN_BUILD_COMMAND="npm run test:report && npm ci --omit='dev' --audit=false --ignore-scripts --legacy-peer-deps"
CERTIFICATE_MAPPING="./vaultcfgs/vaultinfo.json"
NPM_SONAR_PROPERTIES='-Dsonar.sources=.  -Dsonar.tests=tests -Dsonar.exclusions=node_modules/**,*.yaml,*.json,*.tgz,*.md,Jenkinsfile,.eslintrc.js,*.spec.js., **.test.js, **/test/**, **/coverage/**, **/proxies.json, **/VUGenerator.js, **/constants.js -Dsonar.javascript.coveragePlugin=lcov -Dsonar.javascript.lcov.reportPath=coverage/lcov.info'

```

Actualmente *dichas variables ya estan configuradas* para que *funcionen en una Function App*. Es posible que se tenga que modificar algunas variables como la NPM_SONAR_PROPERTIES sea la más modificada ya que cada proyecto tiene distintas opciones.

## Deployent.yaml
Como se venía utilizando desde antes, se necesita de un fichero de deployment.yaml para poder desplegar en los distintos entornos. El cambios más destacado, es el nombre de los distintos entornos

```yaml
environments:
  - name: certification
    regions:
      - name: EU-WEST
        properties:
          SPN_CREDENTIALS_ID: 
          RESOURCE_GROUP: 
          APP_NAME: 
          KUDU_API:
            enabled: true
            url: 
  - name: preproduction
    regions:
      - name: EU-WEST
        properties:
          SPN_CREDENTIALS_ID: 
          RESOURCE_GROUP: 
          APP_NAME: 
          KUDU_API:
            enabled: true
            url: 
  - name: production
    regions:
      - name: EU-WEST
        properties:
          SPN_CREDENTIALS_ID: 
          RESOURCE_GROUP: 
          APP_NAME: 
          KUDU_API:
            enabled: true
            url: 
```
### Entorno Hybrid
El fichero deployment.yaml tambien permite añadir el entorno hybrid, para ellos sera necesario añadir el nombre **hyb**
```yaml
environments:
  - name: hyb
    regions:
      - name: EU-WEST
        properties:
          SPN_CREDENTIALS_ID: 
          RESOURCE_GROUP: 
          APP_NAME: 
          KUDU_API:
            enabled: true
            url: 
```
Por otro lado, a la hora de especificar el entorno hyb, *a nivel de github y gluon no encontraremos el entorno hyb/hybrid*, ya que por defecto se crean los entornos de certification, preproduction y production.

Como *el entorno hyb es muy similar al de certification*, las ejecuiones del entorno hyb, *aparecerán en el entorno certification*.

## Vault
Los componentes de gluon utilizan Hashicorp Vault para almacenar secretos, por ello se ha creado el fichero /vaultcfgs/vaultinfo.json, en donde se ha especificado un secreto que utilizamos a nivel de pipeline para poder desplegar en la Azure Function

Por otro lado, el valor del SPN_CREDENTIALS_ID del fichero de deployment.yaml se basa su nombre en el nombre que pongamos en la propiedad file. El valor del SPN_CREDENTIALS_ID tiene el siguiente formato `HC_<value_of_file_property>`


Para el siguiente caso
```json
[
  {
    "secret_name": "azure_credentials_certification",
    "key": "*",
    "file": "azure_credentials_dev"
  },
  {
    "secret_name": "azure_credentials_hyb",
    "key": "*",
    "file": "azure_credentials_hyb"
  },
  {
    "secret_name": "azure_credentials_preproduction",
    "key": "*",
    "file": "azure_credentials_pre"
  },
  {
    "secret_name": "azure_credentials_production",
    "key": "*",
    "file": "azure_credentials_pro"
  }
]
```
En nuestro fichero deployment.yaml tendriamos el siguiente valor para SPN_CREDENTIALS_ID
```yaml
environments:
  - name: hyb
    regions:
      - name: EU-WEST
        properties:
          SPN_CREDENTIALS_ID: HC_AZURE_CREDENTIALS_HYB
          RESOURCE_GROUP: ""
          APP_NAME: ""
          KUDU_API:
            enabled: true
            url: ""
```
