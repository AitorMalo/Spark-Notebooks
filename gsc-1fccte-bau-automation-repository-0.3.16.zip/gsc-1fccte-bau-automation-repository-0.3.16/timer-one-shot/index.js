const snowflakeDB = require("@sdh-core/sdh-core-lib/lib/Snowflake");
const UtilsSnowflake = require("../lib/UtilsSnowflake");
const Utils = require("../lib/Utils");
const UtilsOneShot = require("./lib/UtilsOneShot");
 
require('dotenv').config({ path: `./configuration/${process.env.environment}.env`, override: true });

module.exports = async function (context, myTimer) {

    context.log('🚀 Inicio timer-one-shot');
    
    // ----- Connect to Snowflake 
    const vConfig = UtilsSnowflake.GetConfigSnowflakeClient();
    const vSnowClientInstance = await snowflakeDB.getInstance(vConfig);

    // ----- Read date execution from environment variables
    const vDateProcessEnvVariable = process.env.OneShot_execution_date;
   
    // ----- Read date execution from Snowflake (table BAU_LOGS)
    const vDateProcessSnowflake = await UtilsOneShot.getExecutionDateSnowflake(vSnowClientInstance);
    const vDateProcessSnowflakeString = vDateProcessSnowflake 
        ? Utils.dateToStringYYYYMMDD(new Date(vDateProcessSnowflake)) 
        : null;

    // ----- Set today variable
    const vToday = new Date();
    const vTodayString = Utils.dateToStringYYYYMMDD(vToday);
    
    context.log(`ℹ️ Hoy -> ${vTodayString} - Fecha en variable entorno --> ${vDateProcessEnvVariable} - Fecha en Snowflake --> ${vDateProcessSnowflakeString}` );

    // ----- If the execution date defined in the environment variables 
    //       or the one defined in the Snowflake BAU_LOGS table matches today's date: the oneshot is executed
    if ( vTodayString === vDateProcessEnvVariable || vTodayString === vDateProcessSnowflakeString ) { 

        context.log(`Antes de UtilsOneShot.GetVolumetryHistory()` );

        const vVolumetryHistoyry = UtilsOneShot.GetVolumetryHistory();
        
        context.log(`Después de UtilsOneShot.GetVolumetryHistory()` );
       
        try {

            // ----- Columnas
            const vColumns = ['INTERFACE_ID','REFERENCE_DATE','VOLUMETRY'];

            // ----- Base del INSERT
            const baseSql = `
                INSERT INTO BAU_VOLUMETRY_DH 
                (${vColumns.join(', ')}) 
                VALUES 
            `;

            // ----- Preparar datos
            const rowsToInsert = [];

            for (let item of vVolumetryHistoyry) {

                const vInterface = item[0];
                const vVolumetry = item[2];

                const [year, month, day] = item[1].split('-');
                const vReferenceDate = new Date(year, month - 1, day);

                rowsToInsert.push([vInterface, vReferenceDate, vVolumetry]);
            }

            if (rowsToInsert.length === 0) {
                context.log("No hay filas para insertar");
                return;
            }

            

            const chunkSize = 10000;  

            for (let i = 0; i < rowsToInsert.length; i += chunkSize) {

                const chunk = rowsToInsert.slice(i, i + chunkSize);

                // Generar placeholders dinámicos (?, ?, ?), (?, ?, ?), ...
                const placeholders = chunk
                    .map(() => `(${Array(vColumns.length).fill('?').join(',')})`)
                    .join(',');

                const sqlText = baseSql + placeholders;

                // Aplanar array [[...],[...]] -> [...]
                const flatValues = chunk.flat();

                try {
                    await vSnowClientInstance.executeQueryAsync(
                        sqlText,
                        'String',
                        flatValues
                    );

                    context.log(`Insertadas ${chunk.length} filas`);
                } catch (err) {
                    context.log(`Error en bloque desde índice ${i} --> ${err}`);
                }
            }

            context.log(`✅ Proceso finalizado. Total filas: ${rowsToInsert.length}`);

        } catch (err) {
            context.log('ERROR GENERAL --> ', err);
        }
    } else {
        context.log(`ℹ️ No se ejecuta OneShot` );

    }

    // ----- Close Snowflake conection
    await UtilsSnowflake.CloseConnectionSnowClient(vSnowClientInstance);
};
