const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsTransactionCount = require("./lib/UtilsTransactionCount");
const UtilsTicketsTransactionCount = require("./lib/UtilsTicketsTransactionCount");

require('dotenv').config({ path: `./configuration/${process.env.environment}.env`, override: true });


module.exports = async function (context, myTimer) {

    // ---------------- Countries
    const vCountries = process.env.r3_countries.split(',');

    // ---------------- Date range: 1st of current month to yesterday
    const vYesterday = new Date();
    vYesterday.setDate(vYesterday.getDate() - 1);
    const vEndDate = Utils.dateToStringYYYYMMDD(vYesterday);

    const vFirstOfMonth = new Date(vYesterday.getFullYear(), vYesterday.getMonth(), 1);
    const vStartDate = Utils.dateToStringYYYYMMDD(vFirstOfMonth);

    context.log(`Ejecuta timer-transaction-type-id-count - Rango: ${vStartDate} a ${vEndDate}`);

    // ---------------- Functions returns OK / ERROR and an error message in a dictionary
    //                  Each function contains try/catch and return unexpected errors in message
    //                  Example: {'result': 'ERROR', 'message':'error description' } 
    //                           {'result': 'OK', 'message':'aditional information for OK' }
    let vResult = {};

    // ---------- Create Snowflake Connection
    const vSnowflakeConfig = UtilsSnowflake.GetConfigSnowflakeClient();
    const vSnowClientInstance = await UtilsSnowflake.CreateSnowflakeClientInstance(vSnowflakeConfig);

    try {

        // ---------- Get Country Config
        const vCountriesConfig = UtilsYaml.ReadConfig("CountriesConfig.yaml");

        // ---------------- for each country
        for (const vCountry of vCountries) {

            context.log('------------------------ COUNTRY:', vCountry);
            const vCountryConfig = vCountriesConfig[vCountry];
            const vCountryShortName = vCountryConfig['short_name'];

            if ( await Utils.getLog(vSnowClientInstance, vCountryShortName, vYesterday, 'TRANSACTION_COUNT_NO_DATA' ) === null
               && await Utils.getLog(vSnowClientInstance, vCountryShortName, vYesterday, 'TRANSACTION_COUNT_PROCESSED_OK' ) === null ) {
                
                // ---------- 1. Query transaction type id count data from Snowflake (date range, filtered by country)
                const vTransactionData = await UtilsTransactionCount.getTransactionTypeIdCount(
                    context,
                    vSnowClientInstance,
                    vStartDate,
                    vEndDate,
                    vCountryConfig['code']
                );
    
                context.log(`Registros obtenidos: ${vTransactionData.length} (${vStartDate} a ${vEndDate})`);
    
                // ---------- 2. Create ticket (with data or "no data" depending on query result)
                vResult = await UtilsTicketsTransactionCount.createTicketTransactionCount(
                    context,
                    vCountryConfig,
                    vStartDate,
                    vEndDate,
                    vTransactionData
                );
    
                if (vTransactionData.length === 0) {
                    context.log(`No hay datos de transaction_type_id_count para ${vCountryShortName} - ${vStartDate} a ${vEndDate}`);
                    context.log(`Create ticket Transaction Count NO DATA - ${vResult['result']} ${vResult['message']}`);
    
                    // ---------- 3. Insert log (no data)
                    await Utils.insertLog(
                        vSnowClientInstance,
                        vCountryShortName,
                        vYesterday,
                        'I',
                        'timer-transaction-type-id-count',
                        'TRANSACTION_COUNT_NO_DATA',
                        `No se encontraron datos (${vStartDate} a ${vEndDate})`
                    );
    
                } else {
                    context.log(`Create ticket Transaction Count - ${vResult['result']} ${vResult['message']}`);
    
                    // ---------- 3. Insert log (data found)
                    await Utils.insertLog(
                        vSnowClientInstance,
                        vCountryShortName,
                        vYesterday,
                        'I',
                        'timer-transaction-type-id-count',
                        'TRANSACTION_COUNT_PROCESSED_OK',
                        `Procesado OK (${vStartDate} a ${vEndDate})`
                    );
                }
            }
        }

        context.log('Finaliza timer-transaction-type-id-count');

    } catch(error) {
        throw new Error(error);
    } finally {
        // ---------- Close Snowflake Connection
        if (vSnowClientInstance) {
            await UtilsSnowflake.CloseConnectionSnowClient(vSnowClientInstance);
        }
    }
};
