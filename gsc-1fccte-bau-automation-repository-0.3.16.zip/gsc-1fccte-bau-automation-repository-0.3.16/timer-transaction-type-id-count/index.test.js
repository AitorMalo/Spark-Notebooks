"use strict";

jest.mock("../lib/UtilsSnowflake", () => ({
  GetConfigSnowflakeClient: jest.fn(),
  CreateSnowflakeClientInstance: jest.fn(),
  CloseConnectionSnowClient: jest.fn(),
  ExecuteQuerySnowflakeConn: jest.fn(),
  ExecuteQuerySnowflake: jest.fn(),
  InsertRowSnowflakeConn: jest.fn(),
  InsertRowSnowflake: jest.fn(),
}));
jest.mock("../lib/UtilsYaml", () => ({
  ReadConfig: jest.fn(),
  ClearCache: jest.fn(),
}));
jest.mock("../lib/Utils", () => ({
  dateToStringYYYYMMDD: jest.fn(),
  InitResult: jest.fn(),
  getLog: jest.fn(),
  insertLog: jest.fn(),
  ReplaceLabels: jest.fn(),
  parseYYYYMMDD: jest.fn(),
  isFestive: jest.fn(),
  getLastBusinessDay: jest.fn(),
}));
jest.mock("../lib/UtilsServicenow", () => ({
  CreateSaveTicket: jest.fn(),
  getAccessToken: jest.fn(),
  createServicenowTicket: jest.fn(),
  TicketExists: jest.fn(),
}));
jest.mock("./lib/UtilsTransactionCount", () => ({
  getTransactionTypeIdCount: jest.fn(),
}));
jest.mock("./lib/UtilsTicketsTransactionCount", () => ({
  createTicketTransactionCount: jest.fn(),
  generateTicketDescription: jest.fn(),
}));

const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsTransactionCount = require("./lib/UtilsTransactionCount");
const UtilsTicketsTransactionCount = require("./lib/UtilsTicketsTransactionCount");

const indexModule = require("./index");

const mockContext = {
  log: jest.fn(),
};

beforeEach(() => {
  jest.clearAllMocks();

  process.env.r3_countries = "00411,00051,00053,00012";

  Utils.dateToStringYYYYMMDD.mockImplementation((d) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}${m}${day}`;
  });

  Utils.InitResult.mockReturnValue({ result: "OK", message: "OK" });
  Utils.getLog.mockResolvedValue(null);
  Utils.insertLog.mockResolvedValue();

  UtilsSnowflake.GetConfigSnowflakeClient.mockReturnValue({});
  UtilsSnowflake.CreateSnowflakeClientInstance.mockResolvedValue({});
  UtilsSnowflake.CloseConnectionSnowClient.mockResolvedValue();

  UtilsYaml.ReadConfig.mockReturnValue({
    "00411": { short_name: "PT", code: "00411" },
    "00051": { short_name: "CH", code: "00051" },
    "00053": { short_name: "UY", code: "00053" },
    "00012": { short_name: "BR", code: "00012" },
  });

  UtilsTransactionCount.getTransactionTypeIdCount.mockResolvedValue([]);
  UtilsTicketsTransactionCount.createTicketTransactionCount.mockResolvedValue({
    result: "OK",
    message: "OK",
  });
});

describe("timer-transaction-type-id-count index", () => {
  test("creates Snowflake connection and closes it after processing", async () => {
    await indexModule(mockContext);

    expect(UtilsSnowflake.GetConfigSnowflakeClient).toHaveBeenCalledTimes(1);
    expect(UtilsSnowflake.CreateSnowflakeClientInstance).toHaveBeenCalledTimes(1);
    expect(UtilsSnowflake.CloseConnectionSnowClient).toHaveBeenCalledTimes(1);
  });

  test("processes all 4 countries", async () => {
    await indexModule(mockContext);

    expect(UtilsTransactionCount.getTransactionTypeIdCount).toHaveBeenCalledTimes(4);
    expect(UtilsTicketsTransactionCount.createTicketTransactionCount).toHaveBeenCalledTimes(4);
  });

  test("skips country when idempotency log exists (NO_DATA)", async () => {
    Utils.getLog.mockImplementation((client, country, date, code) => {
      if (country === "PT" && code === "TRANSACTION_COUNT_NO_DATA") return Promise.resolve({});
      return Promise.resolve(null);
    });

    await indexModule(mockContext);

    // PT skipped, 3 remaining countries processed
    expect(UtilsTransactionCount.getTransactionTypeIdCount).toHaveBeenCalledTimes(3);
  });

  test("skips country when idempotency log exists (PROCESSED_OK)", async () => {
    Utils.getLog.mockImplementation((client, country, date, code) => {
      if (country === "CH" && code === "TRANSACTION_COUNT_PROCESSED_OK") return Promise.resolve({});
      return Promise.resolve(null);
    });

    await indexModule(mockContext);

    expect(UtilsTransactionCount.getTransactionTypeIdCount).toHaveBeenCalledTimes(3);
  });

  test("inserts TRANSACTION_COUNT_NO_DATA log when no data found", async () => {
    UtilsTransactionCount.getTransactionTypeIdCount.mockResolvedValue([]);

    await indexModule(mockContext);

    expect(Utils.insertLog).toHaveBeenCalledWith(
      expect.anything(),
      expect.any(String),
      expect.any(Date),
      "I",
      "timer-transaction-type-id-count",
      "TRANSACTION_COUNT_NO_DATA",
      expect.stringContaining("No se encontraron datos")
    );
  });

  test("inserts TRANSACTION_COUNT_PROCESSED_OK log when data found", async () => {
    UtilsTransactionCount.getTransactionTypeIdCount.mockResolvedValue([
      { LEGAL_ENTITY_CODE: "00411", TRANSACTION_TYPE_ID: "TYPE_001", ROWS_NUMBER: 100 },
    ]);

    await indexModule(mockContext);

    expect(Utils.insertLog).toHaveBeenCalledWith(
      expect.anything(),
      expect.any(String),
      expect.any(Date),
      "I",
      "timer-transaction-type-id-count",
      "TRANSACTION_COUNT_PROCESSED_OK",
      expect.stringContaining("Procesado OK")
    );
  });

  test("passes date range (startDate, endDate) to query function", async () => {
    await indexModule(mockContext);

    const call = UtilsTransactionCount.getTransactionTypeIdCount.mock.calls[0];
    // call: (context, snowClient, startDate, endDate, code)
    const startDate = call[2];
    const endDate = call[3];

    // startDate should be 1st of month (ends with '01')
    expect(startDate).toMatch(/^\d{8}$/);
    expect(startDate.substring(6)).toBe("01");
    // endDate should be yesterday
    expect(endDate).toMatch(/^\d{8}$/);
  });

  test("passes date range to ticket creation function", async () => {
    UtilsTransactionCount.getTransactionTypeIdCount.mockResolvedValue([
      { LEGAL_ENTITY_CODE: "00411", TRANSACTION_TYPE_ID: "TYPE_001", ROWS_NUMBER: 100 },
    ]);

    await indexModule(mockContext);

    const call = UtilsTicketsTransactionCount.createTicketTransactionCount.mock.calls[0];
    // call: (context, countryConfig, startDate, endDate, data)
    expect(call[2]).toMatch(/^\d{8}$/);
    expect(call[3]).toMatch(/^\d{8}$/);
  });

  test("closes Snowflake connection even when error occurs", async () => {
    UtilsTransactionCount.getTransactionTypeIdCount.mockRejectedValue(new Error("DB error"));

    await expect(indexModule(mockContext)).rejects.toThrow();

    expect(UtilsSnowflake.CloseConnectionSnowClient).toHaveBeenCalledTimes(1);
  });

  test("logs execution start with date range", async () => {
    await indexModule(mockContext);

    expect(mockContext.log).toHaveBeenCalledWith(
      expect.stringContaining("Ejecuta timer-transaction-type-id-count - Rango:")
    );
  });
});
