"use strict";

jest.mock("../lib/UtilsSnowflake", () => ({
  GetConfigSnowflakeClient: jest.fn(),
  CreateSnowflakeClientInstance: jest.fn(),
  CloseConnectionSnowClient: jest.fn(),
  ExecuteQuerySnowflakeConn: jest.fn(),
  ExecuteQuerySnowflake: jest.fn(),
  InsertRowSnowflakeConn: jest.fn(),
  InsertRowSnowflake: jest.fn(),
}));
jest.mock("../lib/UtilsYaml", () => ({
  ReadConfig: jest.fn(),
  ClearCache: jest.fn(),
}));
jest.mock("../lib/Utils", () => ({
  dateToStringYYYYMMDD: jest.fn(),
  InitResult: jest.fn(),
  getLog: jest.fn(),
  insertLog: jest.fn(),
  ReplaceLabels: jest.fn(),
  parseYYYYMMDD: jest.fn(),
  isFestive: jest.fn(),
  getLastBusinessDay: jest.fn(),
}));
jest.mock("../lib/UtilsServicenow", () => ({
  CreateSaveTicket: jest.fn(),
  getAccessToken: jest.fn(),
  createServicenowTicket: jest.fn(),
  TicketExists: jest.fn(),
}));
jest.mock("./lib/UtilsFileLoad", () => ({
  getTMVolumetries: jest.fn(),
  getTMInterfaceInfo: jest.fn(),
  getDHVolumetryForGrouped: jest.fn(),
  getDHVolumetryForNonGrouped: jest.fn(),
  checkVolumetryConsistency: jest.fn(),
  getMandatoryDHNotInTM: jest.fn(),
  getDHNotInTM: jest.fn(),
  getDatesToProcess: jest.fn(),
  formatVolumetryTable: jest.fn(),
  formatMissingReport: jest.fn(),
}));
jest.mock("./lib/UtilsTicketsFileLoad", () => ({
  createTicketFileLoad: jest.fn(),
}));

const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsFileLoad = require("./lib/UtilsFileLoad");
const UtilsTicketsFileLoad = require("./lib/UtilsTicketsFileLoad");

const indexModule = require("./index");

const mockContext = {
  log: jest.fn(),
};

beforeEach(() => {
  jest.clearAllMocks();

  process.env.r3_file_load_countries = "00411,00051,00053";

  Utils.dateToStringYYYYMMDD.mockReturnValue("20260512");
  Utils.InitResult.mockReturnValue({ result: "OK", message: "OK" });
  Utils.getLog.mockResolvedValue(null);
  Utils.insertLog.mockResolvedValue();

  UtilsSnowflake.GetConfigSnowflakeClient.mockReturnValue({});
  UtilsSnowflake.CreateSnowflakeClientInstance.mockResolvedValue({});
  UtilsSnowflake.CloseConnectionSnowClient.mockResolvedValue();

  UtilsYaml.ReadConfig.mockReturnValue({
    "00411": { short_name: "PT", code: "00411" },
    "00051": { short_name: "CH", code: "00051" },
    "00053": { short_name: "UY", code: "00053" },
  });

  const vYesterday = new Date();
  vYesterday.setDate(vYesterday.getDate() - 1);
  vYesterday.setHours(0, 0, 0, 0);

  UtilsFileLoad.getDatesToProcess.mockResolvedValue([
    { date: vYesterday, check_mandatories: true },
  ]);
  UtilsFileLoad.getMandatoryDHNotInTM.mockResolvedValue([]);
  UtilsFileLoad.getDHNotInTM.mockResolvedValue([]);
  UtilsFileLoad.checkVolumetryConsistency.mockResolvedValue([]);
  UtilsFileLoad.formatVolumetryTable.mockReturnValue("table");
  UtilsFileLoad.formatMissingReport.mockReturnValue("");

  UtilsTicketsFileLoad.createTicketFileLoad.mockResolvedValue({
    result: "OK",
    message: "OK",
  });
});

describe("timer-check-file-load TimerFunction", () => {
  test("executes without errors for happy path", async () => {
    await indexModule(mockContext);

    expect(mockContext.log).toHaveBeenCalledWith(
      expect.stringContaining("Finaliza timer-check-file-load")
    );
  });

  test("calls getDatesToProcess for each country", async () => {
    await indexModule(mockContext);

    expect(UtilsFileLoad.getDatesToProcess).toHaveBeenCalledTimes(3);
  });

  test("runs all 3 checks for each date", async () => {
    await indexModule(mockContext);

    // 3 countries * 1 date = 3 calls each
    expect(UtilsFileLoad.getMandatoryDHNotInTM).toHaveBeenCalledTimes(3);
    expect(UtilsFileLoad.getDHNotInTM).toHaveBeenCalledTimes(3);
    expect(UtilsFileLoad.checkVolumetryConsistency).toHaveBeenCalledTimes(3);
  });
});
