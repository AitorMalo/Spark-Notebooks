"use strict";

jest.mock("../lib/UtilsSnowflake", () => ({
  GetConfigSnowflakeClient: jest.fn(),
  CreateSnowflakeClientInstance: jest.fn(),
  CloseConnectionSnowClient: jest.fn(),
  ExecuteQuerySnowflakeConn: jest.fn(),
  ExecuteQuerySnowflake: jest.fn(),
  InsertRowSnowflakeConn: jest.fn(),
  InsertRowSnowflake: jest.fn(),
}));
jest.mock("../lib/UtilsYaml", () => ({
  ReadConfig: jest.fn(),
  ClearCache: jest.fn(),
}));
jest.mock("../lib/Utils", () => ({
  dateToStringYYYYMMDD: jest.fn(),
  InitResult: jest.fn(),
  getLog: jest.fn(),
  insertLog: jest.fn(),
  ReplaceLabels: jest.fn(),
  parseYYYYMMDD: jest.fn(),
  isFestive: jest.fn(),
  getLastBusinessDay: jest.fn(),
}));
jest.mock("../lib/UtilsServicenow", () => ({
  CreateSaveTicket: jest.fn(),
  getAccessToken: jest.fn(),
  createServicenowTicket: jest.fn(),
  TicketExists: jest.fn(),
}));
jest.mock("./lib/UtilsFileLoad", () => ({
  getTMVolumetries: jest.fn(),
  getTMInterfaceInfo: jest.fn(),
  getDHVolumetryForGrouped: jest.fn(),
  getDHVolumetryForNonGrouped: jest.fn(),
  checkVolumetryConsistency: jest.fn(),
  getMandatoryDHNotInTM: jest.fn(),
  getDHNotInTM: jest.fn(),
  getDatesToProcess: jest.fn(),
  formatVolumetryTable: jest.fn(),
  formatMissingReport: jest.fn(),
}));
jest.mock("./lib/UtilsTicketsFileLoad", () => ({
  createTicketFileLoad: jest.fn(),
}));

const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsFileLoad = require("./lib/UtilsFileLoad");
const UtilsTicketsFileLoad = require("./lib/UtilsTicketsFileLoad");

const indexModule = require("./index");

const mockContext = {
  log: jest.fn(),
};

beforeEach(() => {
  jest.clearAllMocks();

  process.env.r3_file_load_countries = "00411,00051,00053";

  Utils.dateToStringYYYYMMDD.mockReturnValue("20260512");
  Utils.InitResult.mockReturnValue({ result: "OK", message: "OK" });
  Utils.getLog.mockResolvedValue(null);
  Utils.insertLog.mockResolvedValue();

  UtilsSnowflake.GetConfigSnowflakeClient.mockReturnValue({});
  UtilsSnowflake.CreateSnowflakeClientInstance.mockResolvedValue({});
  UtilsSnowflake.CloseConnectionSnowClient.mockResolvedValue();

  UtilsYaml.ReadConfig.mockReturnValue({
    "00411": { short_name: "PT", code: "00411" },
    "00051": { short_name: "CH", code: "00051" },
    "00053": { short_name: "UY", code: "00053" },
  });

  const vYesterday = new Date();
  vYesterday.setDate(vYesterday.getDate() - 1);
  vYesterday.setHours(0, 0, 0, 0);

  UtilsFileLoad.getDatesToProcess.mockResolvedValue([
    { date: vYesterday, check_mandatories: true },
  ]);
  UtilsFileLoad.getMandatoryDHNotInTM.mockResolvedValue([]);
  UtilsFileLoad.getDHNotInTM.mockResolvedValue([]);
  UtilsFileLoad.checkVolumetryConsistency.mockResolvedValue([]);
  UtilsFileLoad.formatVolumetryTable.mockReturnValue("table");
  UtilsFileLoad.formatMissingReport.mockReturnValue("");

  UtilsTicketsFileLoad.createTicketFileLoad.mockResolvedValue({
    result: "OK",
    message: "OK",
  });
});

describe("timer-check-file-load index", () => {
  test("creates Snowflake connection and closes it after processing", async () => {
    await indexModule(mockContext);

    expect(UtilsSnowflake.GetConfigSnowflakeClient).toHaveBeenCalledTimes(1);
    expect(UtilsSnowflake.CreateSnowflakeClientInstance).toHaveBeenCalledTimes(1);
    expect(UtilsSnowflake.CloseConnectionSnowClient).toHaveBeenCalledTimes(1);
  });

  test("processes all 3 countries", async () => {
    await indexModule(mockContext);

    expect(UtilsFileLoad.getDatesToProcess).toHaveBeenCalledTimes(3);
  });

  test("skips date when idempotency log exists", async () => {
    Utils.getLog.mockResolvedValue({});

    await indexModule(mockContext);

    expect(UtilsFileLoad.getMandatoryDHNotInTM).not.toHaveBeenCalled();
    expect(UtilsFileLoad.getDHNotInTM).not.toHaveBeenCalled();
    expect(UtilsFileLoad.checkVolumetryConsistency).not.toHaveBeenCalled();
  });

  test("creates ticket when mandatory files are missing", async () => {
    UtilsFileLoad.getMandatoryDHNotInTM.mockResolvedValue([
      { NAME: "Contact_File", GROUPED: false },
    ]);

    await indexModule(mockContext);

    expect(UtilsTicketsFileLoad.createTicketFileLoad).toHaveBeenCalledTimes(3);
  });

  test("creates ticket when DH files not in TM", async () => {
    UtilsFileLoad.getDHNotInTM.mockResolvedValue([
      { NAME: "SomeFile", DH_INTERFACES: ["SomeFile"], GROUPED: false },
    ]);

    await indexModule(mockContext);

    expect(UtilsTicketsFileLoad.createTicketFileLoad).toHaveBeenCalledTimes(3);
  });

  test("creates ticket when volumetry mismatches exist", async () => {
    UtilsFileLoad.checkVolumetryConsistency.mockResolvedValue([
      { INTERFACE: "Contact", TM_ROWS: 100, DH_VOLUMETRY: 90, DIFFERENCE: 10, MATCH: false },
    ]);

    await indexModule(mockContext);

    expect(UtilsTicketsFileLoad.createTicketFileLoad).toHaveBeenCalledTimes(3);
  });

  test("does not create ticket when no issues found", async () => {
    UtilsFileLoad.checkVolumetryConsistency.mockResolvedValue([
      { INTERFACE: "Contact", TM_ROWS: 100, DH_VOLUMETRY: 100, DIFFERENCE: 0, MATCH: true },
    ]);

    await indexModule(mockContext);

    expect(UtilsTicketsFileLoad.createTicketFileLoad).not.toHaveBeenCalled();
  });

  test("inserts FILE_LOAD_CHECK_DONE log for each processed date", async () => {
    await indexModule(mockContext);

    expect(Utils.insertLog).toHaveBeenCalledWith(
      expect.anything(),
      expect.any(String),
      expect.any(Date),
      "I",
      "timer-check-file-load",
      "FILE_LOAD_CHECK_DONE",
      expect.any(String)
    );
  });

  test("log description includes issue details when issues found", async () => {
    UtilsFileLoad.getMandatoryDHNotInTM.mockResolvedValue([
      { NAME: "File1", GROUPED: false },
    ]);
    UtilsFileLoad.getDHNotInTM.mockResolvedValue([
      { NAME: "File2", DH_INTERFACES: ["File2"], GROUPED: false },
    ]);

    await indexModule(mockContext);

    expect(Utils.insertLog).toHaveBeenCalledWith(
      expect.anything(),
      expect.any(String),
      expect.any(Date),
      "I",
      "timer-check-file-load",
      "FILE_LOAD_CHECK_DONE",
      expect.stringContaining("Mand missing")
    );
  });

  test("truncates log description to 2000 chars", async () => {
    // Create a scenario where description would be very long
    const longMissing = Array.from({ length: 500 }, (_, i) => ({
      NAME: `VeryLongFileName_${i}_${i}_${i}`,
      GROUPED: false,
    }));
    UtilsFileLoad.getMandatoryDHNotInTM.mockResolvedValue(longMissing);

    await indexModule(mockContext);

    // Just verify insertLog was called - the truncation logic is in index.js
    expect(Utils.insertLog).toHaveBeenCalled();
  });

  test("closes Snowflake connection even when error occurs", async () => {
    UtilsFileLoad.getDatesToProcess.mockRejectedValue(new Error("DB error"));

    await expect(indexModule(mockContext)).rejects.toThrow();

    expect(UtilsSnowflake.CloseConnectionSnowClient).toHaveBeenCalledTimes(1);
  });

  test("logs execution start", async () => {
    await indexModule(mockContext);

    expect(mockContext.log).toHaveBeenCalledWith(
      expect.stringContaining("Ejecuta timer-check-file-load")
    );
  });
});
