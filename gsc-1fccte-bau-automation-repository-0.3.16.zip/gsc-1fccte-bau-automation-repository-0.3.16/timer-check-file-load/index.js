const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsFileLoad = require("./lib/UtilsFileLoad");
const UtilsTicketsFileLoad = require("./lib/UtilsTicketsFileLoad");

require('dotenv').config({ path: `./configuration/${process.env.environment}.env`, override: true });


module.exports = async function (context, myTimer) {

    // ---------------- Countries
    const vCountries = process.env.r3_file_load_countries.split(',');

    context.log(`Ejecuta timer-check-file-load`);

    // ---------------- Functions returns OK / ERROR and an error message in a dictionary
    //                  Each function contains try/catch and return unexpected errors in message
    //                  Example: {'result': 'ERROR', 'message':'error description' } 
    //                           {'result': 'OK', 'message':'aditional information for OK' }
    let vResult = {};

    // ---------- Create Snowflake Connection
    const vSnowflakeConfig = UtilsSnowflake.GetConfigSnowflakeClient();
    const vSnowClientInstance = await UtilsSnowflake.CreateSnowflakeClientInstance(vSnowflakeConfig);

    try {

        // ---------- Get Country Config
        const vCountriesConfig = UtilsYaml.ReadConfig("CountriesConfig.yaml");

        // ---------------- for each country
        for (const vCountry of vCountries) {

            context.log('------------------------ COUNTRY:', vCountry);
            const vCountryConfig = vCountriesConfig[vCountry];
            const vCountryShortName = vCountryConfig['short_name'];

            // ---------- Get dates to process and check_mandatories flag
            const vDatesToProcess = await UtilsFileLoad.getDatesToProcess(vSnowClientInstance, vCountry);

            for (const vDateInfo of vDatesToProcess) {

                const vDate = vDateInfo.date;
                const vCheckMandatories = vDateInfo.check_mandatories;
                const vDateString = Utils.dateToStringYYYYMMDD(vDate);

                context.log(`Fecha: ${vDateString}, check_mandatories: ${vCheckMandatories}`);

                // ---------- Idempotency guard
                if ( await Utils.getLog(vSnowClientInstance, vCountryShortName, vDate, 'FILE_LOAD_CHECK_DONE' ) === null ) {

                    // ---------- CHECK 1: Mandatory DH files present in TM
                    const vMandatoryMissing = await UtilsFileLoad.getMandatoryDHNotInTM(
                        context,
                        vSnowClientInstance,
                        vDateString,
                        vCountry,
                        vCountryShortName,
                        vCheckMandatories
                    );

                    context.log(`Mandatory DH not in TM: ${vMandatoryMissing.length}`);

                    // ---------- CHECK 2: All DH files present in TM
                    const vDHNotInTM = await UtilsFileLoad.getDHNotInTM(
                        context,
                        vSnowClientInstance,
                        vDateString,
                        vCountry,
                        vCountryShortName
                    );

                    context.log(`DH files not in TM: ${vDHNotInTM.length}`);

                    // ---------- CHECK 3: Volumetry consistency DH vs TM
                    const vVolumetryResults = await UtilsFileLoad.checkVolumetryConsistency(
                        context,
                        vSnowClientInstance,
                        vDateString,
                        vCountry,
                        vCountryShortName
                    );

                    const vVolumetryMismatches = vVolumetryResults.filter(r => !r.MATCH);
                    context.log(`Volumetry mismatches: ${vVolumetryMismatches.length} of ${vVolumetryResults.length}`);

                    // ---------- Log volumetry table (always)
                    if (vVolumetryResults.length > 0) {
                        const vTable = UtilsFileLoad.formatVolumetryTable(vVolumetryResults);
                        context.log(`Volumetry table for ${vCountryShortName} (${vDateString}):\n${vTable}`);
                    }

                    // ---------- Determine if there are issues
                    const vHasIssues = vMandatoryMissing.length > 0 || vDHNotInTM.length > 0 || vVolumetryMismatches.length > 0;

                    if (vHasIssues) {
                        // ---------- Log missing files report
                        const vMissingReport = UtilsFileLoad.formatMissingReport(vMandatoryMissing, vDHNotInTM);
                        if (vMissingReport) {
                            context.log(`Missing files for ${vCountryShortName} (${vDateString}):\n${vMissingReport}`);
                        }

                        // ---------- Create ticket
                        vResult = await UtilsTicketsFileLoad.createTicketFileLoad(
                            context,
                            vCountryConfig,
                            vDateString,
                            vVolumetryResults,
                            vMandatoryMissing,
                            vDHNotInTM
                        );
                        context.log(`Create ticket File Load - ${vResult['result']} ${vResult['message']}`);

                    } else {
                        context.log(`File load OK para ${vCountryShortName} - ${vDateString}`);
                    }

                    // ---------- Insert log (truncate to 2000 chars - VARCHAR limit in BAU_LOGS.DESCRIPTION)
                    let vLogDescription = '';
                    if (vHasIssues) {
                        const vParts = [];
                        if (vMandatoryMissing.length > 0) vParts.push(`Mand missing: ${vMandatoryMissing.length}`);
                        if (vDHNotInTM.length > 0) vParts.push(`DH not in TM: ${vDHNotInTM.length}`);
                        if (vVolumetryMismatches.length > 0) vParts.push(`Vol mismatch: ${vVolumetryMismatches.length}`);
                        vLogDescription = vParts.join(' + ') + ` (${vDateString})`;
                    } else {
                        vLogDescription = `OK (${vDateString})`;
                    }

                    if (vLogDescription.length > 2000) {
                        vLogDescription = vLogDescription.substring(0, 1997) + '...';
                    }

                    await Utils.insertLog(
                        vSnowClientInstance,
                        vCountryShortName,
                        vDate,
                        'I',
                        'timer-check-file-load',
                        'FILE_LOAD_CHECK_DONE',
                        vLogDescription
                    );
                } else {
                    context.log(`Ya procesado ${vCountryShortName} para ${vDateString} - skip`);
                }
            }
        }

        context.log('Finaliza timer-check-file-load');

    } catch(error) {
        throw new Error(error);
    } finally {
        // ---------- Close Snowflake Connection
        if (vSnowClientInstance) {
            await UtilsSnowflake.CloseConnectionSnowClient(vSnowClientInstance);
        }
    }
};
