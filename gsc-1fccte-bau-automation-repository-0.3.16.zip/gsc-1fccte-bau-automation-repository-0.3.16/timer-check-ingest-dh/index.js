const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsIngestDH = require("./lib/UtilsIngestDH");
const UtilsTicketsDH =  require("./lib/UtilsTicketsDH");
require('dotenv').config({ path: `./configuration/${process.env.environment}.env`, override: true });



module.exports = async function (context, myTimer) {

    // ---------------- Countries
    const vCountries = process.env.checkIngestDH_countries.split(',');
    //const vCountries = ['00051'];

    // ---------------- Functions returns OK / ERROR and an error message in a dictionary
    //                  Each function contains try/catch and return unexpected errors in message
    //                  Example: {'result': 'ERROR', 'message':'error description' } 
    //                           {'result': 'OK', 'message':'aditional information for OK' }
    let vResult = {}; 

    // ---------- Create Snowflake Connection
    const vSnowflakeConfig = UtilsSnowflake.GetConfigSnowflakeClient();
    const vSnowClientInstance = await UtilsSnowflake.CreateSnowflakeClientInstance(vSnowflakeConfig);

    try { 

        // ---------- Get Country Config
        const vCountriesConfig = UtilsYaml.ReadConfig("CountriesConfig.yaml");
        

        // ---------------- for each country
        for (const vCountry of vCountries) {  

            context.log('------------------------ COUNTRY:', vCountry);
            const vCountryShortName = vCountriesConfig[vCountry]['short_name'];

            // ---------------- BAU-1 - Check Ingest DH
            //                  BAU-4 - Check Referential Integrity
            
            vResult = await UtilsIngestDH.checkIngestDH(context, vCountry);
            
            // ---------- Any unespected error is returning in vResult
            if ( vResult['result'] === 'ERROR') {
                context.log(vResult['message'] );
                throw new Error(vResult['message']);  
            }
            
            if ( vResult['result'] === 'OK' ) { 
        
                // ---------------- BAU-3 - Chech Controls ING
                context.log('----- BAU-3');
                vResult = await UtilsIngestDH.checkING(context, vSnowClientInstance, vCountry);
                
                // ---------- Any unespected error is returning in vResult
                if ( vResult['result'] === 'ERROR') {
                    context.log(vResult['message'] );
                    throw new Error(vResult['message']);  
                }
        
            } else {
                throw new Error(`Index - error en checkIngestDH: ${vResult['message']}`);
            }

            // ---------------- BAU-2 + CREACIÓN DE TICKETS - T1 y T2 

            const vDatesToProcess = await UtilsIngestDH.getDatesToProcess(vSnowClientInstance, vCountry);
            
            for (const vDate of vDatesToProcess) {
                
                     

                // --------- If the CHECK VOLUMETRY process or the TICKET generation process has not yet been executed:
                if ( await Utils.getLog(vSnowClientInstance, vCountryShortName, vDate['date'], 'VOLUMETRY_PROCESSED_OK' ) === null || 
                     await Utils.getLog(vSnowClientInstance, vCountryShortName, vDate['date'], 'TICKET_PROCESSED_OK' ) === null ) {

                    context.log(`Procesa ${Utils.dateToStringYYYYMMDD(vDate['date'])} - check_mandatories: ${vDate['check_mandatories']}`);  

                    vResult = await UtilsTicketsDH.createTicketsIngestDH(context, vDate['date'], vCountry, vDate['check_mandatories']);
                     
                    // ---------- Any unespected error is returning in vResult
                    if ( vResult['result'] === 'ERROR') {
                        context.log(vResult['message'] );
                        throw new Error(vResult['message']);  
                    }
                }
            }
        } 
        //context.log('Finaliza BAU-1-2-3-4');
    } catch(error) {
        throw new Error(error);
    } finally {
        // ---------- Close Snowflake Connection
        if (vSnowClientInstance) {
            await UtilsSnowflake.CloseConnectionSnowClient(vSnowClientInstance);
        }
    }
}