const UtilsSnowflake = require("../lib/UtilsSnowflake");
const UtilsYaml = require("../lib/UtilsYaml");
const Utils = require("../lib/Utils");
const UtilsCM = require("./lib/UtilsCM");

require('dotenv').config({ path: `./configuration/${process.env.environment}.env`, override: true });

module.exports = async function (context, myTimer) {

    context.log('Entorno -->', process.env.environment);

    // ---------------- Countries
    const vCountries = process.env.caseManager_countries.split(',');
    
    // ---------------- Functions returns OK / ERROR and an error message in a dictionary
    //                  Each function contains try/catch and return unexpected errors in message
    //                  Example: {'result': 'ERROR', 'message':'error description' } 
    //                           {'result': 'OK', 'message':'aditional information for OK' }
    let vResult = Utils.InitResult('Index timer-check-proactive-reactive');

    // ---------- Create Snowflake Connection
    const vSnowflakeConfig = UtilsSnowflake.GetConfigSnowflakeClient();
    const vSnowClientInstance = await UtilsSnowflake.CreateSnowflakeClientInstance(vSnowflakeConfig);

    try { 

        // ---------- Get Country Config
        const vCountriesConfig = UtilsYaml.ReadConfig("CountriesConfig.yaml");
        
        let vDatesToProcess;

        // ---------------- for each country
        for (const vCountry of vCountries) {  

            context.log('🚀 ----- Inicio R2B ', vCountry);
            const vCountryShortName = vCountriesConfig[vCountry]['short_name'];

            // ---------- getDatesToProcess return Yesterday + dates to process in BAU_LOGS
            vDatesToProcess = await UtilsCM.getDatesToProcess(vSnowClientInstance, vCountryShortName);

            // ---------------- BAU-18-19 -  Proactive-Reactive
            for (const vDate of vDatesToProcess) {
                
                if ( await Utils.getLog(vSnowClientInstance, vCountryShortName, vDate, 'CM_PROCESSED_OK' ) === null ) {
                
                    context.log('Procesa fecha ',vDate);
                    vResult = await UtilsCM.checkProactiveReactive(context, vSnowClientInstance, vCountry, vCountryShortName, vDate);
                    context.log(`BAU-18-19 -  Proactivos-Reactivos - ${vResult['result']} ${vResult['message']}`)
                    
                    if ( vResult['result'] === 'ERROR' ) { 
                        const vError = `❌ Index - BAU-18-19 -  Proactivos-Reactivos: ${vResult['message']}`
                        context.log(vError);
                        throw new Error(vError);
                    }
                    
                    // --------- Insert log CM_PROCESSED_OK
                    await Utils.insertLog(vSnowClientInstance, vCountryShortName, vDate, 'I', 'timer-check-proactive-reactive', 'CM_PROCESSED_OK', 'Proactivos-Reactivos procesado' );
                               
                }
            }

            context.log('✅ Fin ', vCountry);
        } 
    } catch(error) {
        throw new Error(error);
    } finally {
        // ---------- Close Snowflake Connection
        if (vSnowClientInstance) {
            await UtilsSnowflake.CloseConnectionSnowClient(vSnowClientInstance);
        }
    }
}