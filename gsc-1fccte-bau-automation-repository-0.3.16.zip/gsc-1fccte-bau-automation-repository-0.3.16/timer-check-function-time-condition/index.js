const {
    InsertRowSnowflake,
    CreateSnowflakeClientInstance,
    GetConfigSnowflakeClient,
    CloseConnectionSnowClient,
    ExecuteQuerySnowflake,
    InsertPruebaHarcodeado
} = require("../lib/UtilsSnowflake");

require("dotenv").config({path: `./configuration/dev.env`});

module.exports = async function (context, myTimer) {

    // =============== LOG CON TIMESTAMP
    const timestamp = new Date().toISOString();
    context.log(`Execution time: ${timestamp}`);
 

    // =============== VARIABLES DE ENTORNO SNOWFLAKE
    const snowflakeEnvObject = Object.fromEntries(
        Object.entries(process.env).filter(([key]) => key.toLowerCase().includes('snowflake'))
    );
    context.log("variables de entorno SNOWFLAKE --> ",snowflakeEnvObject);

    // =============== INSERTAR EN SNOWFLAKE
    // try {
        
    //     // vValues = ['2a330ce8-752c-4590-a0ad-222222222222','Nombre de fichero insertado desde Azure Function'];
    //     // snowflake.InsertRowSnowflake('BAU_FILES_MASTER', vValues);

    //     // ----- Define insert sentence 
    //     const vSqlText = `INSERT INTO BAU_FILES_MASTER ('TRACE_ID', 'FILENAME') VALUES ( '2a330ce8-752c-4590-a0ad-222222222222','Nombre de fichero insertado desde Azure Function')`
    //     const vRows = await InsertPruebaHarcodeado(vSqlText);
    //     context.log('filas insertadas --> ',vRows);

    // } catch (err) {
    //     context.log('ERROR AL INSERTAR EN SNOWFLAKE --> ', err);
    // }  
    
    // =============== LEER DE SNOWFLAKE
    try {
        
        // ----- Define query 
        const vSqlText = `SELECT * FROM BAU_FILES_MASTER`
        
        const vSnowflakeConfig = GetConfigSnowflakeClient();

        context.log('vSnowflakeConfig -->',vSnowflakeConfig);

        const snowClientInstance = await CreateSnowflakeClientInstance(vSnowflakeConfig);
        const result = await ExecuteQuerySnowflake(snowClientInstance, vSqlText);
        
        context.log(`Recuperó ${result.length} filas` )

    } catch (err) {
        context.log('ERROR AL LEER DE SNOWFLAKE --> ', err);
    }   
};