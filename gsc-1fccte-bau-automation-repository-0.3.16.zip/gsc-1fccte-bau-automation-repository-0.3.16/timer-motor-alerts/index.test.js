"use strict";

jest.mock("./lib/AlertasMotor");
jest.mock("../lib/Utils");

const AlertasMotor = require("./lib/AlertasMotor");
const Utils = require("../lib/Utils");

const indexModule = require("./index");

const mockContext = {
  log: jest.fn(),
};

beforeEach(() => {
  jest.clearAllMocks();
  Utils.InitResult.mockReturnValue({ result: "OK", message: "OK" });
});

describe("timer-motor-alerts index", () => {
  test("calls GetTicketsTypes for each automation and country", async () => {
    AlertasMotor.GetTicketsTypes.mockReturnValue({});

    await indexModule(mockContext);

    // 3 automations * 4 countries = 12 calls
    expect(AlertasMotor.GetTicketsTypes).toHaveBeenCalledTimes(12);
    expect(AlertasMotor.GetTicketsTypes).toHaveBeenCalledWith("ALERTAS_MOTOR_WARNING");
    expect(AlertasMotor.GetTicketsTypes).toHaveBeenCalledWith("ALERTAS_MOTOR_KO");
    expect(AlertasMotor.GetTicketsTypes).toHaveBeenCalledWith("FALLO_INGESTA_RE");
  });

  test("calls AlertasMotorWarning for WARNING ticket types", async () => {
    AlertasMotor.GetTicketsTypes.mockImplementation((auto) => {
      if (auto === "ALERTAS_MOTOR_WARNING") return { "Alertas_Motor_War_TM": "tm" };
      return {};
    });
    AlertasMotor.AlertasMotorWarning.mockResolvedValue({ result: "OK", message: "ok" });

    await indexModule(mockContext);

    expect(AlertasMotor.AlertasMotorWarning).toHaveBeenCalledWith(
      mockContext,
      "Alertas_Motor_War_TM",
      expect.any(String),
      expect.any(String),
      "tm"
    );
  });

  test("calls AlertasMotorKO for KO ticket types", async () => {
    AlertasMotor.GetTicketsTypes.mockImplementation((auto) => {
      if (auto === "ALERTAS_MOTOR_KO")
        return { "Alertas_Motor_KO_TM": { filter: "tm", operator: "=" } };
      return {};
    });
    AlertasMotor.AlertasMotorKO.mockResolvedValue({ result: "OK", message: "ok" });

    await indexModule(mockContext);

    expect(AlertasMotor.AlertasMotorKO).toHaveBeenCalledWith(
      mockContext,
      "Alertas_Motor_KO_TM",
      expect.any(String),
      expect.any(String),
      "tm",
      "="
    );
  });

  test("calls FallosIngestaRe for FALLO_INGESTA_RE ticket types", async () => {
    AlertasMotor.GetTicketsTypes.mockImplementation((auto) => {
      if (auto === "FALLO_INGESTA_RE") return { "Fallo_Ingesta_RE": {} };
      return {};
    });
    AlertasMotor.FallosIngestaRe.mockResolvedValue({ result: "OK", message: "ok" });

    await indexModule(mockContext);

    expect(AlertasMotor.FallosIngestaRe).toHaveBeenCalledWith(
      mockContext,
      "Fallo_Ingesta_RE",
      expect.any(String),
      expect.any(String)
    );
  });

  test("logs error when result is ERROR", async () => {
    AlertasMotor.GetTicketsTypes.mockImplementation((auto) => {
      if (auto === "ALERTAS_MOTOR_WARNING") return { "Type1": "tm" };
      return {};
    });
    AlertasMotor.AlertasMotorWarning.mockResolvedValue({
      result: "ERROR",
      message: "Something went wrong",
    });

    await expect(indexModule(mockContext)).rejects.toThrow("Something went wrong");

    expect(mockContext.log).toHaveBeenCalledWith("Something went wrong");
  });

  test("handles default case for unknown automation", async () => {
    // This shouldn't happen in practice since autos are hardcoded,
    // but the switch has a default case
    AlertasMotor.GetTicketsTypes.mockReturnValue({});

    await indexModule(mockContext);

    // Should complete without errors
    expect(mockContext.log).toHaveBeenCalled();
  });

  test("processes all 4 countries", async () => {
    AlertasMotor.GetTicketsTypes.mockReturnValue({});

    await indexModule(mockContext);

    // Verify date string is logged
    expect(mockContext.log).toHaveBeenCalledWith(
      expect.stringContaining("Ejecuta timer-motor_alert")
    );
  });
});
