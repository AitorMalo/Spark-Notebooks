const AlertasMotor = require('./lib/AlertasMotor');
const Utils = require("../lib/Utils");
//"schedule": "0 */10 * * * 1-5" "schedule": "0 0 31 2 * *"

module.exports = async function (context) {
  
  
    //  Reference date
    const vDate = new Date();
    vDate.setDate(vDate.getDate() - 1);

    const vDay = String(vDate.getDate()).padStart(2, '0');
    const vMonth = String(vDate.getMonth() + 1).padStart(2, '0');
    const vYear = vDate.getFullYear();

    const vDateString = `${vYear}${vMonth}${vDay}`;  
    //let vDateString = '20231123'

    context.log(`Ejecuta timer-motor_alert - Date --> ${vDateString}`);
    
    const vCountries = ['00411', '00051', '00053', '00012'];
    // automations
    const vAutos = [
        'ALERTAS_MOTOR_WARNING', // bau_5
        'ALERTAS_MOTOR_KO', // bau_6
        'FALLO_INGESTA_RE' ]; // bau_7
    
    // execute tickets types for each automation
    let vTicketsTypes = {};
    let vResult = Utils.InitResult('IndexAlertasMotor');

    // ---------- for each country
    for (const vCountry of vCountries) {  
      
        // ---------- for each auto
        for (const vAuto of vAutos) { 
          
            context.log(`Ejecuta ${vAuto}`);
            
            vTicketsTypes= AlertasMotor.GetTicketsTypes(vAuto);
              
            // ---------- for each ticket type
            for (const vTicketType of Object.keys(vTicketsTypes)) { 
                
              context.log(`Ticket type --> ${vTicketType}`);
                
              switch (vAuto) {
                    case 'ALERTAS_MOTOR_WARNING':
                      vResult =  await AlertasMotor.AlertasMotorWarning(context, vTicketType, vCountry, vDateString, vTicketsTypes[vTicketType]);  
                      break;
                    case 'ALERTAS_MOTOR_KO':  
                      vResult =  await AlertasMotor.AlertasMotorKO(context, vTicketType, vCountry, vDateString, vTicketsTypes[vTicketType]['filter'], vTicketsTypes[vTicketType]['operator']);
                      break;
                    case 'FALLO_INGESTA_RE':
                      vResult =  await AlertasMotor.FallosIngestaRe(context, vTicketType, vCountry, vDateString);
                      break;
                    default:
                      context.log(`Valor inválido para vAuto --> ${vAuto}`);
              } // switch

              // ---------- Any unespected error is returning in vResult
              if ( vResult['result'] === 'ERROR') {
                  context.log(vResult['message'] );
                  throw new Error(vResult['message']);  
              }
          }  
        }  
    }  
    

};
