
# swift_driver.py
#
# Orquestador de SWIFT Parsing basado en configuración YAML.
# Lee un fichero YAML, decide el modo de ejecución (automatic, manual, reprocess,
# incremental, recovery) y llama a la función main() definida en SWIFT_parsing.py.

import argparse
import logging
import os
from datetime import datetime, timedelta

import yaml

# Importamos la función main de tu código actual de parsing.
# Firma esperada:
#   def main(adls_input_base_dir, adls_output_base_dir, date, local_dir): ...
from SWIFT_parsing import main as swift_main


DATE_FMT = "%Y%m%d"  # Formato de fecha: 20250115


def parse_date(date_str: str) -> datetime:
    """Convierte '20250115' -> datetime."""
    return datetime.strptime(date_str, DATE_FMT)


def format_date(dt: datetime) -> str:
    """Convierte datetime -> '20250115'."""
    return dt.strftime(DATE_FMT)


def date_range_inclusive(start_str: str, end_str: str):
    """Genera todas las fechas entre start y end (ambas incluidas)."""
    start = parse_date(start_str)
    end = parse_date(end_str)
    current = start
    while current <= end:
        yield format_date(current)
        current += timedelta(days=1)


def setup_logger(log_level: str = "INFO"):
    """Configura logging básico para el driver."""
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    logging.basicConfig(
        level=numeric_level,
        format="%(asctime)s | %(levelname)s | %(message)s"
    )


def load_config(path: str) -> dict:
    """Lee un YAML y devuelve un dict."""
    with open(path, "r") as f:
        return yaml.safe_load(f)


def apply_auth_env(auth_cfg: dict | None):
    """Carga las credenciales del YAML en variables de entorno para que las use SWIFT_parsing.

    Espera un bloque de este estilo:

    auth:
      client_id: "..."
      client_secret: "..."
      tenant_id: "..."
      storage_account: "..."
    """
    if not auth_cfg:
        logging.info("No se ha definido bloque 'auth' en el YAML; se asume configuración externa.")
        return

    os.environ["SWIFT_CLIENT_ID"] = auth_cfg.get("client_id", "")
    os.environ["SWIFT_CLIENT_SECRET"] = auth_cfg.get("client_secret", "")
    os.environ["SWIFT_TENANT_ID"] = auth_cfg.get("tenant_id", "")
    os.environ["SWIFT_STORAGE_ACCOUNT"] = auth_cfg.get("storage_account", "")

    logging.info("Variables de entorno SWIFT_* cargadas desde YAML (client_id, tenant_id, storage_account).")


def run_for_single_date(cfg: dict, date_str: str):
    """Llama a swift_main() para una única fecha, aplicando antes la configuración de auth."""
    paths = cfg["paths"]
    adls_input_base_dir = paths["adls_input_base_dir"]
    adls_output_base_dir = paths["adls_output_base_dir"]
    local_dir = paths["local_work_dir"]

    # Cargamos credenciales (si existen) en variables de entorno
    auth_cfg = cfg.get("auth")
    apply_auth_env(auth_cfg)

    logging.info(
        f"Ejecutando SWIFT parsing para fecha={date_str} | "
        f"input={adls_input_base_dir} | output={adls_output_base_dir} | local={local_dir}"
    )

    # Delegamos en tu lógica de parsing (definida en SWIFT_parsing.main)
    swift_main(adls_input_base_dir, adls_output_base_dir, date_str, local_dir)



def run_automatic(cfg: dict):
    """Modo automatic: pensado para ejecución diaria (y futuro horario)."""
    freq = cfg["execution"].get("frequency", "daily")
    exec_date = cfg["execution"].get("execution_date")

    if not exec_date:
        exec_date = format_date(datetime.today())
        logging.info(f"No se ha definido execution.execution_date. Usando fecha de hoy: {exec_date}")

    if freq == "daily":
        logging.info(f"[automatic/daily] Procesando fecha {exec_date}")
        run_for_single_date(cfg, exec_date)
    elif freq == "hourly":
        logging.info("[automatic/hourly] Placeholder – aquí iría el consumo horario de la API.")
        # En el futuro, aquí se podría añadir lógica de consumo horario de la API.
    else:
        raise ValueError(f"execution.frequency no soportado: {freq}")



def run_manual(cfg: dict):
    """Modo manual: ejecuta el parsing para una fecha concreta definida en el YAML."""
    exec_date = cfg["execution"]["execution_date"]
    logging.info(f"[manual] Procesando fecha {exec_date}")
    run_for_single_date(cfg, exec_date)



def run_reprocess(cfg: dict):
    """Modo reprocess: recorre un rango de fechas y reprocesa cada día."""
    hr = cfg["historical_range"]
    start = hr["start"]
    end = hr["end"]

    logging.info(f"[reprocess] Reprocesando rango completo {start} -> {end}")

    for date_str in date_range_inclusive(start, end):
        logging.info(f"[reprocess] Fecha {date_str}")
        run_for_single_date(cfg, date_str)



def run_incremental(cfg: dict):
    """Modo incremental: similar a automatic, pero semánticamente para nueva info (BIC, etc.)."""
    exec_date = cfg["execution"]["execution_date"]
    logging.info(f"[incremental] Procesando fecha {exec_date}")
    run_for_single_date(cfg, exec_date)



def run_recovery(cfg: dict):
    """Modo recovery: permite reprocesar un día concreto o rellenar un hueco de días."""
    recovery_cfg = cfg["recovery"]
    rtype = recovery_cfg["type"]

    if rtype == "manual_load":
        date_str = recovery_cfg["date"]
        logging.info(f"[recovery/manual_load] Reprocesando fecha {date_str}")
        run_for_single_date(cfg, date_str)
    elif rtype == "fill_gap":
        start = recovery_cfg["start_date"]
        end = recovery_cfg["end_date"]
        logging.info(f"[recovery/fill_gap] Reprocesando hueco {start} -> {end}")
        for date_str in date_range_inclusive(start, end):
            logging.info(f"[recovery/fill_gap] Fecha {date_str}")
            run_for_single_date(cfg, date_str)
    else:
        raise ValueError(f"recovery.type no soportado: {rtype}")



def main():
    parser = argparse.ArgumentParser(description="Driver de SWIFT Parsing basado en YAML")
    parser.add_argument(
        "--config",
        required=True,
        help="Ruta al fichero YAML de configuración (por ejemplo: configs/swift_daily_automatic.yaml)"
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        help="Nivel de log (DEBUG, INFO, WARNING, ERROR)"
    )

    args = parser.parse_args()
    setup_logger(args.log_level)

    cfg = load_config(args.config)
    mode = cfg["execution"]["mode"]

    logging.info(f"Iniciando SWIFT driver en modo={mode} | config={args.config}")

    if mode == "automatic":
        run_automatic(cfg)
    elif mode == "manual":
        run_manual(cfg)
    elif mode == "reprocess":
        run_reprocess(cfg)
    elif mode == "incremental":
        run_incremental(cfg)
    elif mode == "recovery":
        run_recovery(cfg)
    else:
        raise ValueError(f"execution.mode no soportado: {mode}")

    logging.info("Ejecución del driver finalizada correctamente.")



if __name__ == "__main__":
    main()
