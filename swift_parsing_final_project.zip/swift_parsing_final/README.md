
# SWIFT Parsing – Proyecto orquestado por YAML

Estructura profesional pensada para integración con Control-M.

## Estructura de directorios

swift_parsing/
├── src/
│   ├── swift_driver.py              # Orquestador: lee YAML y llama a SWIFT_parsing.main()
│   ├── SWIFT_parsing.py             # Lógica real de parsing (adaptada desde tu notebook)
│   ├── swiftutils.py                # Utilidades y funciones auxiliares del parsing
│   └── swift_move_data_and_unzip.py # Script de soporte para cargas manuales (sin cambios funcionales)
└── configs/
    ├── swift_daily_automatic.yaml
    ├── swift_manual_load.yaml
    ├── swift_reprocess_full.yaml
    ├── swift_incremental.yaml
    ├── swift_recovery_manual.yaml
    └── swift_recovery_fill_gap.yaml

## Ejecución básica

Ejemplo de ejecución desde línea de comandos o desde Control-M:

```bash
python swift_parsing/src/swift_driver.py --config swift_parsing/configs/swift_daily_automatic.yaml
```

Cada YAML define:
- `execution.mode` (automatic, manual, reprocess, incremental, recovery)
- Rango de fechas o fecha concreta
- Bloque `auth` con credenciales para ADLS
- Bloque `paths` con rutas base de entrada/salida y directorio local de trabajo
