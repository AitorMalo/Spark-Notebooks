const xlsx = require('xlsx');
const fs = require('fs');
const path = require('path');

// Ruta del archivo Excel
const inputFile = path.join(__dirname, 'UY_volumetry.xlsx');
// Ruta del archivo CSV de salida
const outputFile = path.join(__dirname, 'UY_output.csv');

// Leer el archivo Excel
const workbook = xlsx.readFile(inputFile);

// Tomar la primera hoja
const sheetName = workbook.SheetNames[0];
const sheet = workbook.Sheets[sheetName];

// Convertir la hoja a JSON
const data = xlsx.utils.sheet_to_json(sheet, { defval: null });

// Obtener las columnas (headers)
const headers = Object.keys(data[0]);

// La primera columna es interface_id
const interfaceColumn = headers[0];
// El resto son reference_date
const dateColumns = headers.slice(1);

// Array para almacenar las filas del CSV
const csvRows = [];
csvRows.push('interface_id,reference_date,volumetry');

// Transformar los datos
data.forEach(row => {
  const interfaceId = row[interfaceColumn];

  
  dateColumns.forEach(date => {
    const volumetry = row[date];

    if (volumetry !== null && volumetry !== undefined) {
      csvRows.push(`${interfaceId},${date},${volumetry}`);
    }
  });
});

// Escribir el archivo CSV
fs.writeFileSync(outputFile, csvRows.join('\n'), 'utf8');

console.log('Archivo CSV generado correctamente:', outputFile);
