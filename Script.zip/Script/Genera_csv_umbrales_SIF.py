import pandas as pd
from pathlib import Path

# country
country = 'BR'

# Ruta del archivo Excel
input_file = Path(f"{country}_volumetry.xlsx")

# Ruta del archivo CSV de salida
output_file = Path(f"{country}_umbrales.csv")

# Leer el Excel
df = pd.read_excel(input_file, sheet_name='Umbrales')

# Obtener nombres de columnas
columns = df.columns.tolist()

# Primera columna: interface_id
interface_column = columns[0]

# Resto de columnas: reference_date
day_columns = columns[1:]

# Lista para almacenar filas del CSV
rows = []

# Transformar los datos
for _, row in df.iterrows():
    interface_id = row[interface_column]

    for day_col in day_columns:
        umbral = row[day_col]

        # Ignorar celdas vacías
        if pd.notna(umbral):
            rows.append({
                "interface_id": interface_id,
                "week_day" : day_col,
                "umbral": umbral * 100
            })

# Crear DataFrame final
result_df = pd.DataFrame(rows, columns=[
    "interface_id",
    "week_day",
    "umbral"
])

# Exportar a CSV
result_df.to_csv(output_file, index=False)

print(f"Archivo CSV generado correctamente: {output_file}")
