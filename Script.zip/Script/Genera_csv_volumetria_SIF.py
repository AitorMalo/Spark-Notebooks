import pandas as pd
from pathlib import Path

# country
country = 'UY'


# Ruta del archivo Excel
input_file = Path(f"{country}_volumetry.xlsx")

# Ruta del archivo CSV de salida
output_file = Path(f"{country}_volumetry.csv")

# Leer el Excel
df = pd.read_excel(input_file)

# Obtener nombres de columnas
columns = df.columns.tolist()

# Primera columna: interface_id
interface_column = columns[0]

# Resto de columnas: reference_date
date_columns = columns[1:]

# Lista para almacenar filas del CSV
rows = []

# Transformar los datos
for _, row in df.iterrows():
    interface_id = row[interface_column]

    for date_col in date_columns:
        volumetry = row[date_col]

        # Ignorar celdas vacías
        if pd.notna(volumetry):
            rows.append({
                "interface_id": interface_id,
                #"reference_date": str(date_col),
                #"reference_date" : pd.to_datetime(date_col).date().isoformat(),
                "reference_date" : pd.to_datetime(date_col,format="%d/%m/%Y").date().isoformat(),
                "volumetry": volumetry
            })

# Crear DataFrame final
result_df = pd.DataFrame(rows, columns=[
    "interface_id",
    "reference_date",
    "volumetry"
])

# Exportar a CSV
result_df.to_csv(output_file, index=False)

print(f"Archivo CSV generado correctamente: {output_file}")
