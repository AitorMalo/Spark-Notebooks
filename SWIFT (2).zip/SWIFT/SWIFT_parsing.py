# Databricks notebook source
# MAGIC %md
# MAGIC ### Import libraries

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ###   Set credentials

# COMMAND ----------

#Credenciales
sec = dbutils.secrets.get("scpcumpsccrit002","gscp1glbsp4cumpscauth100").split("[###]")
client_id = sec[1]
client_secret = sec[0]

client_endpoint = "https://login.microsoftonline.com/35595a02-4d6d-44ac-99e1-f9ab4cd872db/oauth2/token"
 
storage_account = "gscp1weustacumpsccrit100"
 
# Configurar Spark para autenticación OAuth de Azure Data Lake Storage
spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", client_id)
spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", client_secret)
spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", client_endpoint)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import SWIFTUtils

# COMMAND ----------

# MAGIC %run /Workspace/Users/x949854@santanderglobaltech.com/cumplimiento/swift/SWIFTUtils

# COMMAND ----------

# MAGIC %md
# MAGIC ### Constants

# COMMAND ----------

TARGET_SCHEMA_PAYMENTS = StructType([
    StructField("Filename", StringType(), True),
    StructField("Message_Content", StringType(), True),
    StructField("Creation_date", StringType(), True),
    StructField("Direction", StringType(), True),
    StructField("Sender_InstructingAgent_Requestor", StringType(), True),
    StructField("Receiver_InstructedAgent_Responder", StringType(), True),
    StructField("OwnBIC8", StringType(), True),
    StructField("Own_Country", StringType(), True),
    StructField("Role", StringType(), True),
    StructField("Format", StringType(), True),
    StructField("Message_type", StringType(), True),
    StructField("InstructionId", StringType(), True),
    StructField("End2EndId", StringType(), True),
    StructField("UETR", StringType(), True),
    StructField("Related_Message_Id", StringType(), True),
    StructField("Transaction_Reference", StringType(), True),
    StructField("Interbank_Settled_Date", StringType(), True),
    StructField("Interbank_Settled_Currency", StringType(), True),
    StructField("Interbank_Settled_Amount", StringType(), True),
    StructField("Instructed_Currency", StringType(), True),
    StructField("Instructed_Amount", StringType(), True),
    StructField("Ordering_Customer_Account", StringType(), True),
    StructField("Ordering_Customer_Name", StringType(), True),
    StructField("Ordering_Customer_Id", StringType(), True),
    StructField("Ordering_Customer_Address", StringType(), True),
    StructField("Ordering_Customer_Address_Country", StringType(), True),
    StructField("Ordering_Customer_Residence_Country", StringType(), True),
    StructField("Ordering_Customer_Date_Of_Birth", StringType(), True),
    StructField("Ordering_Customer_Place_Of_Birth", StringType(), True),
    StructField("Ordering_Customer_ID_Number", StringType(), True),
    StructField("Ordering_Customer_National_ID_Number", StringType(), True),
    StructField("Ordering_Customer_Id_Additional_Information", DoubleType(), True),
    StructField("Ordering_Institution", StringType(), True),
    StructField("Ordering_Institution_Name", StringType(), True),
    StructField("Ordering_Institution_Address", StringType(), True),
    StructField("Senders_Correspondent", StringType(), True),
    StructField("Senders_Correspondent_Name_and_Address", StringType(), True),
    StructField("Receivers_Correspondent", StringType(), True),
    StructField("Receivers_Correspondent_Name_and_Address", DoubleType(), True),
    StructField("Third_Reimbursement_Institution", DoubleType(), True),
    StructField("Third_Reimbursement_Institution_Name_and_Address", DoubleType(), True),
    StructField("Intermediary_Institution", StringType(), True),
    StructField("Beneficiary_Institution", StringType(), True),
    StructField("Beneficiary_Institution_Name", StringType(), True),
    StructField("Beneficiary_Institution_Address", StringType(), True),
    StructField("Account_With_Institution", StringType(), True),
    StructField("Account_With_Institution_Address", StringType(), True),
    StructField("Account_With_Institution_Name_and_Address", StringType(), True),
    StructField("Beneficiary_Account", StringType(), True),
    StructField("Beneficiary_Name", StringType(), True),
    StructField("Beneficiary_Id", StringType(), True),
    StructField("Beneficiary_Address", StringType(), True),
    StructField("Beneficiary_Address_Country", StringType(), True),
    StructField("Beneficiary_Residence_Country", StringType(), True),
    StructField("Beneficiary_Additional_Information", DoubleType(), True),
    StructField("Remittance_Information", StringType(), True),
    StructField("Narrative", StringType(), True),
    StructField("Sender_to_Receiver_Information", StringType(), True),
    StructField("Clearance_System", StringType(), True),
])

TARGET_SCHEMA_PAYMENTS = {f.name: f.dataType for f in TARGET_SCHEMA_PAYMENTS.fields}

# COMMAND ----------

TARGET_SCHEMA_TRADES = StructType([
    StructField("Filename", StringType(), True),
    StructField("Message_Content", StringType(), True),
    StructField("Creation_date", StringType(), True),
    StructField("Direction", StringType(), True),
    StructField("Sender_InstructingAgent_Requestor", StringType(), True),
    StructField("Receiver_InstructedAgent_Responder", StringType(), True),
    StructField("OwnBIC8", StringType(), True),
    StructField("Own_Country", StringType(), True),
    StructField("Role", StringType(), True),
    StructField("Format", StringType(), True),
    StructField("Message_type", StringType(), True),
    StructField("Type_Purpose", StringType(), True),
    StructField("Senders_Reference", StringType(), True),
    StructField("Receivers_Reference", StringType(), True),
    StructField("Issuing_Banks_Reference", StringType(), True),
    StructField("Issue_Date", StringType(), True),
    StructField("Expiry_Date", StringType(), True),
    StructField("Expiry_Place", StringType(), True),
    StructField("Applicant_Name", StringType(), True),
    StructField("Applicant_Address", StringType(), True),
    StructField("Applicant_Bank", StringType(), True),
    StructField("Applicant_Bank_Name_and_Address", StringType(), True),
    StructField("Instructing_Party", StringType(), True),
    StructField("Issuing_Bank", StringType(), True),
    StructField("Issuing_Bank_Name", StringType(), True),
    StructField("Issuing_Bank_Address", StringType(), True),
    StructField("Beneficiary_Account", StringType(), True),
    StructField("Beneficiary_Name", StringType(), True),
    StructField("Beneficiary_Address", StringType(), True),
    StructField("Currency", StringType(), True),
    StructField("Amount", StringType(), True),
    StructField("Available_Bank", StringType(), True),
    StructField("Available_Bank_Name", StringType(), True),
    StructField("Available_Bank_Address", StringType(), True),
    StructField("Drawee", StringType(), True),
    StructField("Drawee_Name", StringType(), True),
    StructField("Drawee_Address", StringType(), True),
    StructField("Place_Dispatch_Receipt", StringType(), True),
    StructField("PortLoading_AirportDeparture", StringType(), True),
    StructField("PortDischarge_AirportDestination", StringType(), True),
    StructField("Place_Destination_Delivery", StringType(), True),
    StructField("Latest_Date_Shipment", StringType(), True),
    StructField("Description_Goods", StringType(), True),
    StructField("Documents_Required", StringType(), True),
    StructField("Additional_Conditions", StringType(), True),
    StructField("Requested_Confirmation_Party", StringType(), True),
    StructField("Requested_Confirmation_Party_Name", StringType(), True),
    StructField("Requested_Confirmation_Party_Address", StringType(), True),
    StructField("Reimbursing_Bank", StringType(), True),
    StructField("Reimbursing_Bank_Name", StringType(), True),
    StructField("Reimbursing_Bank_Address", StringType(), True),
    StructField("Instructions", StringType(), True),
    StructField("Advising_Bank", StringType(), True),
    StructField("Advising_Bank_Name", StringType(), True),
    StructField("Advising_Bank_Address", StringType(), True),
    StructField("Advise_Through_Bank", StringType(), True),
    StructField("Advise_Through_Bank_Name_and_Address", StringType(), True),
    StructField("Sender_to_Receiver_Information", StringType(), True),
    StructField("Undertaking_Terms", StringType(), True),
    StructField("Transaction_Details", StringType(), True),
    StructField("Local_Type_Purpose", StringType(), True),
    StructField("Local_Applicant_Name", StringType(), True),
    StructField("Local_Applicant_Address", StringType(), True),
    StructField("Local_Beneficiary_Account", StringType(), True),
    StructField("Local_Beneficiary_Name", StringType(), True),
    StructField("Local_Beneficiary_Address", StringType(), True),
    StructField("Local_Currency", StringType(), True),
    StructField("Local_Amount", StringType(), True),
    StructField("Local_Undertaking_Terms", StringType(), True),
    StructField("Local_Transaction_Details", StringType(), True),
    StructField("Narrative", IntegerType(), True),
])

TARGET_SCHEMA_TRADES = {f.name: f.dataType for f in TARGET_SCHEMA_TRADES.fields}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Functions

# COMMAND ----------

def move_batch_parquets_to_batches(base_dir: str, batches_dirname: str = "batches", dry_run: bool = True):
    
    files = dbutils.fs.ls(base_dir)

    batch_files = [
        f for f in files
        if f.name.endswith(".parquet")
        and "_batch_" in f.name
        and ("Payments" in f.name or "Trade" in f.name)
    ]

    if not batch_files:
        print("No se encontraron parquets batch para mover.")
        return

    print(f"Encontrados {len(batch_files)} parquets batch")
    batches_path = f"{base_dir}/{batches_dirname}"
    print(f"Destino batches: {batches_path}")

    if dry_run:
        for f in batch_files[:5]:
            print(f"[DRY-RUN] movería {f.path} -> {batches_path}/{f.name}")
        if len(batch_files) > 5:
            print("...")
        return

    # Crear carpeta batches
    dbutils.fs.mkdirs(batches_path)

    for f in batch_files:
        dest = f"{batches_path}/{f.name}"
        dbutils.fs.mv(f.path, dest)

    print("Movimiento de batches completado.")

# COMMAND ----------

def write_single_parquet_from_batches(prefix: str, final_name: str, tmp_dir: str, TARGET_SCHEMA: dict):

    files = [
        f.path for f in dbutils.fs.ls(batches_dir)
        if f.name.startswith(prefix) and f.name.endswith(".parquet")
    ]

    if not files:
        raise ValueError(f"No se encontraron parquets con prefijo {prefix}")

    print(f"{prefix} files: {len(files)}")

    df_final = None

    for f in files:
        df = spark.read.parquet(f)

        # Normalización de tipos (DESPUÉS de leer)
        for col_name, dtype in TARGET_SCHEMA.items():
            if col_name in df.columns:
                df = df.withColumn(col_name, F.col(col_name).cast(dtype))

        if df_final is None:
            df_final = df
        else:
            df_final = df_final.unionByName(df, allowMissingColumns=True)

    # --- Escritura controlada ---
    tmp_path = f"{base_dir}/{tmp_dir}"
    dbutils.fs.rm(tmp_path, True)

    df_final.coalesce(1).write.mode("overwrite").parquet(tmp_path)

    part = [
        f.path for f in dbutils.fs.ls(tmp_path)
        if f.name.startswith("part-") and f.name.endswith(".parquet")
    ][0]

    final_path = f"{base_dir}/{final_name}"

    try:
        dbutils.fs.rm(final_path, True)
    except Exception:
        pass

    dbutils.fs.mv(part, final_path)
    dbutils.fs.rm(tmp_path, True)

    print(f"OK -> {final_path}")

# COMMAND ----------

def move_file(src, target):
    filename = src.split("/")[-1]
    dest = f"{target}/{filename}"
    
    try:
        dbutils.fs.mv(src, dest)
        return True, src
    except Exception as e:
        return False, (src, str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Parsing

# COMMAND ----------

# 
import os
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from pyspark.sql import SparkSession

import shutil  # local fallback copy

from concurrent.futures import ThreadPoolExecutor, as_completed  # OPTIMIZACIÓN
import gc  # OPTIMIZACIÓN: BATCHING


spark = SparkSession.builder.getOrCreate().newSession()
logger = SWIFTParserLogger.getSWIFTParserLogger('INFO')


def main(adls_input_base_dir: str, adls_output_base_dir: str, date: str, local_dir: str):
    dbutils = get_dbutils(spark)

    #NEW

    def copy_to_staging(local_path: str, staging_dir: str):
            """
            Copy local_path (absolute filesystem path) to staging_dir.
            - Tries dbutils.fs.cp using file: prefix.
            - If that fails, tries to map staging_dir to local fs (/dbfs/...) and uses shutil.copy2.
            - Non-fatal: logs errors but does not raise.
            """
            if not staging_dir:
                logger.debug("No staging_dir provided; skipping staging copy.")
                return

            try:
                local_path = str(local_path)
                base_name = os.path.basename(local_path)
                # Ensure target path in staging
                staging_dir = staging_dir.rstrip('/')
                target_staging_path = f"{staging_dir}/{base_name}"

                # Build a file: URI for dbutils if needed
                local_volume_path = local_path
                if not local_dir.startswith('file:') and not local_dir.startswith('/dbfs'):
                    local_volume_path = f"file:{local_path}"

                # Try dbutils.fs.cp first (works in Databricks for many schemes)
                try:
                    dbutils.fs.cp(local_volume_path, target_staging_path)
                    logger.info(f"Copied to staging with dbutils: {local_volume_path} -> {target_staging_path}")
                    return
                except Exception as e:
                    logger.warning(f"dbutils.fs.cp failed for {local_volume_path} -> {target_staging_path}: {e}")

                # Fallback: try local filesystem mapping (for /dbfs/ or dbfs:/ mapping)
                try:
                    if staging_dir.startswith('/dbfs/'):
                        staging_local_dir = staging_dir
                    elif staging_dir.startswith('dbfs:/'):
                        staging_local_dir = '/dbfs' + staging_dir[len('dbfs:'):]
                    else:
                        staging_local_dir = staging_dir

                    staging_local_path = os.path.join(staging_local_dir, base_name)
                    os.makedirs(os.path.dirname(staging_local_path), exist_ok=True)
                    shutil.copy2(local_dir, staging_local_path)
                    logger.info(f"Copied to staging by shutil: {local_dir} -> {staging_local_path}")
                    return
                except Exception as e:
                    logger.error(f"Fallback copy failed: {local_dir} -> {staging_dir}: {e}")

            except Exception as e:
                logger.error(f"Unexpected error in copy_to_staging for {local_dir} -> {staging_dir}: {e}")

    #NEW_END


    ALL_TAGS = {}
    resultados_MX = {}

    adls_input_dir =  f'{adls_input_base_dir}/{date}'
    adls_output_dir =  f'{adls_output_base_dir}/{date}'
    local_input_dir = f'{local_dir}/swift_parsing/{date}'
    volume_input_dir = f'file:{local_input_dir}'

    local_output_dir = f'{local_dir}/swift_parsing_output/{date}'

    # copiamos los ficheros a directorio volumen
    try:
        dbutils.fs.rm(volume_input_dir, True)
        dbutils.fs.mkdirs(volume_input_dir)
    except Exception as e:
        logger.error(f'Error al borrar directorio {volume_input_dir} {e}')
    dbutils.fs.cp(adls_input_dir, volume_input_dir, recurse=True)


    ficheros_de_datos = os.listdir(Path(local_input_dir))

    if len(ficheros_de_datos) == 0:
        logger.info(f'No hay ficheros de datos en la carpeta: {volume_input_dir}')
        return
    for fichero in ficheros_de_datos:
        csv_procesado = False
        # Lee el primer archivo CSV encontrado
        if fichero.endswith(".csv") and not csv_procesado:
            fechas = pd.read_csv(f'{local_input_dir}/{fichero}')
            # Muestra las primeras filas del DataFrame
            fechas = fechas.rename(columns={'Warehouse ID': 'Filename'})
            fechas = fechas.rename(columns={'Creation date': 'Creation_date'})
        # Procesar el archivo .unknown
        if fichero.endswith(".unknown"): separar_secciones(f'{local_input_dir}/{fichero}')

    # OPTIMIZACIÓN: paralelización del parsing (misma lógica que el bucle secuencial)
    def _process_one(filename):  # OPTIMIZACIÓN
        return ProcessMessage(local_input_dir, filename, date)

    files = os.listdir(Path(local_input_dir))  # OPTIMIZACIÓN

    files_to_process = [
        filename for filename in files
        if not (filename[0] == '.' or filename.endswith(".unknown") or filename.endswith(".csv"))
    ]  # OPTIMIZACIÓN

    max_workers = min(32, (os.cpu_count() or 8) * 2)  # OPTIMIZACIÓN

    # OPTIMIZACIÓN: BATCHING
    BATCH_SIZE = 10000  # OPTIMIZACIÓN: BATCHING

    # OPTIMIZACIÓN: BATCHING
    def chunked(lst, size):  # OPTIMIZACIÓN: BATCHING
        for i in range(0, len(lst), size):
            yield lst[i:i + size]

    os.makedirs(local_output_dir, exist_ok=True)

    # OPTIMIZACIÓN: BATCHING
    for batch_id, batch_files_to_process in enumerate(chunked(files_to_process, BATCH_SIZE)):  # OPTIMIZACIÓN: BATCHING

        with ThreadPoolExecutor(max_workers=max_workers) as executor:  # OPTIMIZACIÓN
            futures = [executor.submit(_process_one, fn) for fn in batch_files_to_process]  # OPTIMIZACIÓN

            for fut in as_completed(futures):  # OPTIMIZACIÓN
                # MISMO comportamiento que antes: si falla, peta aquí
                tags, resultados = fut.result()
                ALL_TAGS.update(tags)
                resultados_MX.update(resultados)

        os.makedirs(local_output_dir, exist_ok=True)
        ruta_archivo_parquet_MT = local_output_dir + '/Payments' + '_' + datetime.now().strftime('%Y%m%d%H%M%S') + f'_batch_{batch_id}' + '.parquet'
        ruta_archivo_parquet_MX = local_output_dir + '/Trade' + '_' + datetime.now().strftime('%Y%m%d%H%M%S') + f'_batch_{batch_id}' + '.parquet'
        ruta_archivo_parquet_completo = local_input_dir + '/All_messages' + '_' + datetime.now().strftime('%Y%m%d%H%M%S') + f'_batch_{batch_id}' + '.parquet'

        if ALL_TAGS:
            data_list_MT = []
            for key, value in ALL_TAGS.items():
                row = {"Filename": key}
                for subkey, subvalue in value.items():
                    if isinstance(subvalue, dict):
                        for subsubkey, subsubvalue in subvalue.items():
                            new_key = f"{subkey}_{subsubkey}"
                            row[new_key] = subsubvalue
                    else:
                        row[subkey] = subvalue
                data_list_MT.append(row)
            df_ALL_TAGS = pd.DataFrame(data_list_MT)
            df_ALL_TAGS = separar_mensajes_101(df_ALL_TAGS)
            df_ALL_TAGS = funciones_complejas(df_ALL_TAGS)
            df_ALL_TAGS = df_ALL_TAGS.replace('\n', ' ', regex=True)
            df_ALL_TAGS['Filename'] = df_ALL_TAGS['Filename'].str.replace('.fin', '')
            fechas_filtradas = fechas[['Filename', 'Creation_date']]
            df_merged = pd.merge(df_ALL_TAGS, fechas_filtradas, on='Filename')
            df_ALL_TAGS_final = cambiar_nombres_direccion(df_merged)
            # df_ALL_TAGS_final.to_parquet(ruta_archivo_parquet_MT,index=False)
            # df_ALL_TAGS_final.to_csv('nombre_del_archivo.csv',index=False, sep=';')

        if resultados_MX:
            data_list_MX = []
            for key, value in resultados_MX.items():
                row = {"Filename": key}
                for subkey, subvalue in value.items():
                    if isinstance(subvalue, dict):
                        for subsubkey, subsubvalue in subvalue.items():
                            new_key = f"{subkey}_{subsubkey}"
                            row[new_key] = subsubvalue
                    else:
                        row[subkey] = subvalue
                data_list_MX.append(row)
            df_resultados_MX = pd.DataFrame(data_list_MX)
            # df_resultados_MX = New_MX_Names.rellenar_nan_con_prefijo(df_resultados_MX)
            df_resultados_MX = rellenar_nan_con_prefijo(df_resultados_MX)
            df_resultados_MX = df_resultados_MX.replace('\n', ' ', regex=True)
            df_resultados_MX['Filename'] = df_resultados_MX['Filename'].str.replace('.xml', '')
            df_merged = pd.merge(df_resultados_MX, fechas, on='Filename', how='left')
            # df_resultados_MX_final = New_MX_Names.cambiar_nombres_MX(df_merged)
            df_resultados_MX_final = cambiar_nombres_MX(df_merged)
            # df_resultados_MX_final.to_parquet(ruta_archivo_parquet_MX,index=False)
            # df_resultados_MX_final.to_csv('prueba.csv',index=False,sep=';')

        if 'df_resultados_MX_final' in locals() and 'df_ALL_TAGS_final' in locals():
            columnas_comunes = df_resultados_MX_final.columns.intersection(df_ALL_TAGS_final.columns).tolist()
            df_juntos = pd.merge(df_resultados_MX_final, df_ALL_TAGS_final, on=columnas_comunes, how='outer')
            representaciones_nulas_1 = ['nan', 'NaN', 'None', ':None', '<NA>', '']
            df_juntos = df_juntos.astype(str)
            df_juntos.replace(representaciones_nulas_1, np.nan, inplace=True)
            df_juntos = df_juntos.replace({'': np.nan, ' ': np.nan})
            df_juntos.to_parquet(ruta_archivo_parquet_completo, index=False)
            # payments = df_juntos[df_juntos['Message_type'].str.startswith(('pacs','camt','1', '2'))]
            payments = df_juntos[
                df_juntos['Message_type'].isin(lista_payments_message_type) | df_juntos['Message_type'].str.startswith(
                    ('pacs', 'camt'))]
            if not payments.empty:
                # payments = payments.dropna(axis=1, how='all')
                payments_final = payments.reindex(columns=lista_payments)
                payments_final.to_parquet(ruta_archivo_parquet_MT, index=False)
                # payments_final.to_csv('payments_final.csv', index=False, sep=';')
                copy_to_staging(ruta_archivo_parquet_MT,adls_output_dir)

            # trade = df_juntos[df_juntos['Message_type'].str.startswith(('7', 'tsrv'))]
            trade = df_juntos[
                df_juntos['Message_type'].isin(lista_trade_message_type) | df_juntos['Message_type'].str.startswith('tsrv')]
            if not trade.empty:
                # trade = trade.dropna(axis=1, how='all')
                trade_final = trade.reindex(columns=lista_trade)
                trade_final.to_parquet(ruta_archivo_parquet_MX, index=False)
                # trade_final.to_csv('trade_final.csv', index=False, sep=';')
                copy_to_staging(ruta_archivo_parquet_MX,adls_output_dir)


        if 'df_ALL_TAGS_final' in locals() and isinstance(locals()['df_ALL_TAGS_final'],
                                                          pd.DataFrame) and 'df_resultados_MX_final' not in locals():
            df_ALL_TAGS_final.to_parquet(ruta_archivo_parquet_completo, index=False)
            representaciones_nulas = ['nan', 'NaN', 'None', ':None', '<NA>', '']
            df_ALL_TAGS_final = df_ALL_TAGS_final.astype(str)
            df_ALL_TAGS_final.replace(representaciones_nulas, np.nan, inplace=True)
            # payments = df_ALL_TAGS_final[df_ALL_TAGS_final['Message_type'].str.startswith(('1', '2'))]
            payments = df_ALL_TAGS_final[
                df_ALL_TAGS_final['Message_type'].isin(lista_payments_message_type) | df_ALL_TAGS_final[
                    'Message_type'].str.startswith(('pacs', 'camt'))]
            if not payments.empty:
                # payments = payments.dropna(axis=1, how='all')
                payments_final = payments.reindex(columns=lista_payments)
                payments_final.to_parquet(ruta_archivo_parquet_MT, index=False)
                copy_to_staging(ruta_archivo_parquet_MT,adls_output_dir)
            # trade = df_ALL_TAGS_final[df_ALL_TAGS_final['Message_type'].str.startswith(('7'))]
            trade = df_ALL_TAGS_final[df_ALL_TAGS_final['Message_type'].isin(lista_trade_message_type) | df_ALL_TAGS_final[
                'Message_type'].str.startswith('tsrv')]
            if not trade.empty:
                # trade = trade.dropna(axis=1, how='all')
                trade_final = trade.reindex(columns=lista_trade)
                trade_final.to_parquet(ruta_archivo_parquet_MX, index=False)
                copy_to_staging(ruta_archivo_parquet_MX,adls_output_dir)

        if 'df_resultados_MX_final' in locals() and isinstance(locals()['df_resultados_MX_final'],
                                                               pd.DataFrame) and 'df_ALL_TAGS_final' not in locals():
            df_resultados_MX_final.to_parquet(ruta_archivo_parquet_completo, index=False)
            representaciones_nulas = ['nan', 'NaN', 'None', ':None', '<NA>', '']
            df_resultados_MX_final = df_resultados_MX_final.astype(str)
            df_resultados_MX_final.replace(representaciones_nulas, np.nan, inplace=True)
            payments = df_resultados_MX_final[df_resultados_MX_final['Message_type'].str.startswith(('pacs', 'camt'))]
            if not payments.empty:
                # payments = payments.dropna(axis=1, how='all')
                payments_final = payments.reindex(columns=lista_payments)
                payments_final.to_parquet(ruta_archivo_parquet_MT, index=False)
                copy_to_staging(ruta_archivo_parquet_MT,adls_output_dir)
            trade = df_resultados_MX_final[df_resultados_MX_final['Message_type'].str.startswith(('tsrv'))]
            if not trade.empty:
                # trade = trade.dropna(axis=1, how='all')
                trade_final = trade.reindex(columns=lista_trade)
                trade_final.to_parquet(ruta_archivo_parquet_MX, index=False)
                copy_to_staging(ruta_archivo_parquet_MX,adls_output_dir)

        # OPTIMIZACIÓN: BATCHING (limpieza para no acumular en driver)
        ALL_TAGS.clear()
        resultados_MX.clear()
        gc.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Capture widget values and check mandatory files

# COMMAND ----------

local_dir = "/tmp/cumplimiento/"

adls_input_base_dir = dbutils.widgets.get("adls_input_base_dir")
adls_output_base_dir = dbutils.widgets.get("adls_output_base_dir")
date = dbutils.widgets.get("date")

# Comprobamos que hay ficheros en la ruta
assert(len(dbutils.fs.ls(adls_input_base_dir + "/" + date)) != 0)

# COMMAND ----------

# MAGIC %md
# MAGIC ### SWIFT parsing execution

# COMMAND ----------

# Ejecutamos main finalmente
main(adls_input_base_dir, adls_output_base_dir, date, local_dir)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Move raw data from ADLS input directory to ADLS output path

# COMMAND ----------

files = dbutils.fs.ls(f'{adls_input_base_dir}/{date}')
paths = [f.path for f in files]
path_adls = f"{adls_output_base_dir}/{date}/raw_data"
print(f"Total de ficheros detectados: {len(paths)}")
paths[:10]

# COMMAND ----------

dbutils.fs.mkdirs(f'{adls_output_base_dir}/{date}/raw_data/')

NUM_THREADS = 75

success = []
errors = []

with ThreadPoolExecutor(max_workers=NUM_THREADS) as executor:
    futures = {executor.submit(move_file, p, path_adls): p for p in paths}

    for fut in as_completed(futures):
        ok, info = fut.result()
        if ok:
            success.append(info)
        else:
            errors.append(info)

print("Copiados OK:", len(success))
print("Errores:", len(errors))

# COMMAND ----------

failed_paths = [src for src, _ in errors]

while len(failed_paths) > 0:

    retry_success = []
    retry_errors = []

    for src in failed_paths:
        ok, info = move_file(src, path_adls)
        if ok:
            retry_success.append(info)
        else:
            retry_errors.append(info)
    
    failed_paths = [src for src, _ in retry_errors]

    print("Copiados OK:", len(retry_success))
    print("Errores:", len(retry_errors))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Unify parquets

# COMMAND ----------

base_dir = f'{adls_output_base_dir}/{date}'

move_batch_parquets_to_batches(base_dir, dry_run=False)

# COMMAND ----------

#Credenciales
sec = dbutils.secrets.get("scpcumpsccrit002","gscp1glbsp4cumpscauth100").split("[###]")
client_id = sec[1]
client_secret = sec[0]

client_endpoint = "https://login.microsoftonline.com/35595a02-4d6d-44ac-99e1-f9ab4cd872db/oauth2/token"
 
storage_account = "gscp1weustacumpsccrit100"
 
# Configurar Spark para autenticación OAuth de Azure Data Lake Storage
spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", client_id)
spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", client_secret)
spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", client_endpoint)

# COMMAND ----------

batches_dir = f"{base_dir}/batches"

# PAYMENTS
write_single_parquet_from_batches("Payments_", "Payments_merged.parquet", "_tmp_payments_merge", TARGET_SCHEMA_PAYMENTS)

# TRADES
write_single_parquet_from_batches("Trade_", "Trade_merged.parquet", "_tmp_trades_merge", TARGET_SCHEMA_TRADES)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Current output directory content

# COMMAND ----------

dbutils.fs.ls(f"{adls_output_base_dir}/{date}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Copy output files to analytic path

# COMMAND ----------

dbutils.fs.mkdirs(f"abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/{date}/")

dbutils.fs.cp(f"{adls_output_base_dir}/{date}/Payments_merged.parquet", f"abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/{date}/Payments_merged.parquet")

dbutils.fs.cp(f"{adls_output_base_dir}/{date}/Trade_merged.parquet",
f"abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/{date}/Trade_merged.parquet")