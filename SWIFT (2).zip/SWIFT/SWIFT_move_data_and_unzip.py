# Databricks notebook source
# MAGIC %md
# MAGIC ## Import libraries

# COMMAND ----------

import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import os

# COMMAND ----------

# MAGIC %md
# MAGIC ## Set credentials

# COMMAND ----------

sec = dbutils.secrets.get("scpcumpsccrit002","gscp1glbsp4cumpscauth100").split("[###]")
client_id = sec[1]
client_secret = sec[0]
client_endpoint = "https://login.microsoftonline.com/35595a02-4d6d-44ac-99e1-f9ab4cd872db/oauth2/token"
storage_account = "gscp1weustacumpsccrit100"
spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", client_id)
spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", client_secret)
spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", client_endpoint)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Capture widgets values

# COMMAND ----------

dbfs_dir = dbutils.widgets.get("dbfs_dir")
adls_output_dir = dbutils.widgets.get("adls_output_dir")
date = dbutils.widgets.get("date")
os.environ["DATE"] = date

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prove that required files exist

# COMMAND ----------

# Nos aseguramos que los ficheros zip y csv asociados a la fecha existen en el directorio
required_files = {f"report_{date}.csv", f"report_{date}.zip"}
files_in_dir = {f.name for f in dbutils.fs.ls(dbfs_dir)}
missing = required_files - files_in_dir
if missing:    raise ValueError(f'The following files are missing: {missing}')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Functions

# COMMAND ----------

def copy_file(src, target):
    filename = src.split("/")[-1]
    dest = f"{target}/{filename}"
    
    try:
        dbutils.fs.cp(src, dest)
        return True, src
    except Exception as e:
        return False, (src, str(e))

# COMMAND ----------

def get_next_pair_version(target_dir, base_name):
    """
    Devuelve el siguiente sufijo disponible para la pareja:
    - report_YYYYMM_<n>.csv
    - report_YYYYMM_<n>.zip

    Se considera ocupada una versión si existe al menos uno de los dos.
    """
    try:
        existing_files = {f.name for f in dbutils.fs.ls(target_dir)}
    except Exception:
        # Si la ruta no existe, la creamos y arrancamos en versión 1
        dbutils.fs.mkdirs(target_dir)
        existing_files = set()

    version = 1

    while True:
        candidate_csv = f"{base_name}_{version}.csv"
        candidate_zip = f"{base_name}_{version}.zip"

        # Si existe cualquiera de los dos, esa versión ya no vale
        if candidate_csv in existing_files or candidate_zip in existing_files:
            version += 1
        else:
            return version

# COMMAND ----------

# MAGIC %md
# MAGIC ### Copy zip file from DBFS to local disk and unzip data

# COMMAND ----------

# Copy report.zip from dbfs to local disk
dbutils.fs.cp(f"dbfs:/FileStore/cumplimiento/swift/report_{date}.zip", f"file:/local_disk0/report_{date}.zip")

# COMMAND ----------

# MAGIC %sh
# MAGIC # Unzip report.zip in local disk
# MAGIC unzip -q /local_disk0/report_${DATE}.zip -d /local_disk0/unzip_tmp

# COMMAND ----------

# MAGIC %md
# MAGIC ### Paths

# COMMAND ----------

path_local_disk = "file:/local_disk0/unzip_tmp"
path_adls = f"{adls_output_dir}/{date}"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Copy unzipped data from local disk to ADLS

# COMMAND ----------

files = dbutils.fs.ls(path_local_disk)
paths = [f.path for f in files]
print(f"Total de ficheros detectados: {len(paths)}")
paths[:10]

# COMMAND ----------

NUM_THREADS = 75

success = []
errors = []

with ThreadPoolExecutor(max_workers=NUM_THREADS) as executor:
    futures = {executor.submit(copy_file, p, path_adls): p for p in paths}

    for fut in as_completed(futures):
        ok, info = fut.result()
        if ok:
            success.append(info)
        else:
            errors.append(info)

print("Copiados OK:", len(success))
print("Errores:", len(errors))

# COMMAND ----------

failed_paths = [src for src, _ in errors]

while len(failed_paths) > 0:

    retry_success = []
    retry_errors = []

    for src in failed_paths:
        ok, info = copy_file(src, path_adls)
        if ok:
            retry_success.append(info)
        else:
            retry_errors.append(info)
    
    failed_paths = [src for src, _ in retry_errors]

    print("Copiados OK:", len(retry_success))
    print("Errores:", len(retry_errors))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Copy report.csv from DBFS to ADLS

# COMMAND ----------

dbutils.fs.cp(f"{dbfs_dir}/report_{date}.csv", f"{adls_output_dir}/{date}/report_{date}.csv")

# COMMAND ----------

print(f"Total de ficheros en la ruta {adls_output_dir}/{date}:", str(len(dbutils.fs.ls(f"{adls_output_dir}/{date}"))))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Move raw data from DBFS to ADLS analytic path

# COMMAND ----------

source_dir = "dbfs:/FileStore/cumplimiento/swift/"
dbutils.fs.mkdirs(f"abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/{date}/")
target_dir = f"abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/{date}/"

date_str = f"{date}"
base_name = f"report_{date_str}"

csv_file = f"{base_name}.csv"
zip_file = f"{base_name}.zip"

version = get_next_pair_version(target_dir, base_name)

source_csv_path = source_dir + csv_file
source_zip_path = source_dir + zip_file

target_csv_path = target_dir + f"{base_name}_{version}.csv"
target_zip_path = target_dir + f"{base_name}_{version}.zip"

dbutils.fs.mv(source_csv_path, target_csv_path)
dbutils.fs.mv(source_zip_path, target_zip_path)

print(f"Copiado {csv_file} -> {base_name}_{version}.csv")
print(f"Copiado {zip_file} -> {base_name}_{version}.zip")