# Databricks notebook source
# MAGIC %md
# MAGIC ### Import libraries

# COMMAND ----------

from pyspark.sql import functions as F
from functools import reduce
from datetime import datetime
from dateutil.relativedelta import relativedelta

# COMMAND ----------

# MAGIC %md
# MAGIC ###   Set credentials

# COMMAND ----------

#Credenciales
sec = dbutils.secrets.get("scpcumpsccrit002","gscp1glbsp4cumpscauth100").split("[###]")
client_id = sec[1]
client_secret = sec[0]

client_endpoint = "https://login.microsoftonline.com/35595a02-4d6d-44ac-99e1-f9ab4cd872db/oauth2/token"

storage_account = "gscp1weustacumpsccrit100"
 
# Configurar Spark para autenticación OAuth de Azure Data Lake Storage
spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", client_id)
spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", client_secret)
spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", client_endpoint)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get Global Variables

# COMMAND ----------

date = dbutils.widgets.get("date")
adls_output_base_dir = dbutils.widgets.get("adls_output_base_dir")
date_prev = datetime.strptime(date, "%Y%m")
date_prev = date_prev - relativedelta(months=1)
date_prev = date_prev.strftime("%Y%m")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Constants

# COMMAND ----------

payments_merged_path = f"{adls_output_base_dir}/{date}/Payments_merged.parquet"
trades_merged_path   = f"{adls_output_base_dir}/{date}/Trade_merged.parquet"
payments_merged_path_prev = f"{adls_output_base_dir}/{date_prev}/Payments_merged.parquet"
trades_merged_path_prev   = f"{adls_output_base_dir}/{date_prev}/Trade_merged.parquet"
VALID_DIRECTIONS = {"Incoming", "Outgoing"}

# Formato REAL: 02-Nov-2025 10:07:06
CREATION_REGEX = r"^\d{2}-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-\d{4} \d{2}:\d{2}:\d{2}$"

# Columnas reales
COL_SENDER    = "Sender_InstructingAgent_Requestor"
COL_RECEIVER  = "Receiver_InstructedAgent_Responder"
COL_OWNBIC8   = "OwnBIC8"
COL_DIRECTION = "Direction"
COL_MSGTYPE   = "Message_type"
COL_CREATION  = "Creation_date"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Functions

# COMMAND ----------

def build_single_file_report(parquet_path: str):

    df = spark.read.parquet(parquet_path)

    def null_count(col):
        return F.sum(F.when(F.col(col).isNull(), 1).otherwise(0))

    # Direction inválida (nulo o fuera de dominio)
    direction_invalid_count = F.sum(
        F.when(F.col(COL_DIRECTION).isNull(), 1)
         .when(~F.upper(F.col(COL_DIRECTION)).isin([d.upper() for d in VALID_DIRECTIONS]), 1)
         .otherwise(0)
    )

    # Creation_date inválida según formato REAL
    creation_str = F.trim(F.col(COL_CREATION).cast("string"))

    creation_not_valid_count = F.sum(
        F.when(
            F.col(COL_CREATION).isNotNull() &
            (~creation_str.rlike(CREATION_REGEX)),
            1
        ).otherwise(0)
    )

    return df.agg(
        F.lit(parquet_path).alias("File_name"),
        F.count("*").alias("df_count"),
        null_count(COL_SENDER).alias("Sender_null"),
        null_count(COL_RECEIVER).alias("Receiver_null"),
        null_count(COL_OWNBIC8).alias("OwnBIC8_null"),
        direction_invalid_count.alias("Direction"),
        null_count(COL_MSGTYPE).alias("Message_type_null"),
        null_count(COL_CREATION).alias("Creation_date_null"),
        creation_not_valid_count.alias("Creation_date_not_valid_format"),
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Build Report

# COMMAND ----------

report_df = reduce(
    lambda a, b: a.unionByName(b),
    [
        build_single_file_report(payments_merged_path),
        build_single_file_report(trades_merged_path),
        # build_single_file_report(payments_merged_path_prev),
        # build_single_file_report(trades_merged_path_prev)
    ]
)

display(report_df)

# COMMAND ----------

dbutils.fs.ls(f'abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/202110')

# COMMAND ----------

dbutils.fs.ls(f'abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/swift/output')

# COMMAND ----------

dbutils.fs.rm(f"dbfs:/FileStore/cumplimiento/swift/202212")

# COMMAND ----------

print(payments_merged_path)
spark.read.parquet(f'abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/swift/output/{date}/Payments_merged.parquet').groupBy('OwnBIC8').count().show()
spark.read.parquet(f'abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/{date}/Payments_merged.parquet').groupBy('OwnBIC8').count().show()
if date == "202506" or date == "202509" or date == "202511" or date == "202512" or date == "202601" or date == "202602" or date == "202603":
    spark.read.parquet(f'abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/{date}/Payments_merged.parquet').groupBy('OwnBIC8').count().show()
else:
    spark.read.parquet(f'abfss://work-cumplimiento@gscp1weustacumpsccrit100.dfs.core.windows.net/cumplimiento/11_SWIFT_Global/{date}/Payments_merged_TOTAPTPL.parquet').groupBy('OwnBIC8').count().show()