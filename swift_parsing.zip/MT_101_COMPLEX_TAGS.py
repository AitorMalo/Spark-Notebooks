import re

def complex_tags(diccionario):
    for clave, valores in diccionario.items():
        if 'Message_Index/Total_28D' in valores:
            pattern = re.compile(r'^(?P<Message_Index>.*?)/(?P<Total>.*)$')
            Message_Index_Total_28D = valores['Message_Index/Total_28D']
            match = pattern.match(Message_Index_Total_28D)
            Message_Index_Total_28D = {}
            if match:
                Message_Index_Total_28D['Message_Index'] = match.group('Message_Index')
                Message_Index_Total_28D['Total'] = match.group('Total')
            if Message_Index_Total_28D:
                valores['Message_Index/Total_28D'] = Message_Index_Total_28D
                              
        if 'Ordering_Customer_50F' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>[^\n]+)\n(?P<Name_number_and_Address>[\s\S]*)$')
            Ordering_Customer_50F = valores['Ordering_Customer_50F']
            match = pattern.match(Ordering_Customer_50F)
            Ordering_Customer_50F = {}
            if match:
                Ordering_Customer_50F['Party_Identifier'] = match.group('Party_Identifier')
                Ordering_Customer_50F['Number_Name_and_Address'] = match.group('Name_number_and_Address')
            if Ordering_Customer_50F:
                valores['Ordering_Customer_50F'] = Ordering_Customer_50F
                
        if 'Ordering_Customer_50G' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Ordering_Customer_50G = valores['Ordering_Customer_50G']
            match = pattern.match(Ordering_Customer_50G)
            Ordering_Customer_50G = {}
            if match:
                Ordering_Customer_50G['Account'] = match.group('Account')
                Ordering_Customer_50G['Identifier_Code'] = match.group('Identifier_Code')
            if Ordering_Customer_50G:
                valores['Ordering_Customer_50G'] = Ordering_Customer_50G
        
        if 'Ordering_Customer_50H' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Ordering_Customer_50H = valores['Ordering_Customer_50H']
            match = pattern.match(Ordering_Customer_50H)
            Ordering_Customer_50H = {}
            if match:
                Ordering_Customer_50H['Account'] = match.group('Account')
                Ordering_Customer_50H['Name_and_Address'] = match.group('Name_and_Address')
            if Ordering_Customer_50H:
                valores['Ordering_Customer_50H'] = Ordering_Customer_50H
                    
        if 'Account_Servicing_Institution_52A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Account_Servicing_Institution_52A = valores['Account_Servicing_Institution_52A']
            match = pattern.match(Account_Servicing_Institution_52A)
            Account_Servicing_Institution_52A = {}
            if match:
                Account_Servicing_Institution_52A['Party_Identifier'] = match.group('Party_Identifier')
                Account_Servicing_Institution_52A['Identifier_Code'] = match.group('Identifier_Code') 
            else:
                Account_Servicing_Institution_52A['Party_Identifier'] = None
                Account_Servicing_Institution_52A['Identifier_Code'] = valores['Account_Servicing_Institution_52A'] 
            if Account_Servicing_Institution_52A:
                valores['Account_Servicing_Institution_52A'] = Account_Servicing_Institution_52A
                
        if 'Sending_Institution_51A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Sending_Institution_51A = valores['Sending_Institution_51A']
            match = pattern.match(Sending_Institution_51A)
            Sending_Institution_51A = {}
            if match:
                Sending_Institution_51A['Party_Identifier'] = match.group('Party_Identifier')
                Sending_Institution_51A['Identifier_Code'] = match.group('Identifier_Code') 
            else:
                Sending_Institution_51A['Party_Identifier'] = None
                Sending_Institution_51A['Identifier_Code'] = valores['Sending_Institution_51A'] 
            if Sending_Institution_51A:
                valores['Sending_Institution_51A'] = Sending_Institution_51A
                
        if 'Instruction_Code_23E' in valores:
            pattern = re.compile(r'^(?P<Instruction_Code>.{4})(?P<Additional_Information>.*)$')
            Instruction_Code_23E = valores['Instruction_Code_23E']
            match = pattern.match(Instruction_Code_23E)
            Instruction_Code_23E = {}
            if match:
                Instruction_Code_23E['Instruction_Code'] = match.group('Instruction_Code')
                Instruction_Code_23E['Additional_Information'] = match.group('Additional_Information') 
            if Instruction_Code_23E:
                valores['Instruction_Code_23E'] = Instruction_Code_23E
                
        if 'Currency/Transaction_Amount_32B' in valores:
            pattern = re.compile(r'^(?P<Currency>[A-Z]{3})(?P<Amount>.+)$')
            Currency_Transaction_Amount_32B = valores['Currency/Transaction_Amount_32B']
            match = pattern.match(Currency_Transaction_Amount_32B)
            Currency_Transaction_Amount_32B = {}
            if match:
                Currency_Transaction_Amount_32B['Currency'] = match.group('Currency')
                Currency_Transaction_Amount_32B['Amount'] = match.group('Amount') 
            if Currency_Transaction_Amount_32B:
                valores['Currency/Transaction_Amount_32B'] = Currency_Transaction_Amount_32B
                
        if 'Intermediary_56A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Intermediary_56A = valores['Intermediary_56A']
            match = pattern.match(Intermediary_56A)
            Intermediary_56A = {}
            if match:
                Intermediary_56A['Party_Identifier'] = match.group('Party_Identifier')
                Intermediary_56A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Intermediary_56A['Party_Identifier'] = None
                Intermediary_56A['Identifier_Code'] = valores['Intermediary_56A']
            if Intermediary_56A:
                valores['Intermediary_56A'] = Intermediary_56A
                
        if 'Intermediary_56D' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Intermediary_56D = valores['Intermediary_56D']
            match = pattern.match(Intermediary_56D)
            Intermediary_56D = {}
            if match:
                Intermediary_56D['Party_Identifier'] = match.group('Party_Identifier')
                Intermediary_56D['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Intermediary_56D['Party_Identifier'] = None
                Intermediary_56D['Name_and_Address'] = valores['Intermediary_56D']
            if Intermediary_56D:
                valores['Intermediary_56D'] = Intermediary_56D
                
        if 'Account_With_Institution_57A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Account_With_Institution_57A = valores['Account_With_Institution_57A']
            match = pattern.match(Account_With_Institution_57A)
            Account_With_Institution_57A = {}
            if match:
                Account_With_Institution_57A['Party_Identifier'] = match.group('Party_Identifier')
                Account_With_Institution_57A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Account_With_Institution_57A['Party_Identifier'] = None
                Account_With_Institution_57A['Identifier_Code'] = valores['Account_With_Institution_57A']
            if Account_With_Institution_57A:
                valores['Account_With_Institution_57A'] = Account_With_Institution_57A
                
        if 'Account_With_Institution_57D' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Account_With_Institution_57D = valores['Account_With_Institution_57D']
            match = pattern.match(Account_With_Institution_57D)
            Account_With_Institution_57D = {}
            if match:
                Account_With_Institution_57D['Party_Identifier'] = match.group('Party_Identifier')
                Account_With_Institution_57D['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Account_With_Institution_57D['Party_Identifier'] = None
                Account_With_Institution_57D['Name_and_Address'] = valores['Account_With_Institution_57D']
            if Account_With_Institution_57D:
                valores['Account_With_Institution_57D'] = Account_With_Institution_57D
                
        if 'Beneficiary_59' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Beneficiary_59 = valores['Beneficiary_59']
            match = pattern.match(Beneficiary_59)
            Beneficiary_59 = {}
            if match:
                Beneficiary_59['Account'] = match.group('Account')
                Beneficiary_59['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Beneficiary_59['Account'] = None
                Beneficiary_59['Name_and_Address'] = valores['Beneficiary_59']
            if Beneficiary_59:
                valores['Beneficiary_59'] = Beneficiary_59
                
        if 'Beneficiary_59A' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Beneficiary_59A = valores['Beneficiary_59A']
            match = pattern.match(Beneficiary_59A)
            Beneficiary_59A = {}
            if match:
                Beneficiary_59A['Account'] = match.group('Account')
                Beneficiary_59A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Beneficiary_59A['Account'] = None
                Beneficiary_59A['Identifier_Code'] = valores['Beneficiary_59A']
            if Beneficiary_59A:
                valores['Beneficiary_59A'] = Beneficiary_59A
                
        if 'Beneficiary_59F' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Number_Name_and_Address>[\s\S]*))?$')
            Beneficiary_59F = valores['Beneficiary_59F']
            match = pattern.match(Beneficiary_59F)
            Beneficiary_59F = {}
            if match:
                Beneficiary_59F['Account'] = match.group('Account')
                Beneficiary_59F['Number_Name_and_Address'] = match.group('Number_Name_and_Address')
            else:
                Beneficiary_59F['Account'] = None
                Beneficiary_59F['Number_Name_and_Address'] = valores['Beneficiary_59F']
            if Beneficiary_59F:
                valores['Beneficiary_59F'] = Beneficiary_59F
        
        if 'Currency/Original_Ordered_Amount_33B' in valores:
            pattern = re.compile(r'^(?P<Currency>[A-Z]{3})(?P<Amount>.+)$')
            Currency_Original_Ordered_Amount_33B = valores['Currency/Original_Ordered_Amount_33B']
            match = pattern.match(Currency_Original_Ordered_Amount_33B)
            Currency_Original_Ordered_Amount_33B = {}
            if match:
                Currency_Original_Ordered_Amount_33B['Currency'] = match.group('Currency')
                Currency_Original_Ordered_Amount_33B['Amount'] = match.group('Amount') 
            if Currency_Original_Ordered_Amount_33B:
                valores['Currency/Original_Ordered_Amount_33B'] = Currency_Original_Ordered_Amount_33B
       #########################################################################################
        for i in range(11):  # Se itera desde 0 hasta 10 inclusive
            nombre = f'Message_Index/Total_28D_{i}' 
            nombre1 = f'Ordering_Customer_50F_{i}'    
            nombre2 = f'Ordering_Customer_50G_{i}'
            nombre3 = f'Ordering_Customer_50H_{i}'  
            nombre4 = f'Account_Servicing_Institution_52A_{i}'  
            nombre5 = f'Sending_Institution_51A_{i}'  
            nombre6 = f'Instruction_Code_23E_{i}'
            nombre7 = f'Currency/Transaction_Amount_32B_{i}'  
            nombre8 = f'Intermediary_56A_{i}'  
            nombre9 = f'Intermediary_56D_{i}' 
            nombre10 = f'Account_With_Institution_57A_{i}'
            nombre11 = f'Account_With_Institution_57D_{i}'  
            nombre12 = f'Beneficiary_59_{i}'  
            nombre13 = f'Beneficiary_59A_{i}' 
            nombre14 = f'Beneficiary_59F_{i}'
            nombre15 = f'Currency/Original_Ordered_Amount_33B_1{i}'  


            if nombre in valores:
                pattern = re.compile(r'^(?P<Message_Index>.*?)/(?P<Total>.*)$')
                Message_Index_Total_28D = valores[nombre]
                match = pattern.match(Message_Index_Total_28D)
                Message_Index_Total_28D = {}
                if match:
                    Message_Index_Total_28D['Message_Index'] = match.group('Message_Index')
                    Message_Index_Total_28D['Total'] = match.group('Total')
                if Message_Index_Total_28D:
                    valores[nombre] = Message_Index_Total_28D
                                
            if nombre1 in valores:
                pattern = re.compile(r'^(?P<Party_Identifier>[^\n]+)\n(?P<Name_number_and_Address>[\s\S]*)$')
                Ordering_Customer_50F = valores[nombre1]
                match = pattern.match(Ordering_Customer_50F)
                Ordering_Customer_50F = {}
                if match:
                    Ordering_Customer_50F['Party_Identifier'] = match.group('Party_Identifier')
                    Ordering_Customer_50F['Number_Name_and_Address'] = match.group('Name_number_and_Address')
                if Ordering_Customer_50F:
                    valores[nombre1] = Ordering_Customer_50F
                    
            if nombre2 in valores:
                pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
                Ordering_Customer_50G = valores[nombre2]
                match = pattern.match(Ordering_Customer_50G)
                Ordering_Customer_50G = {}
                if match:
                    Ordering_Customer_50G['Account'] = match.group('Account')
                    Ordering_Customer_50G['Identifier_Code'] = match.group('Identifier_Code')
                if Ordering_Customer_50G:
                    valores[nombre2] = Ordering_Customer_50G
            
            if nombre3 in valores:
                pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
                Ordering_Customer_50H = valores[nombre3]
                match = pattern.match(Ordering_Customer_50H)
                Ordering_Customer_50H = {}
                if match:
                    Ordering_Customer_50H['Account'] = match.group('Account')
                    Ordering_Customer_50H['Name_and_Address'] = match.group('Name_and_Address')
                if Ordering_Customer_50H:
                    valores[nombre3] = Ordering_Customer_50H
                        
            if nombre4 in valores:
                pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
                Account_Servicing_Institution_52A = valores[nombre4]
                match = pattern.match(Account_Servicing_Institution_52A)
                Account_Servicing_Institution_52A = {}
                if match:
                    Account_Servicing_Institution_52A['Party_Identifier'] = match.group('Party_Identifier')
                    Account_Servicing_Institution_52A['Identifier_Code'] = match.group('Identifier_Code') 
                else:
                    Account_Servicing_Institution_52A['Party_Identifier'] = None
                    Account_Servicing_Institution_52A['Identifier_Code'] = valores[nombre4] 
                if Account_Servicing_Institution_52A:
                    valores[nombre4] = Account_Servicing_Institution_52A
                    
            if nombre5 in valores:
                pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
                Sending_Institution_51A = valores[nombre5]
                match = pattern.match(Sending_Institution_51A)
                Sending_Institution_51A = {}
                if match:
                    Sending_Institution_51A['Party_Identifier'] = match.group('Party_Identifier')
                    Sending_Institution_51A['Identifier_Code'] = match.group('Identifier_Code') 
                else:
                    Sending_Institution_51A['Party_Identifier'] = None
                    Sending_Institution_51A['Identifier_Code'] = valores[nombre5] 
                if Sending_Institution_51A:
                    valores[nombre5] = Sending_Institution_51A
                    
            if nombre6 in valores:
                pattern = re.compile(r'^(?P<Instruction_Code>.{4})(?P<Additional_Information>.*)$')
                Instruction_Code_23E = valores[nombre6]
                match = pattern.match(Instruction_Code_23E)
                Instruction_Code_23E = {}
                if match:
                    Instruction_Code_23E['Instruction_Code'] = match.group('Instruction_Code')
                    Instruction_Code_23E['Additional_Information'] = match.group('Additional_Information') 
                if Instruction_Code_23E:
                    valores[nombre6] = Instruction_Code_23E
                    
            if nombre7 in valores:
                pattern = re.compile(r'^(?P<Currency>[A-Z]{3})(?P<Amount>[0-9,.]+)')
                Currency_Transaction_Amount_32B = valores[nombre7]
                match = pattern.match(Currency_Transaction_Amount_32B)
                Currency_Transaction_Amount_32B = {}
                if match:
                    Currency_Transaction_Amount_32B['Currency'] = match.group('Currency')
                    Currency_Transaction_Amount_32B['Amount'] = match.group('Amount') 
                if Currency_Transaction_Amount_32B:
                    valores[nombre7] = Currency_Transaction_Amount_32B
                    
            if nombre8 in valores:
                pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
                Intermediary_56A = valores[nombre8]
                match = pattern.match(Intermediary_56A)
                Intermediary_56A = {}
                if match:
                    Intermediary_56A['Party_Identifier'] = match.group('Party_Identifier')
                    Intermediary_56A['Identifier_Code'] = match.group('Identifier_Code')
                else:
                    Intermediary_56A['Party_Identifier'] = None
                    Intermediary_56A['Identifier_Code'] = valores[nombre8]
                if Intermediary_56A:
                    valores[nombre8] = Intermediary_56A
                    
            if nombre9 in valores:
                pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
                Intermediary_56D = valores[nombre9]
                match = pattern.match(Intermediary_56D)
                Intermediary_56D = {}
                if match:
                    Intermediary_56D['Party_Identifier'] = match.group('Party_Identifier')
                    Intermediary_56D['Name_and_Address'] = match.group('Name_and_Address')
                else:
                    Intermediary_56D['Party_Identifier'] = None
                    Intermediary_56D['Name_and_Address'] = valores[nombre9]
                if Intermediary_56D:
                    valores[nombre9] = Intermediary_56D
                    
            if nombre10 in valores:
                pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
                Account_With_Institution_57A = valores[nombre10]
                match = pattern.match(Account_With_Institution_57A)
                Account_With_Institution_57A = {}
                if match:
                    Account_With_Institution_57A['Party_Identifier'] = match.group('Party_Identifier')
                    Account_With_Institution_57A['Identifier_Code'] = match.group('Identifier_Code')
                else:
                    Account_With_Institution_57A['Party_Identifier'] = None
                    Account_With_Institution_57A['Identifier_Code'] = valores[nombre10]
                if Account_With_Institution_57A:
                    valores[nombre10] = Account_With_Institution_57A
                    
            if nombre11 in valores:
                pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
                Account_With_Institution_57D = valores[nombre11]
                match = pattern.match(Account_With_Institution_57D)
                Account_With_Institution_57D = {}
                if match:
                    Account_With_Institution_57D['Party_Identifier'] = match.group('Party_Identifier')
                    Account_With_Institution_57D['Name_and_Address'] = match.group('Name_and_Address')
                else:
                    Account_With_Institution_57D['Party_Identifier'] = None
                    Account_With_Institution_57D['Name_and_Address'] = valores[nombre11]
                if Account_With_Institution_57D:
                    valores[nombre11] = Account_With_Institution_57D
                    
            if nombre12 in valores:
                pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
                Beneficiary_59 = valores[nombre12]
                match = pattern.match(Beneficiary_59)
                Beneficiary_59 = {}
                if match:
                    Beneficiary_59['Account'] = match.group('Account')
                    Beneficiary_59['Name_and_Address'] = match.group('Name_and_Address')
                else:
                    Beneficiary_59['Account'] = None
                    Beneficiary_59['Name_and_Address'] = valores[nombre12]
                if Beneficiary_59:
                    valores[nombre12] = Beneficiary_59
                    
            if nombre13 in valores:
                pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
                Beneficiary_59A = valores[nombre13]
                match = pattern.match(Beneficiary_59A)
                Beneficiary_59A = {}
                if match:
                    Beneficiary_59A['Account'] = match.group('Account')
                    Beneficiary_59A['Identifier_Code'] = match.group('Identifier_Code')
                else:
                    Beneficiary_59A['Account'] = None
                    Beneficiary_59A['Identifier_Code'] = valores[nombre13]
                if Beneficiary_59A:
                    valores[nombre13] = Beneficiary_59A
                    
            if nombre14 in valores:
                pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Number_Name_and_Address>[\s\S]*))?$')
                Beneficiary_59F = valores[nombre14]
                match = pattern.match(Beneficiary_59F)
                Beneficiary_59F = {}
                if match:
                    Beneficiary_59F['Account'] = match.group('Account')
                    Beneficiary_59F['Number_Name_and_Address'] = match.group('Number_Name_and_Address')
                else:
                    Beneficiary_59F['Account'] = None
                    Beneficiary_59F['Number_Name_and_Address'] = valores[nombre14]
                if Beneficiary_59F:
                    valores[nombre14] = Beneficiary_59F
            
            if nombre15 in valores:
                pattern = re.compile(r'^(?P<Currency>[A-Z]{3})(?P<Amount>.+)$')
                Currency_Original_Ordered_Amount_33B = valores[nombre15]
                match = pattern.match(Currency_Original_Ordered_Amount_33B)
                Currency_Original_Ordered_Amount_33B = {}
                if match:
                    Currency_Original_Ordered_Amount_33B['Currency'] = match.group('Currency')
                    Currency_Original_Ordered_Amount_33B['Amount'] = match.group('Amount') 
                if Currency_Original_Ordered_Amount_33B:
                    valores[nombre15] = Currency_Original_Ordered_Amount_33B
    return diccionario