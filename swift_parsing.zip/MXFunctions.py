import xml.etree.ElementTree as ET

####################################################################################################################################################
## Funcion 1: FUNCIÓN PARA SACAR TODO EL CONTENIDO DE LOS MENSAJES MX 
## ------------------------------------------------------------
## Esta función recibe un elemento XML y devuelve un diccionario que contiene los valores junto con sus etiquetas y atributos correspondientes
## Recorre de manera recursiva la estructura del XML, extrayendo valores de texto, nombres de etiquetas y atributos, y los almacena en un diccionario.
## Se aplica en la funcion ProcessMessage en initialFunctions.py
#####################################################################################################################################################

def extract_values_with_tags_and_attributes(element, parent_tags=None):
    if parent_tags is None:
        parent_tags = []

    result = {}

    # Handle XML namespaces
    ns_prefix = element.tag.split('}')[0][1:]
    ns = {'': ns_prefix}

    for child in element:
        child_tags = parent_tags + [child.tag.replace('{' + ns_prefix + '}', '')]
        child_name = '_'.join(child_tags)

        # Eliminar prefijos 'Header_AppHdr_' y 'Document_'
        child_name = child_name.replace('Header_', '').replace('Document_', '').replace('AppHdr_', '')

        if 'Body_{' in child_name:
            child_name = child_name.split('Body_{')[0] + child_name.split('}')[1]
        # Extract attributes
        for attr_key, attr_value in child.attrib.items():
            attr_name = f"{child_name}_{attr_key}"
            result[attr_name] = attr_value

        # Recursively call the function for child elements
        result.update(extract_values_with_tags_and_attributes(child, child_tags))

        # Extract text content if present
        if child.text is not None and child.text.strip() != "":
            text_name = f"{child_name}"
            try:
                # Intentar agregar el valor a la lista existente
                result[text_name].append(child.text.strip())
            except KeyError:
                # Si la clave no existe, crearla con el valor en una lista
                result[text_name] = [child.text.strip()]

    return result

####################################################################################################################################################
## Funcion 2: FUNCIÓN PARA "APLANAR" LAS LISTAS DENTRO DEL DICCIONARIO  
## ------------------------------------------------------------
## Si encuentra algún valor que sea una lista, convierte esa lista en una cadena de texto concatenando todos los elementos de la lista con un espacio como separador
## Se aplica en la funcion ProcessMessage en initialFunctions.py
#####################################################################################################################################################

def flatten_lists(result):
    flattened_result = {}

    for key, value in result.items():
        if isinstance(value, list):
            # Si el valor es una lista, convierte a una cadena uniendo los elementos con un espacio
            flattened_result[key] = ' '.join(map(str, value))
        else:
            # Si no es una lista, deja el valor como está
            flattened_result[key] = value

    return flattened_result

####################################################################################################################################################
## Funcion 3: FUNCIÓN PARA SACAR EL CONTENIDO COMPLETO DEL MENSAJE   
## ------------------------------------------------------------
## Se aplica en la funcion ProcessMessage en initialFunctions.py
#####################################################################################################################################################

def obtener_contenido(elemento):
    contenido = ET.tostring(elemento, encoding='unicode', method='xml')
    return ''.join(contenido.split())