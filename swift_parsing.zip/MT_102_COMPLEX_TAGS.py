import re

def complex_tags(diccionario):
    for clave, valores in diccionario.items():
        if 'Sending_Institution_51A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Sending_Institution_51A = valores['Sending_Institution_51A']
            match = pattern.match(Sending_Institution_51A)
            Sending_Institution_51A = {}
            if match:
                Sending_Institution_51A['Party_Identifier'] = match.group('Party_Identifier')
                Sending_Institution_51A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Sending_Institution_51A['Party_Identifier'] = None
                Sending_Institution_51A['Identifier_Code'] = valores['Sending_Institution_51A'] 
            if Sending_Institution_51A:
                valores['Sending_Institution_51A'] = Sending_Institution_51A
                
        if 'Ordering_Customer_50A' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Ordering_Customer_50A = valores['Ordering_Customer_50A']
            match = pattern.match(Ordering_Customer_50A)
            Ordering_Customer_50A = {}
            if match:
                Ordering_Customer_50A['Account'] = match.group('Account')
                Ordering_Customer_50A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Ordering_Customer_50A['Account'] = None
                Ordering_Customer_50A['Identifier_Code'] = valores['Ordering_Customer_50A'] 
            if Ordering_Customer_50A:
                valores['Ordering_Customer_50A'] = Ordering_Customer_50A
            
        if 'Ordering_Customer_50F' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>[^\n]+)\n(?P<Name_number_and_Address>[\s\S]*)$')
            Ordering_Customer_50F = valores['Ordering_Customer_50F']
            match = pattern.match(Ordering_Customer_50F)
            Ordering_Customer_50F = {}
            if match:
                Ordering_Customer_50F['Party_Identifier'] = match.group('Party_Identifier')
                Ordering_Customer_50F['Number/Name_and_Address'] = match.group('Name_number_and_Address')
            if Ordering_Customer_50F:
                valores['Ordering_Customer_50F'] = Ordering_Customer_50F
        
        if 'Ordering_Customer_50K' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Ordering_Customer_50K = valores['Ordering_Customer_50K']
            match = pattern.match(Ordering_Customer_50K)
            Ordering_Customer_50K = {}
            if match:
                Ordering_Customer_50K['Account'] = match.group('Account')
                Ordering_Customer_50K['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Ordering_Customer_50K['Account'] = None
                Ordering_Customer_50K['Name_and_Address'] = valores['Ordering_Customer_50K'] 
            if Ordering_Customer_50K:
                valores['Ordering_Customer_50K'] = Ordering_Customer_50K
                       
        if 'Ordering_Institution_52A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Ordering_Institution_52A = valores['Ordering_Institution_52A']
            match = pattern.match(Ordering_Institution_52A)
            Ordering_Institution_52A = {}
            if match:
                Ordering_Institution_52A['Party_Identifier'] = match.group('Party_Identifier')
                Ordering_Institution_52A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Ordering_Institution_52A['Party_Identifier'] = None
                Ordering_Institution_52A['Identifier_Code'] = valores['Ordering_Institution_52A'] 
            if Ordering_Institution_52A:
                valores['Ordering_Institution_52A'] = Ordering_Institution_52A
                
        if 'Ordering_Institution_52B' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Location>[\s\S]*))?$')
            Ordering_Institution_52B = valores['Ordering_Institution_52B']
            match = pattern.match(Ordering_Institution_52B)
            Ordering_Institution_52B = {}
            if match:
                Ordering_Institution_52B['Party_Identifier'] = match.group('Party_Identifier')
                Ordering_Institution_52B['Location'] = match.group('Location')
            else:
                Ordering_Institution_52B['Party_Identifier'] = None
                Ordering_Institution_52B['Location'] = valores['Ordering_Institution_52B'] 
            if Ordering_Institution_52B:
                valores['Ordering_Institution_52B'] = Ordering_Institution_52B
            
        if 'Transaction_Amount_32B' in valores:
            pattern = re.compile(r'^(?P<Currency>[A-Z]{3})(?P<Amount>.+)$')
            Transaction_Amount_32B = valores['Transaction_Amount_32B']
            match = pattern.match(Transaction_Amount_32B)
            Transaction_Amount_32B = {}
            if match:
                Transaction_Amount_32B['Currency'] = match.group('Currency')
                Transaction_Amount_32B['Amount'] = match.group('Amount') 
            if Transaction_Amount_32B:
                valores['Transaction_Amount_32B'] = Transaction_Amount_32B
            
        if 'Account_With_Institution_57A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Account_With_Institution_57A = valores['Account_With_Institution_57A']
            match = pattern.match(Account_With_Institution_57A)
            Account_With_Institution_57A = {}
            if match:
                Account_With_Institution_57A['Party_Identifier'] = match.group('Party_Identifier')
                Account_With_Institution_57A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Account_With_Institution_57A['Party_Identifier'] = None
                Account_With_Institution_57A['Identifier_Code'] = valores['Account_With_Institution_57A']
            if Account_With_Institution_57A:
                valores['Account_With_Institution_57A'] = Account_With_Institution_57A
                       
        if 'Beneficiary_Customer_59' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Beneficiary_Customer_59 = valores['Beneficiary_Customer_59']
            match = pattern.match(Beneficiary_Customer_59)
            Beneficiary_Customer_59 = {}
            if match:
                Beneficiary_Customer_59['Account'] = match.group('Account')
                Beneficiary_Customer_59['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Beneficiary_Customer_59['Account'] = None
                Beneficiary_Customer_59['Name_and_Address'] = valores['Beneficiary_Customer_59']
            if Beneficiary_Customer_59:
                valores['Beneficiary_Customer_59'] = Beneficiary_Customer_59
                
        if 'Beneficiary_Customer_59A' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Beneficiary_Customer_59A = valores['Beneficiary_Customer_59A']
            match = pattern.match(Beneficiary_Customer_59A)
            Beneficiary_Customer_59A = {}
            if match:
                Beneficiary_Customer_59A['Account'] = match.group('Account')
                Beneficiary_Customer_59A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Beneficiary_Customer_59A['Account'] = None
                Beneficiary_Customer_59A['Identifier_Code'] = valores['Beneficiary_Customer_59A']
            if Beneficiary_Customer_59A:
                valores['Beneficiary_Customer_59A'] = Beneficiary_Customer_59A
                
        if 'Beneficiary_Customer_59F' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Number_Name_and_Address>[\s\S]*))?$')
            Beneficiary_Customer_59F = valores['Beneficiary_Customer_59F']
            match = pattern.match(Beneficiary_Customer_59F)
            Beneficiary_Customer_59F = {}
            if match:
                Beneficiary_Customer_59F['Account'] = match.group('Account')
                Beneficiary_Customer_59F['Number_Name_and_Address'] = match.group('Number_Name_and_Address')
            else:
                Beneficiary_Customer_59F['Account'] = None
                Beneficiary_Customer_59F['Number_Name_and_Address'] = valores['Beneficiary_Customer_59F']
            if Beneficiary_Customer_59F:
                valores['Beneficiary_Customer_59F'] = Beneficiary_Customer_59F
                       
        if 'Currency/Instructed_Amount_33B' in valores:
            pattern = re.compile(r'^(?P<primeros_tres>...)(?P<resto>.*)')
            Currency_Instructed_Amount_33B = valores['Currency/Instructed_Amount_33B']
            match = pattern.match(Currency_Instructed_Amount_33B)
            Currency_Instructed_Amount_33B = {}
            if match:
                Currency_Instructed_Amount_33B['Currency'] = match.group('primeros_tres')
                Currency_Instructed_Amount_33B['Amount'] = match.group('resto')
            if Currency_Instructed_Amount_33B:
                valores['Currency/Instructed_Amount_33B'] = Currency_Instructed_Amount_33B
                        
        if 'Senders_Charges_71F' in valores:
            pattern = re.compile(r'^(?P<Currency>[A-Z]{3})(?P<Amount>.+)$')
            Senders_Charges_71F = valores['Senders_Charges_71F']
            match = pattern.match(Senders_Charges_71F)
            Senders_Charges_71F = {}
            if match:
                Senders_Charges_71F['Currency'] = match.group('Currency')
                Senders_Charges_71F['Amount'] = match.group('Amount') 
            if Senders_Charges_71F:
                valores['Senders_Charges_71F'] = Senders_Charges_71F
                
        if 'Receivers_Charges_71G' in valores:
            pattern = re.compile(r'^(?P<Currency>[A-Z]{3})(?P<Amount>.+)$')
            Receivers_Charges_71G = valores['Receivers_Charges_71G']
            match = pattern.match(Receivers_Charges_71G)
            Receivers_Charges_71G = {}
            if match:
                Receivers_Charges_71G['Currency'] = match.group('Currency')
                Receivers_Charges_71G['Amount'] = match.group('Amount') 
            if Receivers_Charges_71G:
                valores['Receivers_Charges_71G'] = Receivers_Charges_71G
           
        if 'Value_Date_Currency_Code_Amount_32A' in valores:
            pattern = re.compile(r'^(?P<primeros_6>\d{6})(?P<tres_caracteres>[a-zA-Z]{3})(?P<resto>.*)')
            Value_Date_Currency_Code_Amount_32A = valores['Value_Date_Currency_Code_Amount_32A']
            match = pattern.match(Value_Date_Currency_Code_Amount_32A)
            Value_Date_Currency_Code_Amount_32A = {}
            if match:
                Value_Date_Currency_Code_Amount_32A['Date'] = match.group('primeros_6')
                Value_Date_Currency_Code_Amount_32A['Currency'] = match.group('tres_caracteres')
                Value_Date_Currency_Code_Amount_32A['Amount'] = match.group('resto')
            if Value_Date_Currency_Code_Amount_32A:
                valores['Value_Date_Currency_Code_Amount_32A'] = Value_Date_Currency_Code_Amount_32A
            
        if 'Sum_of_Receivers_Charges_71G' in valores:
            pattern = re.compile(r'^(?P<Currency>[A-Z]{3})(?P<Amount>.+)$')
            Sum_of_Receivers_Charges_71G = valores['Sum_of_Receivers_Charges_71G']
            match = pattern.match(Sum_of_Receivers_Charges_71G)
            Sum_of_Receivers_Charges_71G = {}
            if match:
                Sum_of_Receivers_Charges_71G['Currency'] = match.group('Currency')
                Sum_of_Receivers_Charges_71G['Amount'] = match.group('Amount') 
            if Sum_of_Receivers_Charges_71G:
                valores['Sum_of_Receivers_Charges_71G'] = Sum_of_Receivers_Charges_71G
                
        if 'Time_indication_13C' in valores:
            pattern = re.compile(r'/(?P<first_part>.*?)(?P<next_4_numbers>\d{4})(?P<any_character>.*?)(?P<last_4_numbers>\d{4})')
            time_indication_13C = valores['Time_indication_13C']
            match = pattern.match(time_indication_13C)
            Time_indication_13C = {}
            if match:
                Time_indication_13C['Code'] = match.group('first_part')
                Time_indication_13C['Time_indication'] = match.group('next_4_numbers')
                Time_indication_13C['Sign'] = match.group('any_character')
                Time_indication_13C['Time_offset'] = match.group('last_4_numbers')
            if Time_indication_13C:
                valores['Time_indication_13C'] = Time_indication_13C
        
        if 'Senders_Correspondent_53A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Senders_Correspondent_53A = valores['Senders_Correspondent_53A']
            match = pattern.match(Senders_Correspondent_53A)
            Senders_Correspondent_53A = {}
            if match:
                Senders_Correspondent_53A['Party_Identifier'] = match.group('Party_Identifier')
                Senders_Correspondent_53A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Senders_Correspondent_53A['Party_Identifier'] = None
                Senders_Correspondent_53A['Identifier_Code'] = valores['Senders_Correspondent_53A'] 
            if Senders_Correspondent_53A:
                valores['Senders_Correspondent_53A'] = Senders_Correspondent_53A
                
        if 'Receivers_Correspondent_54A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Receivers_Correspondent_54A = valores['Receivers_Correspondent_54A']
            match = pattern.match(Receivers_Correspondent_54A)
            Receivers_Correspondent_54A = {}
            if match:
                Receivers_Correspondent_54A['Party_Identifier'] = match.group('Party_Identifier')
                Receivers_Correspondent_54A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Receivers_Correspondent_54A['Party_Identifier'] = None
                Receivers_Correspondent_54A['Identifier_Code'] = valores['Receivers_Correspondent_54A'] 
            if Receivers_Correspondent_54A:
                valores['Receivers_Correspondent_54A'] = Receivers_Correspondent_54A
                
    return diccionario