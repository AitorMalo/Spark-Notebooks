import HDFS_process
import os 

DAT_DIR = os.environ.get('DAT_DIR') # directorio
##########################################################################################################
## STEP 1: Upload again
## ------------------------------------------------------------
## 
##########################################################################################################  
HDFS_process.ejecutar_proceso_kinit()
fechas=HDFS_process.listar_rutas_hdfs()
print(fechas)
ruta_zip=HDFS_process.seleccionar_fecha(fechas)
ruta_zip= f'/initiatives/cumplimiento/11_SWIFT_Global/{ruta_zip}'
if ruta_zip:
    archivos_zip, archivos_csv = HDFS_process.listar_archivos_hdfs(ruta_zip)
    # Mostrar archivos .zip disponibles y permitir al usuario seleccionar uno
    archivo_zip, archivo_csv = HDFS_process.seleccionar_archivos(archivos_zip, archivos_csv)
    # Copiar los archivos seleccionados del HDFS al sistema local
    if archivo_zip and archivo_csv:
        HDFS_process.borrar_antiguos(DAT_DIR)
        HDFS_process.copiar_archivo_hdfs_a_local(archivo_zip, DAT_DIR)
        HDFS_process.copiar_archivo_hdfs_a_local(archivo_csv, DAT_DIR)
        HDFS_process.volver_a_ejecutar()