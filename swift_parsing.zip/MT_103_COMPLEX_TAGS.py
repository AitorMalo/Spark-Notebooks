import re

def complex_tags(diccionario):
    # Iterar sobre las claves del diccionario
    for clave, valores in diccionario.items():
        # Verificar si la clave 'Time_indication_13C' existe en los valores
        if 'Time_indication_13C' in valores:
            pattern = re.compile(r'/(?P<first_part>.*?)(?P<next_4_numbers>\d{4})(?P<any_character>.*?)(?P<last_4_numbers>\d{4})')
            # Obtener el valor asociado a la clave 'Time_indication_13C'
            time_indication_13C = valores['Time_indication_13C']
            # Hacer la coincidencia con la expresión regular
            match = pattern.match(time_indication_13C)
            # Inicializar el diccionario time_indication_info
            Time_indication_13C = {}
            # Acceder a los grupos nombrados y agregar al diccionario
            if match:
                Time_indication_13C['Code'] = match.group('first_part')
                Time_indication_13C['Time_indication'] = match.group('next_4_numbers')
                # Suponemos que el signo siempre está en la posición 9
                Time_indication_13C['Sign'] = match.group('any_character')
                Time_indication_13C['Time_offset'] = match.group('last_4_numbers')
            # Agregar el diccionario 'time_indication_info' a los valores existentes si no es un diccionario vacio
            if Time_indication_13C:
                valores['Time_indication_13C'] = Time_indication_13C
            
        if 'Instruction_Code_23E' in valores:
            pattern = re.compile(r'^(?P<primeros_4>....)(?P<resto>.*)')
            Instruction_Code_23E = valores['Instruction_Code_23E']
            match = pattern.match(Instruction_Code_23E)
            Instruction_Code_23E = {}
            if match:
                Instruction_Code_23E['Instruction_Code'] = match.group('primeros_4')
                Instruction_Code_23E['Additional_Information'] = match.group('resto') 
            if Instruction_Code_23E:
                valores['Instruction_Code_23E'] = Instruction_Code_23E
            
        if 'Value_Date/Currency/Interbank_Settled_Amount_32A' in valores:
            pattern = re.compile(r'^(?P<primeros_6>\d{6})(?P<tres_caracteres>[a-zA-Z]{3})(?P<resto>.*)')
            Value_Date_Currency_Interbank_Settled_Amount_32A = valores['Value_Date/Currency/Interbank_Settled_Amount_32A']
            match = pattern.match(Value_Date_Currency_Interbank_Settled_Amount_32A)
            Value_Date_Currency_Interbank_Settled_Amount_32A = {}
            if match:
                Value_Date_Currency_Interbank_Settled_Amount_32A['Date'] = match.group('primeros_6')
                Value_Date_Currency_Interbank_Settled_Amount_32A['Currency'] = match.group('tres_caracteres')
                Value_Date_Currency_Interbank_Settled_Amount_32A['Amount'] = match.group('resto')
            if Value_Date_Currency_Interbank_Settled_Amount_32A:
                valores['Value_Date/Currency/Interbank_Settled_Amount_32A'] = Value_Date_Currency_Interbank_Settled_Amount_32A
            
        if 'Currency/Instructed_Amount_33B' in valores:
            pattern = re.compile(r'^(?P<primeros_tres>...)(?P<resto>.*)')
            Currency_Instructed_Amount_33B = valores['Currency/Instructed_Amount_33B']
            match = pattern.match(Currency_Instructed_Amount_33B)
            Currency_Instructed_Amount_33B = {}
            if match:
                Currency_Instructed_Amount_33B['Currency'] = match.group('primeros_tres')
                Currency_Instructed_Amount_33B['Amount'] = match.group('resto')
            if Currency_Instructed_Amount_33B:
                valores['Currency/Instructed_Amount_33B'] = Currency_Instructed_Amount_33B
                
        if 'Ordering_Customer_50A' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Ordering_Customer_50A = valores['Ordering_Customer_50A']
            match = pattern.match(Ordering_Customer_50A)
            Ordering_Customer_50A = {}
            if match:
                Ordering_Customer_50A['Account'] = match.group('Account')
                Ordering_Customer_50A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Ordering_Customer_50A['Account'] = None
                Ordering_Customer_50A['Identifier_Code'] = valores['Ordering_Customer_50A'] 
            if Ordering_Customer_50A:
                valores['Ordering_Customer_50A'] = Ordering_Customer_50A
            
        if 'Ordering_Customer_50F' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>[^\n]+)\n(?P<Name_number_and_Address>[\s\S]*)$')
            Ordering_Customer_50F = valores['Ordering_Customer_50F']
            match = pattern.match(Ordering_Customer_50F)
            Ordering_Customer_50F = {}
            if match:
                Ordering_Customer_50F['Party_Identifier'] = match.group('Party_Identifier')
                Ordering_Customer_50F['Number_Name_and_Address'] = match.group('Name_number_and_Address')
            if Ordering_Customer_50F:
                valores['Ordering_Customer_50F'] = Ordering_Customer_50F
        
        if 'Ordering_Customer_50K' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Ordering_Customer_50K = valores['Ordering_Customer_50K']
            match = pattern.match(Ordering_Customer_50K)
            Ordering_Customer_50K = {}
            if match:
                Ordering_Customer_50K['Account'] = match.group('Account')
                Ordering_Customer_50K['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Ordering_Customer_50K['Account'] = None
                Ordering_Customer_50K['Name_and_Address'] = valores['Ordering_Customer_50K'] 
            if Ordering_Customer_50K:
                valores['Ordering_Customer_50K'] = Ordering_Customer_50K
        
        if 'Sending_Institution_51A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Sending_Institution_51A = valores['Sending_Institution_51A']
            match = pattern.match(Sending_Institution_51A)
            Sending_Institution_51A = {}
            if match:
                Sending_Institution_51A['Party_Identifier'] = match.group('Party_Identifier')
                Sending_Institution_51A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Sending_Institution_51A['Party_Identifier'] = None
                Sending_Institution_51A['Identifier_Code'] = valores['Sending_Institution_51A'] 
            if Sending_Institution_51A:
                valores['Sending_Institution_51A'] = Sending_Institution_51A
        
        if 'Ordering_Institution_52A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Ordering_Institution_52A = valores['Ordering_Institution_52A']
            match = pattern.match(Ordering_Institution_52A)
            Ordering_Institution_52A = {}
            if match:
                Ordering_Institution_52A['Party_Identifier'] = match.group('Party_Identifier')
                Ordering_Institution_52A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Ordering_Institution_52A['Party_Identifier'] = None
                Ordering_Institution_52A['Identifier_Code'] = valores['Ordering_Institution_52A'] 
            if Ordering_Institution_52A:
                valores['Ordering_Institution_52A'] = Ordering_Institution_52A
                
        if 'Ordering_Institution_52D' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Ordering_Institution_52D = valores['Ordering_Institution_52D']
            match = pattern.match(Ordering_Institution_52D)
            Ordering_Institution_52D = {}
            if match:
                Ordering_Institution_52D['Party_Identifier'] = match.group('Party_Identifier')
                Ordering_Institution_52D['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Ordering_Institution_52D['Party_Identifier'] = None
                Ordering_Institution_52D['Name_and_Address'] = valores['Ordering_Institution_52D'] 
            if Ordering_Institution_52D:
                valores['Ordering_Institution_52D'] = Ordering_Institution_52D
                
        if 'Senders_Correspondent_53A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Senders_Correspondent_53A = valores['Senders_Correspondent_53A']
            match = pattern.match(Senders_Correspondent_53A)
            Senders_Correspondent_53A = {}
            if match:
                Senders_Correspondent_53A['Party_Identifier'] = match.group('Party_Identifier')
                Senders_Correspondent_53A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Senders_Correspondent_53A['Party_Identifier'] = None
                Senders_Correspondent_53A['Identifier_Code'] = valores['Senders_Correspondent_53A'] 
            if Senders_Correspondent_53A:
                valores['Senders_Correspondent_53A'] = Senders_Correspondent_53A
        
        if 'Senders_Correspondent_53B' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Location>[\s\S]*))?$')
            Senders_Correspondent_53B = valores['Senders_Correspondent_53B']
            match = pattern.match(Senders_Correspondent_53B)
            Senders_Correspondent_53B = {}
            if match:
                Senders_Correspondent_53B['Party_Identifier'] = match.group('Party_Identifier')
                Senders_Correspondent_53B['Location'] = match.group('Location')
            else:
                Senders_Correspondent_53B['Party_Identifier'] = None
                Senders_Correspondent_53B['Location'] = valores['Senders_Correspondent_53B'] 
            if Senders_Correspondent_53B:
                valores['Senders_Correspondent_53B'] = Senders_Correspondent_53B
                
        if 'Senders_Correspondent_53D' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Senders_Correspondent_53D = valores['Senders_Correspondent_53D']
            match = pattern.match(Senders_Correspondent_53D)
            Senders_Correspondent_53D = {}
            if match:
                Senders_Correspondent_53D['Party_Identifier'] = match.group('Party_Identifier')
                Senders_Correspondent_53D['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Senders_Correspondent_53D['Party_Identifier'] = None
                Senders_Correspondent_53D['Name_and_Address'] = valores['Senders_Correspondent_53D']
            if Senders_Correspondent_53D:
                valores['Senders_Correspondent_53D'] = Senders_Correspondent_53D
                
        if 'Receivers_Correspondent_54A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Receivers_Correspondent_54A = valores['Receivers_Correspondent_54A']
            match = pattern.match(Receivers_Correspondent_54A)
            Receivers_Correspondent_54A = {}
            if match:
                Receivers_Correspondent_54A['Party_Identifier'] = match.group('Party_Identifier')
                Receivers_Correspondent_54A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Receivers_Correspondent_54A['Party_Identifier'] = None
                Receivers_Correspondent_54A['Identifier_Code'] = valores['Receivers_Correspondent_54A']
            if Receivers_Correspondent_54A:
                valores['Receivers_Correspondent_54A'] = Receivers_Correspondent_54A
                
        if 'Receivers_Correspondent_54B' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Location>[\s\S]*))?$')
            Receivers_Correspondent_54B = valores['Receivers_Correspondent_54B']
            match = pattern.match(Receivers_Correspondent_54B)
            Receivers_Correspondent_54B = {}
            if match:
                Receivers_Correspondent_54B['Party_Identifier'] = match.group('Party_Identifier')
                Receivers_Correspondent_54B['Location'] = match.group('Location')
            else:
                Receivers_Correspondent_54B['Party_Identifier'] = None
                Receivers_Correspondent_54B['Location'] = valores['Receivers_Correspondent_54B']
            if Receivers_Correspondent_54B:
                valores['Receivers_Correspondent_54B'] = Receivers_Correspondent_54B
                
        if 'Receivers_Correspondent_54D' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Receivers_Correspondent_54D = valores['Receivers_Correspondent_54D']
            match = pattern.match(Receivers_Correspondent_54D)
            Receivers_Correspondent_54D = {}
            if match:
                Receivers_Correspondent_54D['Party_Identifier'] = match.group('Party_Identifier')
                Receivers_Correspondent_54D['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Receivers_Correspondent_54D['Party_Identifier'] = None
                Receivers_Correspondent_54D['Name_and_Address'] = valores['Receivers_Correspondent_54D']
            if Receivers_Correspondent_54D:
                valores['Receivers_Correspondent_54D'] = Receivers_Correspondent_54D
                
        if 'Third_Reimbursement_Institution_55A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Third_Reimbursement_Institution_55A = valores['Third_Reimbursement_Institution_55A']
            match = pattern.match(Third_Reimbursement_Institution_55A)
            Third_Reimbursement_Institution_55A = {}
            if match:
                Third_Reimbursement_Institution_55A['Party_Identifier'] = match.group('Party_Identifier')
                Third_Reimbursement_Institution_55A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Third_Reimbursement_Institution_55A['Party_Identifier'] = None
                Third_Reimbursement_Institution_55A['Identifier_Code'] = valores['Third_Reimbursement_Institution_55A']
            if Third_Reimbursement_Institution_55A:
                valores['Third_Reimbursement_Institution_55A'] = Third_Reimbursement_Institution_55A
                
        if 'Third_Reimbursement_Institution_55B' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Location>[\s\S]*))?$')
            Third_Reimbursement_Institution_55B = valores['Third_Reimbursement_Institution_55B']
            match = pattern.match(Third_Reimbursement_Institution_55B)
            Third_Reimbursement_Institution_55B = {}
            if match:
                Third_Reimbursement_Institution_55B['Party_Identifier'] = match.group('Party_Identifier')
                Third_Reimbursement_Institution_55B['Location'] = match.group('Location')
            else:
                Third_Reimbursement_Institution_55B['Party_Identifier'] = None
                Third_Reimbursement_Institution_55B['Location'] = valores['Third_Reimbursement_Institution_55B']
            if Third_Reimbursement_Institution_55B:
                valores['Third_Reimbursement_Institution_55B'] = Third_Reimbursement_Institution_55B
                
        if 'Third_Reimbursement_Institution_55D' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Third_Reimbursement_Institution_55D = valores['Third_Reimbursement_Institution_55D']
            match = pattern.match(Third_Reimbursement_Institution_55D)
            Third_Reimbursement_Institution_55D = {}
            if match:
                Third_Reimbursement_Institution_55D['Party_Identifier'] = match.group('Party_Identifier')
                Third_Reimbursement_Institution_55D['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Third_Reimbursement_Institution_55D['Party_Identifier'] = None
                Third_Reimbursement_Institution_55D['Name_and_Address'] = valores['Third_Reimbursement_Institution_55D']
            if Third_Reimbursement_Institution_55D:
                valores['Third_Reimbursement_Institution_55D'] = Third_Reimbursement_Institution_55D
                
        if 'Intermediary_Institution_56A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Intermediary_Institution_56A = valores['Intermediary_Institution_56A']
            match = pattern.match(Intermediary_Institution_56A)
            Intermediary_Institution_56A = {}
            if match:
                Intermediary_Institution_56A['Party_Identifier'] = match.group('Party_Identifier')
                Intermediary_Institution_56A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Intermediary_Institution_56A['Party_Identifier'] = None
                Intermediary_Institution_56A['Identifier_Code'] = valores['Intermediary_Institution_56A']
            if Intermediary_Institution_56A:
                valores['Intermediary_Institution_56A'] = Intermediary_Institution_56A
                
        if 'Intermediary_Institution_56D' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Intermediary_Institution_56D = valores['Intermediary_Institution_56D']
            match = pattern.match(Intermediary_Institution_56D)
            Intermediary_Institution_56D = {}
            if match:
                Intermediary_Institution_56D['Party_Identifier'] = match.group('Party_Identifier')
                Intermediary_Institution_56D['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Intermediary_Institution_56D['Party_Identifier'] = None
                Intermediary_Institution_56D['Name_and_Address'] = valores['Intermediary_Institution_56D']
            if Intermediary_Institution_56D:
                valores['Intermediary_Institution_56D'] = Intermediary_Institution_56D
        
        if 'Account_With_Institution_57A' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Account_With_Institution_57A = valores['Account_With_Institution_57A']
            match = pattern.match(Account_With_Institution_57A)
            Account_With_Institution_57A = {}
            if match:
                Account_With_Institution_57A['Party_Identifier'] = match.group('Party_Identifier')
                Account_With_Institution_57A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Account_With_Institution_57A['Party_Identifier'] = None
                Account_With_Institution_57A['Identifier_Code'] = valores['Account_With_Institution_57A']
            if Account_With_Institution_57A:
                valores['Account_With_Institution_57A'] = Account_With_Institution_57A
                
        if 'Account_With_Institution_57B' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Location>[\s\S]*))?$')
            Account_With_Institution_57B = valores['Account_With_Institution_57B']
            match = pattern.match(Account_With_Institution_57B)
            Account_With_Institution_57B = {}
            if match:
                Account_With_Institution_57B['Party_Identifier'] = match.group('Party_Identifier')
                Account_With_Institution_57B['Location'] = match.group('Location')
            else:
                Account_With_Institution_57B['Party_Identifier'] = None
                Account_With_Institution_57B['Location'] = valores['Account_With_Institution_57B']
            if Account_With_Institution_57B:
                valores['Account_With_Institution_57B'] = Account_With_Institution_57B
                
        if 'Account_With_Institution_57D' in valores:
            pattern = re.compile(r'^(?P<Party_Identifier>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Account_With_Institution_57D = valores['Account_With_Institution_57D']
            match = pattern.match(Account_With_Institution_57D)
            Account_With_Institution_57D = {}
            if match:
                Account_With_Institution_57D['Party_Identifier'] = match.group('Party_Identifier')
                Account_With_Institution_57D['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Account_With_Institution_57D['Party_Identifier'] = None
                Account_With_Institution_57D['Name_and_Address'] = valores['Account_With_Institution_57D']
            if Account_With_Institution_57D:
                valores['Account_With_Institution_57D'] = Account_With_Institution_57D
        
        if 'Beneficiary_Customer_59' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Name_and_Address>[\s\S]*))?$')
            Beneficiary_Customer_59 = valores['Beneficiary_Customer_59']
            match = pattern.match(Beneficiary_Customer_59)
            Beneficiary_Customer_59 = {}
            if match:
                Beneficiary_Customer_59['Account'] = match.group('Account')
                Beneficiary_Customer_59['Name_and_Address'] = match.group('Name_and_Address')
            else:
                Beneficiary_Customer_59['Account'] = None
                Beneficiary_Customer_59['Name_and_Address'] = valores['Beneficiary_Customer_59']
            if Beneficiary_Customer_59:
                valores['Beneficiary_Customer_59'] = Beneficiary_Customer_59
                
        if 'Beneficiary_Customer_59A' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Identifier_Code>[\s\S]*))?$')
            Beneficiary_Customer_59A = valores['Beneficiary_Customer_59A']
            match = pattern.match(Beneficiary_Customer_59A)
            Beneficiary_Customer_59A = {}
            if match:
                Beneficiary_Customer_59A['Account'] = match.group('Account')
                Beneficiary_Customer_59A['Identifier_Code'] = match.group('Identifier_Code')
            else:
                Beneficiary_Customer_59A['Account'] = None
                Beneficiary_Customer_59A['Identifier_Code'] = valores['Beneficiary_Customer_59A']
            if Beneficiary_Customer_59A:
                valores['Beneficiary_Customer_59A'] = Beneficiary_Customer_59A
                
        if 'Beneficiary_Customer_59F' in valores:
            pattern = re.compile(r'^(?P<Account>/[^\n]*)(?:\n(?P<Number_Name_and_Address>[\s\S]*))?$')
            Beneficiary_Customer_59F = valores['Beneficiary_Customer_59F']
            match = pattern.match(Beneficiary_Customer_59F)
            Beneficiary_Customer_59F = {}
            if match:
                Beneficiary_Customer_59F['Account'] = match.group('Account')
                Beneficiary_Customer_59F['Number_Name_and_Address'] = match.group('Number_Name_and_Address')
            else:
                Beneficiary_Customer_59F['Account'] = None
                Beneficiary_Customer_59F['Number_Name_and_Address'] = valores['Beneficiary_Customer_59F']
            if Beneficiary_Customer_59F:
                valores['Beneficiary_Customer_59F'] = Beneficiary_Customer_59F
        
        if 'Sender_Charges_71F' in valores:
            pattern = re.compile(r'^(?P<currency>[A-Za-z]{3})(?P<amount>.*)$')
            Sender_Charges_71F = valores['Sender_Charges_71F']
            match = pattern.match(Sender_Charges_71F)
            Sender_Charges_71F = {}
            if match:
                Sender_Charges_71F['Currency'] = match.group('currency')
                Sender_Charges_71F['Amount'] = match.group('amount')
            if Sender_Charges_71F:
                valores['Sender_Charges_71F'] = Sender_Charges_71F
                
        if 'Receiver_Charges_71G' in valores:
            pattern = re.compile(r'^(?P<currency>[A-Za-z]{3})(?P<amount>.*)$')
            Receiver_Charges_71G = valores['Receiver_Charges_71G']
            match = pattern.match(Receiver_Charges_71G)
            Receiver_Charges_71G = {}
            if match:
                Receiver_Charges_71G['Currency'] = match.group('currency')
                Receiver_Charges_71G['Amount'] = match.group('amount')
            if Receiver_Charges_71G:
                valores['Receiver_Charges_71G'] = Receiver_Charges_71G
        
        
            
            
    return diccionario