import pexpect
import subprocess
import os
import SWIFTParserLogger
from initialFunctions import PARSER_LOGGER
from pyspark.sql import SparkSession
import pyarrow.hdfs as hdfs
import pandas as pd
import datetime
from General_properties import lista_payments, lista_trade
import time
##############################################################################################################
## Funcion 1: FUNCIÓN PARA ACTIVAR EL KINIT Y CONECTARNOS AL HDFS
## ------------------------------------------------------------
## Se aplica en SWIFT_parsing.py
##############################################################################################################

def ejecutar_proceso_kinit():
    # Ejecutar kinit con contraseña
    comando_kinit = 'kinit'

    try:
        # Inicia el proceso kinit utilizando pexpect
        proceso_kinit = pexpect.spawn(comando_kinit)

        # Espera la cadena "Password" para enviar la contraseña
        proceso_kinit.expect("Password")

        # Ingresa tu contraseña (reemplaza 'tu_contraseña' con tu contraseña real)
        proceso_kinit.sendline('Bandera&3')

        # Espera a que termine el proceso
        proceso_kinit.wait()
        # Verifica el resultado del proceso kinit
        if proceso_kinit.exitstatus == 0:
            PARSER_LOGGER.info('kinit realizado exitosamente.')
        else:
            PARSER_LOGGER.error(f'Error en kinit. Código de salida: {proceso_kinit.exitstatus}')
    except Exception as e:
        PARSER_LOGGER.error(f'Error al ejecutar kinit: {str(e)}')

#############################################################################################################################
## Funcion 2: FUNCIÓN PARA SUBIR LOS ARCHIVOS AL HDFS
## ------------------------------------------------------------
## Primero utilizamos un comando para crear la carpeta con el nombre del .zip con la fecha de este en caso de que no exista
## Luego utilizamos un comando para subir los archivos .parquet al HDFS y los borramos de la carpeta local
## Por último nos aseguramos que no hay más de un .parquet igual y si lo hay lo juntamos en uno solo 
## Se aplica en SWIFT_parsing.py
#############################################################################################################################

def gestionar_directorio_hdfs(ruta_zip):
    # Define la ruta y nombre del directorio en HDFS
    directorio_hdfs = ruta_zip.split('_')[1].replace('.zip', '')

    # Comando para verificar si el archivo existe
    comando_verificacion = f'hdfs dfs -test -e /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}'

    # Ejecutar el comando en la terminal
    resultado_verificacion = subprocess.run(comando_verificacion, shell=True)

    # Verificar el resultado del comando
    if resultado_verificacion.returncode == 0:
        print('Ya existe la carpeta')
    else:
        # Comando para crear el directorio si no existe
        comando_hdfs = f"hadoop fs -mkdir -p /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}"

        # Ejecutar el comando en la terminal
        resultado_hdfs = subprocess.run(comando_hdfs, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Verificar el resultado del comando
        if resultado_hdfs.returncode == 0:
            print(f'Directorio en HDFS ({directorio_hdfs}) creado exitosamente.')
        else:
            print(f'Error al crear el directorio en HDFS. Mensaje de error: {resultado_hdfs.stderr.decode("utf-8")}')

    # Primer comando para copiar el archivo parquet al directorio en HDFS
    comando_hdfs_1 = f'hdfs dfs -copyFromLocal /data/x328135/notebook/*.parquet /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}'

    # Ejecutar el primer comando en la terminal
    try:
        resultado_1 = subprocess.run(comando_hdfs_1, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # Verificar el resultado del primer comando
        if resultado_1.returncode == 0:
            PARSER_LOGGER.info('Archivo parquet (ALL_TAGS_MT.parquet) copiado a HDFS exitosamente.')
        else:
             PARSER_LOGGER.error(f'Error al copiar el archivo parquet (ALL_TAGS_MT.parquet) a HDFS. Mensaje de error: {resultado_1.stderr.decode("utf-8")}')
    except:
        print('No hay mensajes MT')
        
    ###############################################################################################################################################################################
    comando_hdfs_2 = f'hdfs dfs -copyFromLocal /data/x328135/data/* /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}'

    # Ejecutar el primer comando en la terminal
    try:
        resultado_1 = subprocess.run(comando_hdfs_2, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # Verificar el resultado del primer comando
        if resultado_1.returncode == 0:
            PARSER_LOGGER.info('Se ha subido tanto el csv como el zip al HDFS')
        else:
             PARSER_LOGGER.error(f'Error al subir los archivos. Mensaje de error: {resultado_1.stderr.decode("utf-8")}')
    except:
        print('No hay nada en la carpeta')
    ###############################################################################################################################################################################
    # Ruta de la carpeta local
    ruta_carpeta_local = os.environ.get('NOTEBOOK_DIR')

    # Comando para eliminar todos los archivos .parquet en la carpeta
    comando_eliminar_parquet = f'find {ruta_carpeta_local} -type f -name "*.parquet" -exec rm {{}} \\;'

    # Ejecutar el comando en la terminal
    resultado_eliminar_parquet = subprocess.run(comando_eliminar_parquet, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # Verificar el resultado del comando
    if resultado_eliminar_parquet.returncode == 0:
        print('Archivos parquet eliminados exitosamente.')
    else:
        print(f'Error al eliminar archivos parquet. Mensaje de error: {resultado_eliminar_parquet.stderr.decode("utf-8")}')
        
    ##################################################################  
    comando_listar = f'hdfs dfs -ls /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}'
    try:
        resultado_listar = subprocess.run(comando_listar, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        lineas = resultado_listar.stdout.decode('utf-8').split('\n')
        archivos = [linea.split()[-1] for linea in lineas if len(linea.split()) > 0 and not linea.startswith('Found')]
        print(archivos)
    except subprocess.CalledProcessError as e:
        print(f'Error al listar archivos en HDFS. Mensaje de error: {e.stderr.decode("utf-8")}')
        
    dataframes_Payments = []
    fs = hdfs.connect()
    spark = SparkSession.builder.appName("Juntar_parquets").config("spark.driver.memory", "4g").config("spark.executor.memory", "8g").getOrCreate()
    Payments = [ruta for ruta in archivos if 'Payments' in ruta]
    if f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/Payments_merged.parquet' in Payments:
        Payments.remove(f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/Payments_merged.parquet')  # Elimina el valor si está presente en la lista
        Payments.insert(0, f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/Payments_merged.parquet')
    Trade = [ruta for ruta in archivos if 'Trade' in ruta]
    if f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/Trade_merged.parquet' in Trade:
        Trade.remove(f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/Trade_merged.parquet')  # Elimina el valor si está presente en la lista
        Trade.insert(0, f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/Trade_merged.parquet')
    All_messages = [ruta for ruta in archivos if 'All_messages' in ruta]
    if f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/All_messages_merged.parquet' in All_messages:
        All_messages.remove(f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/All_messages_merged.parquet')  # Elimina el valor si está presente en la lista
        All_messages.insert(0, f'/initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/All_messages_merged.parquet')
    
    for nombre_carpeta_hdfs in Payments:
        df_spark = spark.read.parquet(nombre_carpeta_hdfs)
        dataframes_Payments.append(df_spark)
    
    if len(dataframes_Payments) > 1:
        df_final = dataframes_Payments[0]
        for i in range(1, len(dataframes_Payments)):
            columnas_comunes = set(df_final.columns).intersection(dataframes_Payments[i].columns)
            df_final = df_final.join(dataframes_Payments[i], on=list(columnas_comunes), how="outer")
        #Payments_sin_duplicados = df_final.dropDuplicates(subset=list(columnas_comunes))
        #Payments_sin_duplicados = Payments_sin_duplicados.na.drop(how='all')
        pandas_df = df_final.toPandas()
        pandas_df = pandas_df.drop_duplicates(subset=["Message_Content","Filename"], keep='last')
        pandas_df=pandas_df.reindex(columns=lista_payments)
        pandas_df.to_parquet("Payments_merged.parquet", index=False)
        pandas_df.to_csv('prueba_1.csv',index=False,sep=';')
        comando_borrar = f'hdfs dfs -rm /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/*Payments*.parquet'
        subprocess.run(comando_borrar, shell=True)
        if resultado_1.returncode == 0:
            PARSER_LOGGER.info('Archivos parquet eliminados.')
        else:
            PARSER_LOGGER.error(f'Error al eliminar los archivos parquet a HDFS. Mensaje de error: {resultado_1.stderr.decode("utf-8")}')
                    
        comando_hdfs_1 = f'hdfs dfs -copyFromLocal /data/x328135/notebook/*.parquet /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}'
        try:
            resultado_1 = subprocess.run(comando_hdfs_1, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if resultado_1.returncode == 0:
                PARSER_LOGGER.info('Archivo parquet (ALL_TAGS_MT.parquet) copiado a HDFS exitosamente.')
            else:
                 PARSER_LOGGER.error(f'Error al copiar el archivo parquet (ALL_TAGS_MT.parquet) a HDFS. Mensaje de error: {resultado_1.stderr.decode("utf-8")}')
        except:
            print('No hay mensajes MT')

        ruta_carpeta_local = os.environ.get('NOTEBOOK_DIR')
        comando_eliminar_parquet = f'find {ruta_carpeta_local} -type f -name "*.parquet" -exec rm {{}} \\;'
        resultado_eliminar_parquet = subprocess.run(comando_eliminar_parquet, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if resultado_eliminar_parquet.returncode == 0:
            print('Archivos parquet eliminados exitosamente.')
        else:
            print(f'Error al eliminar archivos parquet. Mensaje de error: {resultado_eliminar_parquet.stderr.decode("utf-8")}')

    dataframes_Trade = []
    for nombre_carpeta_hdfs in Trade:
        print(nombre_carpeta_hdfs)
        df_spark = spark.read.parquet(nombre_carpeta_hdfs)
        dataframes_Trade.append(df_spark)
    if len(dataframes_Trade) > 1:
        df_final = dataframes_Trade[0]
        for i in range(1, len(dataframes_Trade)):
            columnas_comunes = set(df_final.columns).intersection(dataframes_Trade[i].columns)
            df_final = df_final.join(dataframes_Trade[i], on=list(columnas_comunes), how="outer")
        num_partitions = spark.sparkContext.defaultParallelism
        df_final = df_final.repartition(num_partitions)
        df_final = df_final.orderBy(col("origen").desc())
        df_final = df_final.dropDuplicates(subset=["Message_Content", "Filename"])
        df_final = df_final.na.drop(how='all')
        df_final = df_final.drop("origen")
        df_final = df_final.filter(
            col("Message_type").isin(lista_trade_message_type) |
            col("Message_type").cast(StringType()).rlike("|".join([f"^{prefix}" for prefix in lista_trade_MX]))
        )
        condicion = col("Message_type").isin(['700', '701', '707', '708', '710', '711', '720', '721', '760', '761'])
        no_700_df = df_final.filter(~condicion)
        df_filtrado = df_final.filter(condicion)
        window_first = Window.partitionBy("Senders_Reference", "Message_type").orderBy(lit(1))
        window_last = Window.partitionBy("Senders_Reference", "Message_type").orderBy(lit(1))
        condicion_primeras = (col("Message_type").isin(['700', '707', '710', '720', '760']))
        df_primeras_repeticiones = df_filtrado.withColumn("row_num", row_number().over(window_first)) \
                                             .filter((col("row_num") == 1) | (~condicion_primeras)) \
                                             .drop("row_num")
        condicion_segundas = (col("Message_type").isin(['700', '707', '710', '720', '760']))
        df_segundas_repeticiones = df_filtrado.withColumn("row_num", row_number().over(window_last)) \
                                              .filter((col("row_num") == 1) | (~condicion_segundas)) \
                                              .drop("row_num")
        columnas_combinar = ['Description_Goods', 'Documents_Required', 'Additional_Conditions', 'Message_Content']
        columnas_presentes = [col_name for col_name in columnas_combinar if col_name in df_filtrado.columns]
        for col_name in columnas_presentes:
            df_primeras_repeticiones = df_primeras_repeticiones.fillna("", subset=[col_name])
            df_segundas_repeticiones = df_segundas_repeticiones.fillna("", subset=[col_name])
        for msg_types in [['700', '701'], ['707', '708'], ['710', '711'], ['720', '721'], ['760', '761']]:
            mask = col("Message_type").isin(msg_types)
            temp_df = df_primeras_repeticiones.filter(mask)
            if temp_df.count() > 0:
                agg_dict = {col_name: concat_ws(" ", col(col_name)) if col_name in columnas_presentes else "first" for col_name in temp_df.columns if col_name != "Senders_Reference"}
                temp_df = temp_df.groupBy("Senders_Reference").agg(*[agg_dict[col_name](col(col_name)).alias(col_name) for col_name in temp_df.columns if col_name != "Senders_Reference"])
                df_primeras_repeticiones = df_primeras_repeticiones.filter(~mask).union(temp_df)
        for msg_types in [['700', '701'], ['707', '708'], ['710', '711'], ['720', '721'], ['760', '761']]:
            mask = col("Message_type").isin(msg_types)
            temp_df = df_segundas_repeticiones.filter(mask)
            if temp_df.count() > 0:
                agg_dict = {col_name: concat_ws(" ", col(col_name)) if col_name in columnas_presentes else "first" for col_name in temp_df.columns if col_name != "Senders_Reference"}
                temp_df = temp_df.groupBy("Senders_Reference").agg(*[agg_dict[col_name](col(col_name)).alias(col_name) for col_name in temp_df.columns if col_name != "Senders_Reference"])
                df_segundas_repeticiones = df_segundas_repeticiones.filter(~mask).union(temp_df)
        df_filtrado = df_primeras_repeticiones.union(df_segundas_repeticiones).dropDuplicates()
        df_final = df_filtrado.union(no_700_df)
        df_final = df_final.select([col_name for col_name in lista_trade if col_name in df_final.columns])
        df_final = df_final.coalesce(8)
        #Trade_sin_duplicados = df_final.dropDuplicates(subset=list(columnas_comunes))
        #Trade_sin_duplicados = Trade_sin_duplicados.na.drop(how='all')
        #pandas_df = df_final.toPandas()
        #df_filtrado = pandas_df.drop_duplicates(subset=["Message_Content","Filename"], keep='last')
        #condicion = (df_filtrado['Message_type'].isin(['700','701', '707','708','710','711','720','721','760','761']))
        #No_700_df = df_filtrado[~condicion]
        #df_filtrado = df_filtrado[condicion]
        #condicion = (df_filtrado['Message_type'].isin(['700', '707', '710', '720','760'])) & (df_filtrado.duplicated(subset=['Senders_Reference', 'Message_type'], keep='first'))
        #df_primeras_repeticiones = df_filtrado[~condicion]
        #df_primeras_repeticiones = df_primeras_repeticiones.sort_values(by='Message_type')
        #condicion_segundas_repeticiones = (df_filtrado['Message_type'].isin(['700', '707', '710', '720','760'])) & (df_filtrado.duplicated(subset=['Senders_Reference', 'Message_type'], keep='last'))
        #df_segundas_repeticiones = df_filtrado[~condicion_segundas_repeticiones]
        #df_segundas_repeticiones = df_segundas_repeticiones.sort_values(by='Message_type')
        #columnas_combinar = ['Description_Goods', 'Documents_Required', 'Additional_Conditions','Message_Content']
        #columnas_presentes_1 = [col for col in columnas_combinar if col in df_filtrado.columns]
        #agg_functions_1 = {col: ' '.join if col in columnas_presentes_1 else 'first' for col in df_primeras_repeticiones.columns if col != 'Senders_Reference'}
        #agg_functions_2 = {col: ' '.join if col in columnas_presentes_1 else 'first' for col in df_segundas_repeticiones.columns if col != 'Senders_Reference'}
        #for col in columnas_presentes_1:
        #    df_primeras_repeticiones[col] = df_primeras_repeticiones[col].fillna('')
        #    df_segundas_repeticiones[col] = df_segundas_repeticiones[col].fillna('')
#
        #mask_700 = df_primeras_repeticiones['Message_type'].isin(['700', '701'])
        #mask_707 = df_primeras_repeticiones['Message_type'].isin(['707', '708'])
        #mask_710 = df_primeras_repeticiones['Message_type'].isin(['710', '711'])
        #mask_720 = df_primeras_repeticiones['Message_type'].isin(['720', '721'])
        #mask_760 = df_primeras_repeticiones['Message_type'].isin(['760', '761'])
        #combined_row_1 = df_primeras_repeticiones[mask_700].groupby('Senders_Reference').agg(agg_functions_1).reset_index()
        #combined_row_2 = df_primeras_repeticiones[mask_707].groupby('Senders_Reference').agg(agg_functions_1).reset_index()
        #combined_row_3 = df_primeras_repeticiones[mask_710].groupby('Senders_Reference').agg(agg_functions_1).reset_index()
        #combined_row_4 = df_primeras_repeticiones[mask_720].groupby('Senders_Reference').agg(agg_functions_1).reset_index()
        #combined_row_5 = df_primeras_repeticiones[mask_760].groupby('Senders_Reference').agg(agg_functions_1).reset_index()
        #df_primeras_repeticiones = pd.concat([combined_row_1, combined_row_2, combined_row_3, combined_row_4, combined_row_5], ignore_index=True)
        #mask_700 = df_segundas_repeticiones['Message_type'].isin(['700', '701'])
        #mask_707 = df_segundas_repeticiones['Message_type'].isin(['707', '708'])
        #mask_710 = df_segundas_repeticiones['Message_type'].isin(['710', '711'])
        #mask_720 = df_segundas_repeticiones['Message_type'].isin(['720', '721'])
        #mask_760 = df_segundas_repeticiones['Message_type'].isin(['760', '761'])
        #combined_row_1_1 = df_segundas_repeticiones[mask_700].groupby('Senders_Reference').agg(agg_functions_2).reset_index()
        #combined_row_2_1 = df_segundas_repeticiones[mask_707].groupby('Senders_Reference').agg(agg_functions_2).reset_index()
        #combined_row_3_1 = df_segundas_repeticiones[mask_710].groupby('Senders_Reference').agg(agg_functions_2).reset_index()
        #combined_row_4_1 = df_segundas_repeticiones[mask_720].groupby('Senders_Reference').agg(agg_functions_2).reset_index()
        #combined_row_5_1 = df_segundas_repeticiones[mask_760].groupby('Senders_Reference').agg(agg_functions_2).reset_index()
        #df_segundas_repeticiones = pd.concat([combined_row_1_1, combined_row_2_1, combined_row_3_1, combined_row_4_1, combined_row_5_1], ignore_index=True)
        #df_filtrado = pd.concat([df_primeras_repeticiones, df_segundas_repeticiones], ignore_index=True)
        #df_filtrado = df_filtrado.drop_duplicates()
        #pandas_df = pd.concat([df_filtrado, No_700_df], ignore_index=True)
        #pandas_df=pandas_df.reindex(columns=lista_trade)
        #pandas_df.to_parquet("Trade_merged.parquet", index=False)
        pandas_df.to_csv('prueba.csv',index=False,sep=';')
        comando_borrar = f'hdfs dfs -rm /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/*Trade*.parquet'
        subprocess.run(comando_borrar, shell=True)
        if resultado_1.returncode == 0:
            PARSER_LOGGER.info('Archivos parquet eliminados.')
        else:
            PARSER_LOGGER.error(f'Error al eliminar los archivos parquet a HDFS. Mensaje de error: {resultado_1.stderr.decode("utf-8")}')
                    
        comando_hdfs_1 = f'hdfs dfs -copyFromLocal /data/x328135/notebook/*.parquet /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}'
        try:
            resultado_1 = subprocess.run(comando_hdfs_1, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if resultado_1.returncode == 0:
                PARSER_LOGGER.info('Archivo parquet (ALL_TAGS_MT.parquet) copiado a HDFS exitosamente.')
            else:
                 PARSER_LOGGER.error(f'Error al copiar el archivo parquet (ALL_TAGS_MT.parquet) a HDFS. Mensaje de error: {resultado_1.stderr.decode("utf-8")}')
        except:
            print('No hay mensajes MT')

        ruta_carpeta_local = os.environ.get('NOTEBOOK_DIR')
        comando_eliminar_parquet = f'find {ruta_carpeta_local} -type f -name "*.parquet" -exec rm {{}} \\;'
        resultado_eliminar_parquet = subprocess.run(comando_eliminar_parquet, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if resultado_eliminar_parquet.returncode == 0:
            print('Archivos parquet eliminados exitosamente.')
        else:
            print(f'Error al eliminar archivos parquet. Mensaje de error: {resultado_eliminar_parquet.stderr.decode("utf-8")}')
            
    ##################################################
    dataframes_All_messages = []
    for nombre_carpeta_hdfs in All_messages:
        df_spark = spark.read.parquet(nombre_carpeta_hdfs)
        dataframes_All_messages.append(df_spark)
    
    if len(dataframes_All_messages) > 1:
        df_final = dataframes_All_messages[0]
        for i in range(1, len(dataframes_All_messages)):
            columnas_comunes = set(df_final.columns).intersection(dataframes_All_messages[i].columns)
            df_final = df_final.join(dataframes_All_messages[i], on=list(columnas_comunes), how="outer")
        #All_messages_sin_duplicados = df_final.dropDuplicates(subset=list(columnas_comunes))
        #All_messages_sin_duplicados = All_messages_sin_duplicados.na.drop(how='all')
        pandas_df = df_final.toPandas()
        pandas_df = pandas_df.drop_duplicates(subset=["Message_Content","Filename"], keep='last')
        pandas_df.to_parquet("All_messages_merged.parquet", index=False)
        comando_borrar = f'hdfs dfs -rm /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}/*All_messages*.parquet'
        subprocess.run(comando_borrar, shell=True)
        if resultado_1.returncode == 0:
            PARSER_LOGGER.info('Archivos parquet eliminados.')
        else:
            PARSER_LOGGER.error(f'Error al eliminar los archivos parquet a HDFS. Mensaje de error: {resultado_1.stderr.decode("utf-8")}')
                    
        comando_hdfs_1 = f'hdfs dfs -copyFromLocal /data/x328135/notebook/*.parquet /initiatives/cumplimiento/11_SWIFT_Global/{directorio_hdfs}'
        try:
            resultado_1 = subprocess.run(comando_hdfs_1, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if resultado_1.returncode == 0:
                PARSER_LOGGER.info('Archivo parquet (ALL_TAGS_MT.parquet) copiado a HDFS exitosamente.')
            else:
                 PARSER_LOGGER.error(f'Error al copiar el archivo parquet (ALL_TAGS_MT.parquet) a HDFS. Mensaje de error: {resultado_1.stderr.decode("utf-8")}')
        except:
            print('No hay mensajes MT')

        ruta_carpeta_local = os.environ.get('NOTEBOOK_DIR')
        comando_eliminar_parquet = f'find {ruta_carpeta_local} -type f -name "*.parquet" -exec rm {{}} \\;'
        resultado_eliminar_parquet = subprocess.run(comando_eliminar_parquet, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if resultado_eliminar_parquet.returncode == 0:
            print('Archivos parquet eliminados exitosamente.')
        else:
            print(f'Error al eliminar archivos parquet. Mensaje de error: {resultado_eliminar_parquet.stderr.decode("utf-8")}')
            
    if 'spark' in locals() or 'spark' in globals():
        spark.stop()
    fs.close()
    
#############################################################################################################################
## Funcion 3: FUNCIÓN PARA SACAR LAS CARPETAS QUE SON DE HACE MÁS DE 10 AÑOS
## ------------------------------------------------------------
## Se aplica en SWIFT_parsing.py
#############################################################################################################################
    
def list_hdfs_folders():
    try:
        output = subprocess.check_output(["hdfs", "dfs", "-ls", "/initiatives/cumplimiento/11_SWIFT_Global"])
        lines = output.decode("utf-8").split("\n")
        folders = []
        # Obtener la fecha actual para comparar con la fecha de las carpetas
        current_date = datetime.datetime.now()
        # Analizar la salida para extraer los nombres de las carpetas y sus fechas
        for line in lines[1:]:
            if line.strip() != "":
                parts = line.split()
                folder_name = parts[-1]
                # Verificar si el nombre de la carpeta termina en un número
                if folder_name.split("/")[-1][:6].isdigit():
                    # Extraer el año y el mes del nombre de la carpeta
                    year_month_str = folder_name.split("/")[-1][:6]
                    year = int(year_month_str[:4])
                    month = int(year_month_str[4:6])
                    # Calcular la diferencia en años y meses entre la fecha actual y la fecha de la carpeta
                    folder_date = datetime.datetime(year, month, 1)
                    difference = current_date - folder_date
                    years_difference = difference.days // 365
                    # Solo agregar nombres de carpetas que tengan más de 10 años de antigüedad
                    if years_difference >= 10:
                        folders.append(folder_name)
        return folders
    except subprocess.CalledProcessError as e:
        print("Error al ejecutar el comando hdfs dfs -ls:", e)
        return []

#############################################################################################################################
## Funcion 4: FUNCIÓN PARA BORRAR LAS CARPETAS QUE SON DE HACE MÁS DE 10 AÑOS
## ------------------------------------------------------------
## Utiliza la función list_hdfs_folders para saber cuales son esas carpetas
## Se aplica en SWIFT_parsing.py
#############################################################################################################################

def borrar_carpetas_antiguas(folders):
    for carpeta in folders:
        comando_borrar = f'hdfs dfs -rm -r {carpeta}'
        resultado = subprocess.run(comando_borrar, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if resultado.returncode == 0:
            print(f'La carpeta {carpeta} fue eliminada exitosamente.')
        else:
            print(f'No tiene más de 10 años {carpeta}.')

#############################################################################################################################
## Funcion 5: FUNCIÓN PARA VOLVER A SUBIR UN .ZIP CON SU .CSV DE NUEVO POR SI HAY ALGUN CAMBIO
## ------------------------------------------------------------
## Utiliza la función list_hdfs_folders para saber cuales son esas carpetas
## Se aplica en SWIFT_parsing.py
#############################################################################################################################
def listar_rutas_hdfs():
    """Función para listar archivos en un directorio del HDFS."""
    comando_listar = 'hdfs dfs -ls /initiatives/cumplimiento/11_SWIFT_Global'
    try:
        resultado_listar = subprocess.run(comando_listar, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        lineas = resultado_listar.stdout.decode('utf-8').split('\n')
        archivos = [linea.split()[-1] for linea in lineas if len(linea.split()) > 0 and not linea.startswith('Found')]
        archivos = [fecha.split("/")[-1] for fecha in archivos]
        archivos.sort()
        return archivos
    except subprocess.CalledProcessError as e:
        print(f'Error al listar archivos en HDFS. Mensaje de error: {e.stderr.decode("utf-8")}')
        return []

def seleccionar_fecha(fechas_disponibles):
    """Función para que el usuario seleccione una fecha de una lista de fechas disponibles."""
    seleccion_fecha = input("Selecciona una fecha que desea analizar con el formato AAAAMMDD ejemplo:20180101 = ").strip()
    if seleccion_fecha in fechas_disponibles:
        return seleccion_fecha
    else:
        print("Error: Esa fecha no está disponible.")
        return None

    
def listar_archivos_hdfs(ruta_zip):
    """Función para listar archivos en un directorio del HDFS."""
    comando_listar = f'hdfs dfs -ls {ruta_zip}'
    try:
        resultado_listar = subprocess.run(comando_listar, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        lineas = resultado_listar.stdout.decode('utf-8').split('\n')
        archivos_zip = [linea.split()[-1] for linea in lineas if linea.endswith(".zip") and not linea.startswith('Found')]
        archivos_csv = [linea.split()[-1] for linea in lineas if linea.endswith(".csv") and not linea.startswith('Found')]
        return archivos_zip, archivos_csv
    except subprocess.CalledProcessError as e:
        print(f'Error al listar archivos en HDFS. Mensaje de error: {e.stderr.decode("utf-8")}')
        return [], []

def seleccionar_archivos(archivos_zip, archivos_csv):
    """Función para que el usuario seleccione un archivo zip y un archivo csv con el mismo nombre."""
    print("Archivos .zip disponibles:")
    archivos = [i.split("/")[-1] for i in archivos_zip]
    archivos.sort()
    for i, archivo in enumerate(archivos, start=1):
        print(f"{i}. {archivo}")
    print("0. No subir nada")
    seleccion_zip = input("Selecciona el número del archivo .zip que deseas copiar o '0' para no subir nada: ").strip()
    if seleccion_zip == '0':
        return None, None
    try:
        indice_zip = int(seleccion_zip) - 1
        if 0 <= indice_zip < len(archivos_zip):
            archivo_zip = archivos_zip[indice_zip]
            nombre_sin_extension_zip = archivo_zip.split('/')[-1][7:-4]  # Eliminar el directorio y la extensión .zip
            for archivo_csv in archivos_csv:
                if archivo_csv.endswith('.csv') and nombre_sin_extension_zip in archivo_csv:
                    return archivo_zip, archivo_csv
            print(f"No se encontró un archivo .csv correspondiente al archivo {archivo_zip}.")
        else:
            print("Por favor, ingresa un número válido.")
    except ValueError:
        print("Por favor, ingresa un número.")

def borrar_antiguos(ruta_local):
    """Función para borrar todo el contenido de una carpeta."""
    comando = f'rm -r {ruta_local}/*'
    try:
        subprocess.run(comando, shell=True, check=True)
        print(f"Contenido de la carpeta {ruta_local} eliminado correctamente.")
    except subprocess.CalledProcessError as e:
        print(f"Error al borrar el contenido de la carpeta {ruta_local}. Mensaje de error: {e}")
            
def copiar_archivo_hdfs_a_local(archivo_hdfs, ruta_local):
    if archivo_hdfs:
        """Función para copiar un archivo del HDFS al sistema local.""" 
        comando = f"hadoop fs -copyToLocal {archivo_hdfs} {ruta_local}"
        try:
            subprocess.run(comando, shell=True, check=True)
            print(f"El archivo {archivo_hdfs} ha sido copiado exitosamente a {ruta_local}.")
        except subprocess.CalledProcessError:
            print(f"No se ha podido copiar el archivo {archivo_hdfs}.")

def volver_a_ejecutar():
    comando = 'python3 SWIFT_parsing.py'
    try:
        subprocess.run(comando, shell=True, check=True)
        print(f"Script ejecutado correctamente.")
    except subprocess.CalledProcessError as e:
        print(f"Error al ejecutar el script. Mensaje de error: {e}")
