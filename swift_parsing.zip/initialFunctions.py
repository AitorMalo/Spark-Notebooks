import os 
import xml.etree.ElementTree as ET
import MTFunctions
import MXFunctions
import SWIFTParserLogger
from datetime import datetime
import importlib
import re
##########################################################################################################
## Funcion 1: FUNCIONES PARA SABER SI EL MENSAJE ES MT O MX
## ------------------------------------------------------------
## Se aplica en la funcion ProcessMessage
##########################################################################################################

def isMT(ruta_al_archivo):
    if MTFunctions.parseMT(ruta_al_archivo)[1].startswith('{1:'):
        return True
    else:
        return False

def isMX(ruta_al_archivo):
    try:
        tree = ET.parse(ruta_al_archivo)
        root = tree.getroot()
        return True
    except:
        return False

#############################################################################################################################################
## Funcion 2: FUNCIÓN PARA APLICAR LOS "COMPLEX_TAGS"
## ------------------------------------------------------------
## Estos son los MT que tienen tags que hay que descomponer, por ejemplo: "USD1099" esto habría que separarlo en "USD" Y "1099" 
## Se aplica en la funcion ProcessMessage y utiliza todos los "MT_{}_COMPLEX_TAGS"
#############################################################################################################################################

def process_tag(contenido, data):
    tag2 = contenido["tag2"]
    number = tag2[1:4]
    module_name = "MT_{}_COMPLEX_TAGS".format(number)
    try:
        module = importlib.import_module(module_name)
        function = getattr(module, "complex_tags")  # Ajusta el nombre de la función según sea necesario
        result = function(data)
        return result
    except ImportError:
        return data

#############################################################################################################################################
## Funcion 3: FUNCIÓN PARA DETECTAR SI ES COV, REMIT O STP el mensaje
## ------------------------------------------------------------
## Se aplica en la funcion ProcessMessage
#############################################################################################################################################

def modify_swift_message_type(input_dict):
    COV_205=['Ordering_Customer_50A','Ordering_Customer_50F','Ordering_Customer_50K','Intermediary_Institution_56A','Intermediary_Institution_56C','Intermediary_Institution_56D','Account_With_Institution_57C','Beneficiary_Customer_59','Beneficiary_Customer_59A','Beneficiary_Customer_59F','Remittance_Information_70','Currency/Instructed_Amount_33B']
    COV_202=['Ordering_Customer_50A','Ordering_Customer_50F','Ordering_Customer_50K','Intermediary_Institution_56A','Intermediary_Institution_56C','Intermediary_Institution_56D','Account_With_Institution_57C','Beneficiary_Customer_59','Beneficiary_Customer_59A','Beneficiary_Customer_59F','Remittance_Information_70','Currency/Instructed_Amount_33B']
    for key, value in input_dict.items():
        if 'SWIFT_Message_Type' in value and 'Envelope_Contents_77T' in value:
            if value['SWIFT_Message_Type'] == '103':
                value['SWIFT_Message_Type'] = '103_REMIT'
        if 'Tag119_Validation_Flag' in value and value['Tag119_Validation_Flag'] == '119:REMIT':
                if value['SWIFT_Message_Type'] == '103':
                    value['SWIFT_Message_Type'] = '103_REMIT'
        if 'Tag119_Validation_Flag' in value and value['Tag119_Validation_Flag'] == '119:STP':
                if value['SWIFT_Message_Type'] == '103':
                    value['SWIFT_Message_Type'] = '103_STP'
                if value['SWIFT_Message_Type'] == '102':
                    value['SWIFT_Message_Type'] = '102_STP'
        if any(key in COV_202 for key in value):
            if value['SWIFT_Message_Type'] == '202':
                value['SWIFT_Message_Type'] = '202_COV'
        if any(key in COV_205 for key in value):
            if value['SWIFT_Message_Type'] == '205':
                value['SWIFT_Message_Type'] = '205_COV'
    return input_dict

PARSER_LOGGER=SWIFTParserLogger.getSWIFTParserLogger('log/prueba_final.log','INFO')

#############################################################################################################################################
## Funcion 4: ES LA FUNCIÓN QUE PROCESA ARCHIVOS MT y MX LOS DEVUELVE EN FORMA DE DICCIONARIO.
#############################################################################################################################################

def ProcessMessage(carpeta,filename,ruta_zip):
    #cosas que necesitamos para los mt
    contenido_tags_parseMT={}
    resultados_tag1_MT={}
    resultados_tag2_MT={}
    resultados_tag3_MT={}
    resultados_tag4_MT={}
    resultados_tag5_MT={}
    ALL_TAGS={}
    # cosas que necesitamos para los mx
    atributos_mx = {}
    resultados_MX={}
    PARSER_LOGGER.debug("PROCESANDO: "+ filename)
    ruta_al_archivo = os.path.join(carpeta, filename)
    if isMT(ruta_al_archivo):
        PARSER_LOGGER.debug("Es un archivo MT: "+ filename)       
        contenido_tags = MTFunctions.parseMT(ruta_al_archivo)[0]
        contenido=MTFunctions.parseMT(ruta_al_archivo)[0]
        PARSER_LOGGER.debug(contenido)
        contenido_tags_parseMT[os.path.basename(ruta_al_archivo)] = contenido_tags  # Almacena el resultado
        contenido_tag1 = MTFunctions.parseMTTag1(contenido)
        contenido_tag1['Message_Content']= MTFunctions.parseMT(ruta_al_archivo)[1]
        contenido_tag1['Extraction_Date']= str(datetime.now())
        contenido_tag1['Payment_Date']= ruta_zip.split('_')[1].replace('.zip', '')
        contenido_tag1['Format']='MT'
        PARSER_LOGGER.debug(contenido_tag1)
        resultados_tag1_MT[os.path.basename(ruta_al_archivo)] = contenido_tag1  # Almacena el resultado
        contenido_tag2 = MTFunctions.parseMTTag2(contenido)
        PARSER_LOGGER.debug(contenido_tag2)
        resultados_tag2_MT[os.path.basename(ruta_al_archivo)] = contenido_tag2  # Almacena el resultado
        contenido_tag3 = MTFunctions.parseMTTag3(contenido)
        PARSER_LOGGER.debug(contenido_tag3)
        resultados_tag3_MT[os.path.basename(ruta_al_archivo)] = contenido_tag3  # Almacena el resultado
        mapeo = MTFunctions.selectMT(contenido)[2]
        lista_subcategorias_valor = MTFunctions.selectMT(contenido)[1]
        contenido_tag4 = MTFunctions.parseMTTag4(contenido,mapeo,lista_subcategorias_valor)[0]
        contenido_tag4_adaptado = MTFunctions.reemplazar_subcategorias(contenido_tag4,mapeo)
        PARSER_LOGGER.debug(contenido_tag4_adaptado)
        resultados_tag4_MT[os.path.basename(ruta_al_archivo)] = contenido_tag4_adaptado  # Almacena el resultado
        resultados_tag4_MT= process_tag(contenido,resultados_tag4_MT)
        contenido_tag5 = MTFunctions.parseMTTag5(contenido)
        PARSER_LOGGER.debug(contenido_tag5)
        resultados_tag5_MT[os.path.basename(ruta_al_archivo)] = contenido_tag5  # Almacena el resultado
        ALL_TAGS= MTFunctions.join_all_tags(resultados_tag1_MT,resultados_tag2_MT,resultados_tag3_MT,resultados_tag4_MT,resultados_tag5_MT)
        ALL_TAGS= modify_swift_message_type(ALL_TAGS)
        
    elif isMX(ruta_al_archivo):
        PARSER_LOGGER.debug("Es un archivo MX: "+ filename)
        tree = ET.parse(ruta_al_archivo)
        root = tree.getroot()
        atributos_mx_finales= MXFunctions.extract_values_with_tags_and_attributes(root)
        atributos_mx_finales= MXFunctions.flatten_lists(atributos_mx_finales)
        atributos_mx_finales['Message_Content']= MXFunctions.obtener_contenido(root)
        atributos_mx_finales['Extraction_Date']= str(datetime.now())
        atributos_mx_finales['Payment_Date']= ruta_zip.split('_')[1].replace('.zip', '')
        atributos_mx_finales['Format']='MX'
        PARSER_LOGGER.debug(atributos_mx_finales)
        resultados_MX[os.path.basename(ruta_al_archivo)] = atributos_mx_finales
    else: 
        PARSER_LOGGER.error("ERROR NO ES UN ARCHIVO MT O MX: "+ filename)
    
    return ALL_TAGS, resultados_MX

#############################################################################################################################################
## Funcion 5: ES LA FUNCIÓN QUE SE OCUPA DE SEPARAR LOS ARCHIVOS UNKNOWN PARA PODER ANALIZARLOS.
#############################################################################################################################################   
def separar_secciones(carpeta):
    try:
        # Leer el contenido del archivo
        with open(carpeta, 'r', encoding='utf-8') as f:
            contenido = f.read()
        # Encontrar la sección AppHdr
        match_apphdr = re.search(r'<AppHdr[^>]*>.*?</AppHdr>', contenido, re.DOTALL)
        if match_apphdr:
            apphdr_xml = match_apphdr.group(0)
            if apphdr_xml is not None:
                nombre_archivo = carpeta.replace(".unknown", "_AppHdr.xml")
                root = ET.fromstring(apphdr_xml)
                tree = ET.ElementTree(root)
                tree.write(nombre_archivo, encoding='utf-8', xml_declaration=True)
                print(f"Contenido guardado en '{nombre_archivo}'.")

        # Encontrar la sección Document
        match_document = re.search(r'<Document[^>]*>.*?</Document>', contenido, re.DOTALL)
        if match_document:
            document_xml = match_document.group(0)
            if document_xml is not None:
                nombre_archivo = carpeta.replace(".unknown", "_Document.xml")
                root = ET.fromstring(document_xml)
                tree = ET.ElementTree(root)
                tree.write(nombre_archivo, encoding='utf-8', xml_declaration=True)
                print(f"Contenido guardado en '{nombre_archivo}'.")

    except Exception as e:
        print(f'Error al procesar {carpeta}: {e}')