import re
import os
import MT_properties

##########################################################################################################
## Funcion 1: FUNCIÓN PARA SACAR TODO EL CONTENIDO DE LOS MENSAJES MT 
## ------------------------------------------------------------
## Con esta función ademas de sacar el contenido dividimos los tags en un diccionario 
## Se aplica en la funcion ProcessMessage en initialFunctions.py
##########################################################################################################

def parseMT(ruta_al_archivo):
    with open(ruta_al_archivo, 'r') as archivo:
        contenido = archivo.read()

        # Usamos expresiones regulares para encontrar y extraer cada tag
        resultado_tag1 = re.search(r'{1:(.*?)\}', contenido)
        resultado_tag2 = re.search(r'{2:(.*?)\}', contenido)
        resultado_tag3 = re.search(r'{3:(.*?)}\}', contenido)
        # Usamos una expresión regular para encontrar el tag4
        indice_inicio_tag4 = contenido.find("{4:") + 4
        indice_fin_tag4 = contenido.find("}", indice_inicio_tag4)

        if indice_inicio_tag4 != -1 and indice_fin_tag4 != -1:
            tag4 = contenido[indice_inicio_tag4:indice_fin_tag4]
        else:
            tag4 = "No se encontró información en el tag4"

        # Igual que el 1, 2 y 3
        resultado_tag5 = re.search(r'{5:(.*?)}\}', contenido)

        # Creamos un diccionario con los resultados y lo retornamos
        contenido_tag = {
            "tag1": resultado_tag1.group(1) if resultado_tag1 else "No se encontró información en el tag1",
            "tag2": resultado_tag2.group(1) if resultado_tag2 else "No se encontró información en el tag2",
            "tag3": resultado_tag3.group(1) + '}' if resultado_tag3 else "No se encontró información en el tag3",
            "tag4": tag4,
            "tag5": resultado_tag5.group(1) if resultado_tag5 else "No se encontró información en el tag5"
        }

        return contenido_tag, contenido

##########################################################################################################
## Funcion 2: FUNCIÓN PARA EXTRAER LOS CAMPOS DEL TAG 1 
## ------------------------------------------------------------
## Se aplica en la funcion ProcessMessage en initialFunctions.py
##########################################################################################################

def parseMTTag1(contenido):
    resultados_tag1={}
    tag1 = contenido["tag1"]
    # Aplicar las funciones a tag1
    if tag1[0] == "F" or tag1[0] == "A" or tag1[0] == "L":
        AppID = tag1[0]
    else:
        AppID = 'ERROR'

    if tag1[1:3] == "01" or tag1[1:3] == "21":
        ServiceID = tag1[1:3]
    else:
        ServiceID = 'ERROR'

    if tag1[11].isalpha() and tag1[11].isupper():
        LTAddress = tag1[3:15]
    else:
        LTAddress = 'ERROR'

    if tag1[15:19].isdigit():
        SessionNumber = tag1[15:19]
    else:
        SessionNumber = 'ERROR'

    if tag1[19:].isdigit():
        SequenceNumber = tag1[19:]
    else:
        SequenceNumber = 'ERROR'

    # Almacenar los resultados en el diccionario resultados_tags
    resultados_tag1 = {
        "AppID": AppID,
        "ServiceID": ServiceID,
        "LTAddress": LTAddress,
        "SessionNumber": SessionNumber,
        "SequenceNumber": SequenceNumber
    }
    return resultados_tag1

##########################################################################################################
## Funcion 3: FUNCIÓN PARA EXTRAER LOS CAMPOS DEL TAG 2 
## ------------------------------------------------------------
## Se aplica en la funcion ProcessMessage en initialFunctions.py
##########################################################################################################

def parseMTTag2(contenido):
    resultados_tag2 = {}
    tag2 = contenido["tag2"]

    if tag2[0]=='I':
        Input_Output= tag2[0]
    elif tag2[0]=='O':
        Input_Output= tag2[0]
    else:
        Input_Output=  'ERROR'

    if tag2[1:4].isdigit():
        SWIFT_Message_Type= tag2[1:4]   
    else:
        SWIFT_Message_Type= 'ERROR'
    
    # CARACTERÍSTICAS ÚNICAS DEL IMPUT
    
    if tag2[0]=='I':
        Destination_Address= tag2[4:16]  
    else:
        Destination_Address= 'ERROR'
    
    if tag2[0]=='I' and len(tag2)==17 and (tag2[16]=='S' or tag2[16]=='U' or tag2[16]=='N'):
        Priority_I= tag2[16] 
    else:
        Priority_I= '---'
    
    if tag2[0]=='I' and len(tag2)==18 and (tag2[17]=='1' or tag2[17]=='2' or tag2[17]=='3'):
        Delivery_Monitoring= tag2[17] 
    else:
        Delivery_Monitoring= '---'    

    if tag2[0]=='I' and len(tag2)==21 and (tag2[17:20]=='003' or tag2[17:20]=='020'):
        Obsolescence_Period= tag2[17:20] 
    else:
        Obsolescence_Period= '---' 
        
    #CARACTERÍSTICAS ÚNICAS DEL OUTPUT
    
    if tag2[0]=='O' and tag2[4:8].isdigit():
        Input_Time= tag2[4:8]
    else:
        Input_Time= 'ERROR'
      
    if tag2[0]=='O' and tag2[8:14].isdigit() and tag2[27:37].isdigit():
        MIR= tag2[8:36]
    else:
        MIR= 'ERROR'
    
    if tag2[0]=='O' and tag2[36:42].isdigit():
        Output_Date= tag2[36:42] 
    else:
        Output_Date= 'ERROR'
    
    if tag2[0]=='O' and tag2[42:46].isdigit():
        Output_Time= tag2[42:46] 
    else:
        Output_Time= 'ERROR'
    
    if tag2[0]=='O' and len(tag2)==47:
        Priority= tag2[46] ## esto no se si es 47 o 46
    else:
        Priority= '---'
        
    # Almacenar los resultados en el diccionario resultados_tags
    if tag2[0]=='I': 
        resultados_tag2 = {
            "Input_Output": Input_Output,
            "SWIFT_Message_Type": SWIFT_Message_Type,
            "Destination_Address": Destination_Address,
            "Priority_I": Priority_I,
            "Delivery_Monitoring": Delivery_Monitoring,
            "Obsolescence_Period": Obsolescence_Period
        }
    else:
        resultados_tag2 = {
            "Input_Output": Input_Output,
            "SWIFT_Message_Type": SWIFT_Message_Type,
            "Input_Time": Input_Time,
            "MIR": MIR,
            "Output_Date": Output_Date,
            "Output_Time": Output_Time,
            "Priority": Priority
        }
    # Aplicar el filtro para eliminar las claves con valor '---'
    resultados_tag2= {clave: valor for clave, valor in resultados_tag2.items() if valor != '---'}

    return resultados_tag2

##########################################################################################################
## Funcion 4: FUNCIÓN PARA EXTRAER LOS CAMPOS DEL TAG 3 
## ------------------------------------------------------------
## Se aplica en la funcion ProcessMessage en initialFunctions.py
##########################################################################################################

def parseMTTag3(contenido):
    resultados_tag3 = {}
    tag3 = contenido["tag3"]

    Tag103_Service_Identifier = re.search(r'103:(.*?)\}', tag3)
    if Tag103_Service_Identifier:
        Tag103_Service_Identifier = '103:'+Tag103_Service_Identifier.group(1)
    else:
        Tag103_Service_Identifier= '---'
    
    Tag113_Banking_Priority = re.search(r'113:(.*?)\}', tag3)
    if Tag113_Banking_Priority:
        Tag113_Banking_Priority = '113:'+Tag113_Banking_Priority.group(1)
    else:
        Tag113_Banking_Priority= '---'

    Tag108_MUR = re.search(r'108:(.*?)\}', tag3)
    if Tag108_MUR:
        Tag108_MUR = '108:'+Tag108_MUR.group(1)
    else:
        Tag108_MUR= '---'
    
    Tag119_Validation_Flag = re.search(r'119:(.*?)\}', tag3)
    if Tag119_Validation_Flag:
        Tag119_Validation_Flag = '119:'+Tag119_Validation_Flag.group(1)
    else:
        Tag119_Validation_Flag= '---'
    
    Tag423_Balance_checkpoint_date_and_time= re.search(r'423:(.*?)\}', tag3)
    if Tag423_Balance_checkpoint_date_and_time:
        Tag423_Balance_checkpoint_date_and_time = '423:'+Tag423_Balance_checkpoint_date_and_time.group(1)
    else:
        Tag423_Balance_checkpoint_date_and_time= '---'
    
    Tag106_MIR = re.search(r'106:(.*?)\}', tag3)
    if Tag106_MIR:
        Tag106_MIR = '106:'+Tag106_MIR.group(1)
    else:
        Tag106_MIR= '---'

    Tag424_Related_reference = re.search(r'424:(.*?)\}', tag3)
    if Tag424_Related_reference:
        Tag424_Related_reference = '424:'+Tag424_Related_reference.group(1)
    else:
        Tag424_Related_reference= '---'
    
    Tag111_Service_type_identifier = re.search(r'111:(.*?)\}', tag3)
    if Tag111_Service_type_identifier:
        Tag111_Service_type_identifier = '111:'+Tag111_Service_type_identifier.group(1)
    else:
        Tag111_Service_type_identifier= '---'
    
    Tag121_Unique_end_to_end_transaction_reference = re.search(r'121:(.*?)\}', tag3)
    if Tag121_Unique_end_to_end_transaction_reference:
        Tag121_Unique_end_to_end_transaction_reference = '121:'+Tag121_Unique_end_to_end_transaction_reference.group(1)
    else:
        Tag121_Unique_end_to_end_transaction_reference= '---'
    
    Tag115_Addressee_Information = re.search(r'115:(.*?)\}', tag3)
    if Tag115_Addressee_Information:
        Tag115_Addressee_Information = '115:'+Tag115_Addressee_Information.group(1)
    else:
        Tag115_Addressee_Information= '---'
       
    Tag165_Payment_release_information_receiver = re.search(r'165:(.*?)\}', tag3)
    if Tag165_Payment_release_information_receiver:
        Tag165_Payment_release_information_receiver = '165:'+Tag165_Payment_release_information_receiver.group(1)
    else:
        Tag165_Payment_release_information_receiver= '---'
    
    Tag433_Sanctions_screening_information_for_receiver = re.search(r'433:(.*?)\}', tag3)
    if Tag433_Sanctions_screening_information_for_receiver:
        Tag433_Sanctions_screening_information_for_receiver = '433:'+Tag433_Sanctions_screening_information_for_receiver.group(1)
    else:
        Tag433_Sanctions_screening_information_for_receiver= '---'

    Tag434_Payment_controls_information_for_receiver = re.search(r'434:(.*?)\}', tag3)
    if Tag434_Payment_controls_information_for_receiver:
        Tag434_Payment_controls_information_for_receiver = '434:'+Tag434_Payment_controls_information_for_receiver.group(1)
    else:
        Tag434_Payment_controls_information_for_receiver= '---'

    # Almacenar los resultados en el diccionario resultados_tags
    resultados_tag3 = {
        "Service_Identifier_103": Tag103_Service_Identifier,
        "Banking_Priority_113": Tag113_Banking_Priority,
        "MUR_108": Tag108_MUR,
        "Validation_Flag_119": Tag119_Validation_Flag,
        "Balance_checkpoint_date_and_time_423": Tag423_Balance_checkpoint_date_and_time,
        "MIR_106": Tag106_MIR,
        "Related_reference_424": Tag424_Related_reference,
        "Service_type_identifier_111": Tag111_Service_type_identifier,
        "UETR": Tag121_Unique_end_to_end_transaction_reference,
        "Addressee_Information_115": Tag115_Addressee_Information,
        "Payment_release_information_receiver_165": Tag165_Payment_release_information_receiver,
        "Sanctions_screening_information_for_receiver_433": Tag433_Sanctions_screening_information_for_receiver,
        "Payment_controls_information_for_receiver_434": Tag434_Payment_controls_information_for_receiver
    }
    # Aplicar el filtro para eliminar las claves con valor '---'
    resultados_tag3= {clave: valor for clave, valor in resultados_tag3.items() if valor != '---'}
    return resultados_tag3

##############################################################################################################
## Funcion 5: FUNCIÓN PARA INDICAR COMO SE VA A LLAMAR CADA CAMPO DEL TAG4 
## ------------------------------------------------------------
## Las listas que utiliza para definir este mapeo están en MT_properites.py
## Se aplica en la funcion ProcessMessage en initialFunctions.py y lo utilizaremos para la función parseMTTag4
##############################################################################################################

def selectMT(contenido):
    tag2 = contenido["tag2"]
    lista_subcategorias_valor=[]
    lista_subcategorias=[]
    # Obtiene el diccionario global del módulo miarchivo
    variables_globales = MT_properties.__dict__
    # Filtra las variables que son listas
    listas_en_miarchivo = {nombre: valor for nombre, valor in variables_globales.items() if isinstance(valor, list)}
    for nombre, lista in listas_en_miarchivo.items():
        if nombre == "lista_"+ tag2[1:4]:
            lista_subcategorias=lista
        elif nombre.startswith("lista_valor_"+tag2[1:4]):
            lista_subcategorias_valor=lista
        
    mapeo = dict(zip(lista_subcategorias_valor, lista_subcategorias))


    return lista_subcategorias,lista_subcategorias_valor,mapeo

##############################################################################################################
## Funcion 6: FUNCIÓN PARA EXTRAER LOS CAMPOS DEL TAG 4
## ------------------------------------------------------------
## Este tag es más complicado de extraer que los demás, por eso utilizaremos más de una función
## Se aplica en la funcion ProcessMessage en initialFunctions.py 
##############################################################################################################

def parseMTTag4(contenido,mapeo,lista_subcategorias_valor):
    tag4 = contenido["tag4"]
    resultados_por_archivo = {}
    if tag4!= 'No se encontró información en el tag4': 
        # Expresión regular para capturar los valores
        expresion_regular = '|'.join(map(re.escape, lista_subcategorias_valor))
        expresion_regular = f'({expresion_regular})(.*?)(?={expresion_regular}|$)'
        matches = re.findall(expresion_regular, tag4, re.DOTALL)
        for match in matches:
            patron_inicial = match[0]
            if patron_inicial in mapeo:
                # Obtener el nombre original del mapeo
                nombre_original = mapeo[patron_inicial]

                # Construir la clave sin sufijo para la primera aparición
                nueva_clave = nombre_original

                # Verificar si ya hay un valor para esta clave, si no lo hay, agregar el valor
                if nueva_clave not in resultados_por_archivo:
                    resultados_por_archivo[nueva_clave] = match[1]
                else:
                    # Para las apariciones siguientes, agregar sufijo numérico
                    sufijo_numerico = 1
                    while f"{nombre_original}_{sufijo_numerico}" in resultados_por_archivo:
                        sufijo_numerico += 1
                    nueva_clave = f"{nombre_original}_{sufijo_numerico}"
                    resultados_por_archivo[nueva_clave] = match[1]

    return resultados_por_archivo, mapeo

#######################################################################################################################
## Funcion 7: FUNCIÓN PARA INDICAR COMO SE VA A LLAMAR CADA CAMPO DEL TAG4 
## ------------------------------------------------------------
## Esta función sustituye las subcategorías en el diccionario correspondiente al tag 4 con sus nombres originales
## Se aplica en la funcion ProcessMessage en initialFunctions.py y lo utilizaremos para la función parseMTTag4
#######################################################################################################################

def reemplazar_subcategorias(diccionario, mapeo_subcategorias):
    diccionario_actualizado = {}
    for clave, valor in diccionario.items():
        if isinstance(valor, dict):
            # Si el valor es otro diccionario, llamar a la función de forma recursiva
            diccionario_actualizado[clave] = reemplazar_subcategorias(valor, mapeo_subcategorias)
        elif clave in mapeo_subcategorias:
            # Si la clave coincide con una subcategoría en el mapeo, reemplazarla
            nueva_clave = mapeo_subcategorias[clave]
            diccionario_actualizado[nueva_clave] = valor
        else:
            diccionario_actualizado[clave] = valor
    return diccionario_actualizado

##############################################################################################################
## Funcion 8: FUNCIÓN PARA EXTRAER LOS CAMPOS DEL TAG 5
## ------------------------------------------------------------
## Se aplica en la funcion ProcessMessage en initialFunctions.py 
##############################################################################################################

def parseMTTag5(contenido):
    resultados_tag5={}
    tag5 = contenido["tag5"]
    
    CHK_Checksum = re.search(r'CHK:(.*?)\}', tag5)
    if CHK_Checksum:
        CHK_Checksum = 'CHK:'+CHK_Checksum.group(1)
    else:
        CHK_Checksum= '---'

    TNG_Test_Training_Message = re.search(r'TNG:(.*?)\}', tag5)
    if TNG_Test_Training_Message:
        TNG_Test_Training_Message = 'TNG:'+TNG_Test_Training_Message.group(1)
    else:
        TNG_Test_Training_Message= '---'

    PDE_Possible_Duplicate_Emission = re.search(r'PDE:(.*?)\}', tag5)
    if PDE_Possible_Duplicate_Emission:
        PDE_Possible_Duplicate_Emission = 'PDE:'+PDE_Possible_Duplicate_Emission.group(1)
    else:
        PDE_Possible_Duplicate_Emission= '---'
    
    DLM_Delayed_Message = re.search(r'DLM:(.*?)\}', tag5)
    if DLM_Delayed_Message:
        DLM_Delayed_Message = 'DLM:'+DLM_Delayed_Message.group(1)
    else:
        DLM_Delayed_Message= '---'
    
    MRF_Message_Reference = re.search(r'MRF:(.*?)\}', tag5)
    if MRF_Message_Reference:
        MRF_Message_Reference = 'MRF:'+MRF_Message_Reference.group(1)
    else:
        MRF_Message_Reference= '---'
    
    PDM_Possible_Duplicate_Message = re.search(r'PDM:(.*?)\}', tag5)
    if PDM_Possible_Duplicate_Message:
        PDM_Possible_Duplicate_Message = 'PDM:'+PDM_Possible_Duplicate_Message.group(1)
    else:
        PDM_Possible_Duplicate_Message= '---'

    SYS_System_Originated_Message = re.search(r'SYS:(.*?)\}', tag5)
    if SYS_System_Originated_Message:
        SYS_System_Originated_Message = 'SYS:'+SYS_System_Originated_Message.group(1)
    else:
        SYS_System_Originated_Message= '---'
        
    # Almacenar los resultados en el diccionario resultados_tags
    resultados_tag5 = {
        "CHK_Checksum": CHK_Checksum,
        "TNG_Test_Training_Message": TNG_Test_Training_Message,
        "PDE_Possible_Duplicate_Emission": PDE_Possible_Duplicate_Emission,
        "DLM_Delayed_Message": DLM_Delayed_Message,
        "MRF_Message_Reference": MRF_Message_Reference,
        "PDM_Possible_Duplicate_Message": PDM_Possible_Duplicate_Message,
        "SYS_System_Originated_Message": SYS_System_Originated_Message
    }
    # Aplicar el filtro para eliminar las claves con valor '---'
    resultados_tag5= {clave: valor for clave, valor in resultados_tag5.items() if valor != '---'}
    return resultados_tag5

##############################################################################################################
## Funcion 9: FUNCIÓN PARA COMBINAR TODOS LOS TAGS EN UN SOLO DICCIONARIO 
## ------------------------------------------------------------
## Se aplica en la funcion ProcessMessage en initialFunctions.py 
##############################################################################################################

def join_all_tags(resultados_tag1_MT,resultados_tag2_MT,resultados_tag3_MT,resultados_tag4_MT,resultados_tag5_MT):
    lista_de_diccionarios_SWIFT_MT=[resultados_tag1_MT,resultados_tag2_MT,resultados_tag3_MT,resultados_tag4_MT,resultados_tag5_MT]
    diccionario_SWIFT_MT = {}
    for diccionario in lista_de_diccionarios_SWIFT_MT:
        for clave, valor in diccionario.items():
            if clave in diccionario_SWIFT_MT:
                # Si la clave ya existe, actualiza el valor con el nuevo diccionario
                diccionario_SWIFT_MT[clave].update(valor)
            else:
                # Si la clave no existe, crea una nueva entrada en el diccionario combinado
                diccionario_SWIFT_MT[clave] = valor
    return diccionario_SWIFT_MT

import pandas as pd
import numpy as np

##############################################################################################################
## Funcion 10: FUNCIÓN PARA SEPARAR LOS MENSAJES MT 101 EN VARIOS MENSAJES
## ------------------------------------------------------------
## Se aplica en SWIFT_parsing.py 
##############################################################################################################

def separar_mensajes_101(df):
    df_duplicated = pd.DataFrame(columns=df.columns)
    for index, row in df.iterrows():
        if row['SWIFT_Message_Type'] == '101':
            for i in range(1, 8):  # Iterar hasta la columna _7
                col_name = f'Transaction_Reference_21_{i}'
                if col_name in df and not pd.isna(row[col_name]):  # Si la columna está informada
                    duplicated_row = row.copy()  # Copiar la fila original
                    duplicated_row['Filename'] += f'_{i}'  # Cambiar el valor de la columna 'Archivo'
                    df_duplicated = pd.concat([df_duplicated, duplicated_row.to_frame().T], ignore_index=True)
    df_duplicated = pd.concat([df, df_duplicated],ignore_index=True)
    nombres_filas_con_1 = [nombre[:-2] for nombre in df_duplicated[df_duplicated['Filename'].str.endswith('_1')]['Filename']]
    if nombres_filas_con_1:
        mask = df_duplicated['Filename'].isin(nombres_filas_con_1)
        columnas_seleccionadas = df_duplicated.columns[df_duplicated.columns.get_loc('Transaction_Reference_21_1'):]
        df_duplicated.loc[mask, columnas_seleccionadas] = np.nan
        for i in range(1,5):
            try:
                mask = df_duplicated['Filename'].str.endswith(f'_{i}')
                columnas_seleccionadas = list(df_duplicated.columns[df_duplicated.columns.get_loc('Transaction_Reference_21'): df_duplicated.columns.get_loc(f'Transaction_Reference_21_{i}')])
                if f'Transaction_Reference_21_{i+1}' in df_duplicated.columns:
                    columnas_nuevas = df_duplicated.columns[df_duplicated.columns.get_loc(f'Transaction_Reference_21_{i+1}'):]
                    columnas_seleccionadas.extend(columnas_nuevas)
                    df_duplicated.loc[mask, columnas_seleccionadas] = np.nan
                else:
                    df_duplicated.loc[mask, columnas_seleccionadas] = np.nan
            except:
                pass
    return df_duplicated