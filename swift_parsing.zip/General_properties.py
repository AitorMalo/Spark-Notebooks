import os

# Home directory
os.environ['HOME_DIR'] = '/data/x328135'
# Notebook directory
os.environ['NOTEBOOK_DIR'] = os.environ.get('HOME_DIR')+'/notebook'
# Log directory
os.environ['LOG_DIR'] = os.environ.get('NOTEBOOK_DIR')+'/log'
# Data directory
os.environ['DAT_DIR'] = os.environ.get('HOME_DIR')+'/data'
# Temp directory
os.environ['TEMP_DIR'] = os.environ.get('DAT_DIR')+'/temp_extracted'
# Log name
os.environ['LOG_NAME'] = 'This value is automatically updated for each execution.'
# Log level
os.environ['LOG_LEVEL'] = 'INFO'
# Log depth
os.environ['LOG_DEPTH'] = '5' #dias

#listas de payments and trade Message type
lista_payments_message_type=['101', '103','103_REMIT','103_STP','192', '195', '196', '199', '202','202_COV', '205','205_COV','292', '295', '296', '299']
lista_trade_message_type=['700', '701', '707', '708', '710', '711', '720', '721', '734', '792', '795', '796', '799', '760', '761']
# lista de las columnas payment
lista_payments = ['Filename','Message_Content','Creation_date', 'Direction', 'Sender_InstructingAgent_Requestor', 'Receiver_InstructedAgent_Responder', 'OwnBIC8', 'Own_Country', 'Role', 'Format', 'Message_type', 'InstructionId', 'End2EndId', 'UETR', 'Related_Message_Id', 'Transaction_Reference','Interbank_Settled_Date','Interbank_Settled_Currency', 'Interbank_Settled_Amount', 'Instructed_Currency', 'Instructed_Amount', 'Ordering_Customer_Account', 'Ordering_Customer_Name','Ordering_Customer_Id', 'Ordering_Customer_Address','Ordering_Customer_Address_Country','Ordering_Customer_Residence_Country','Ordering_Customer_Date_Of_Birth','Ordering_Customer_Place_Of_Birth','Ordering_Customer_ID_Number','Ordering_Customer_National_ID_Number','Ordering_Customer_Id_Additional_Information','Ordering_Institution','Ordering_Institution_Name','Ordering_Institution_Address', "Senders_Correspondent", "Senders_Correspondent_Name_and_Address", "Receivers_Correspondent", "Receivers_Correspondent_Name_and_Address", 'Third_Reimbursement_Institution', 'Third_Reimbursement_Institution_Name_and_Address', 'Intermediary_Institution','Beneficiary_Institution','Beneficiary_Institution_Name','Beneficiary_Institution_Address', 'Account_With_Institution','Account_With_Institution_Address','Account_With_Institution_Name_and_Address','Beneficiary_Account', 'Beneficiary_Name','Beneficiary_Id', 'Beneficiary_Address','Beneficiary_Address_Country','Beneficiary_Residence_Country','Beneficiary_Additional_Information','Remittance_Information', 'Narrative','Sender_to_Receiver_Information']
# lista de las columnas trade
lista_trade= ['Filename','Message_Content','Creation_date','Direction', 'Sender_InstructingAgent_Requestor', 'Receiver_InstructedAgent_Responder','OwnBIC8','Own_Country','Role','Format','Message_type','Type_Purpose','Senders_Reference','Receivers_Reference','Issuing_Banks_Reference','Issue_Date','Expiry_Date','Expiry_Place','Applicant_Name','Applicant_Address','Applicant_Bank','Applicant_Bank_Name_and_Address','Instructing_Party','Issuing_Bank','Issuing_Bank_Name','Issuing_Bank_Address','Beneficiary_Account','Beneficiary_Name','Beneficiary_Address','Currency','Amount','Available_Bank','Available_Bank_Name','Available_Bank_Address','Drawee','Drawee_Name','Drawee_Address','Place_Dispatch_Receipt','PortLoading_AirportDeparture','PortDischarge_AirportDestination','Place_Destination_Delivery','Latest_Date_Shipment','Description_Goods','Documents_Required','Additional_Conditions','Requested_Confirmation_Party','Requested_Confirmation_Party_Name','Requested_Confirmation_Party_Address','Reimbursing_Bank','Reimbursing_Bank_Name','Reimbursing_Bank_Address','Instructions','Advising_Bank','Advising_Bank_Name','Advising_Bank_Address','Advise_Through_Bank','Advise_Through_Bank_Name_and_Address','Sender_to_Receiver_Information','Undertaking_Terms','Transaction_Details','Local_Type_Purpose','Local_Applicant_Name','Local_Applicant_Address','Local_Beneficiary_Account','Local_Beneficiary_Name','Local_Beneficiary_Address','Local_Currency','Local_Amount','Local_Undertaking_Terms','Local_Transaction_Details','Narrative']
